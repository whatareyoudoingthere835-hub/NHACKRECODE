package aethereal.config;

import aethereal.core.Delta;
import aethereal.core.EventManager;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.Module;
import aethereal.event.KeyEvent;
import aethereal.lib.json.JSONArray;
import aethereal.lib.json.JSONObject;
import aethereal.module.combat.NoFriendDamage;
import aethereal.module.misc.NoCommands;
import aethereal.module.render.BlockESP;
import aethereal.module.render.Interface_2;
import aethereal.setting.BindSetting;
import aethereal.setting.Setting;
import aethereal.ui.screen.GUIScreen;
import lombok.Generated;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import aethereal.module.combat.Aura;
import aethereal.module.combat.TriggerBot;
import aethereal.module.combat.AutoTotem;
import aethereal.module.combat.ProjectileHelper;
import aethereal.module.combat.MaceHelper;
import aethereal.module.combat.AimAssistant;
import aethereal.module.combat.AntiBot;
import aethereal.module.combat.AutoArmor;
import aethereal.module.combat.AutoEXP;
import aethereal.module.combat.AutoExplosion;
import aethereal.module.combat.AutoSwap;
import aethereal.module.combat.HitBoxes;
import aethereal.module.combat.ItemHelper;
import aethereal.module.combat.NoServerDesync;
import aethereal.module.combat.NoServerPack;
import aethereal.module.combat.NoSlotChange;
import aethereal.module.combat.ShiftTAP;
import aethereal.module.combat.TapeMouse;
import aethereal.module.combat.Velocity;
import aethereal.module.player.WindHop;
import aethereal.render.Animations;
import aethereal.module.misc.ServerAssistant;
import aethereal.module.misc.StreamerMode;
import aethereal.module.movement.AirStuck;
import aethereal.module.movement.AutoDodge;
import aethereal.module.movement.ElytraTarget;
import aethereal.module.movement.FastBreak;
import aethereal.module.movement.Fly;
import aethereal.module.movement.FreeCamera;
import aethereal.module.movement.NoCrouch;
import aethereal.module.movement.NoDelay;
import aethereal.module.movement.NoPush;
import aethereal.module.movement.NoSlowDown;
import aethereal.module.movement.SafeWalk;
import aethereal.module.movement.Scaffold;
import aethereal.module.movement.ScreenWalk;
import aethereal.module.movement.Sprint;
import aethereal.module.movement.WallClimb;
import aethereal.module.movement.WaterJump;
import aethereal.ambience.Ambience;
import aethereal.module.misc.AncientFarmer;
import aethereal.module.misc.AntiAFK;
import aethereal.module.misc.AppleFarmer;
import aethereal.module.player.AucReissue;
import aethereal.module.player.AutoAccept;
import aethereal.module.player.AutoAuth;
import aethereal.module.misc.AutoBuy;
import aethereal.module.player.AutoEat;
import aethereal.module.player.AutoFish;
import aethereal.module.player.AutoLeave;
import aethereal.module.player.AutoRespawn;
import aethereal.module.player.AutoTool;
import aethereal.module.misc.AutoWarden;
import aethereal.module.player.CaptchaSolver;
import aethereal.module.misc.ChatHelper;
import aethereal.module.player.ChestStealer;
import aethereal.module.misc.ClanUpgrader;
import aethereal.module.player.ClickAction;
import aethereal.module.misc.Collector_2;
import aethereal.module.misc.Communication;
import aethereal.module.player.DeathCoords;
import aethereal.module.player.ElytraHelper;
import aethereal.module.player.FakeLags;
import aethereal.module.player.FastEXP;
import aethereal.module.player.FastLoad;
import aethereal.module.misc.FunDeliver;
import aethereal.module.player.ItemScroller;
import aethereal.module.player.LockSlot;
import aethereal.module.misc.MineAssistant;
import aethereal.module.misc.NoInteract;
import aethereal.module.misc.Nuker;
import aethereal.module.player.OpenWalls;
import aethereal.module.misc.PortalBypass;
import aethereal.module.misc.PotionThrower;
import aethereal.module.misc.ServerJoiner;
import aethereal.module.player.SoundReducer;
import aethereal.module.misc.Sounds;
import aethereal.module.player.Structures;
import aethereal.module.player.ThirdPerson;
import aethereal.module.player.UseTracker;
import aethereal.module.misc.XRay;
import aethereal.module.render.AspectRatio;
import aethereal.module.render.BoardSpoofer;
import aethereal.module.render.ChinaHat;
import aethereal.module.render.Crosshair;
import aethereal.module.render.EntityBox;
import aethereal.module.render.EntityESP;
import aethereal.module.render.FullBright;
import aethereal.module.render.HandsShader;
import aethereal.module.render.ItemPhysic;
import aethereal.module.render.Pointers;
import aethereal.module.render.Predictions;
import aethereal.module.render.Removals;
import aethereal.module.render.SeeInvisibles;
import aethereal.module.render.ShaderESP;
import aethereal.module.render.ShulkerPreview;
import aethereal.module.render.SoundESP;
import aethereal.module.render.SwingAnimation;
import aethereal.module.render.ViewModel;
import aethereal.module.render.WardenESP;

public class ModuleProcessor extends ConfigProcessor<Module> {
    private Interface_2 bd;
    private NoCommands am;
    private NoFriendDamage noFriendDamage;
    private BlockESP blockESP;
    private Aura B;
    private TriggerBot X;
    private Animations Q;
    private ServerAssistant aj;
    private StreamerMode aE;
    private AutoTotem V;
    private ProjectileHelper D;
    private WindHop aW;
    private MaceHelper H;
    private AimAssistant aimAssistant;
    private AntiBot antiBot;
    private AutoArmor autoArmor;
    private AutoEXP autoEXP;
    private AutoExplosion autoExplosion;
    private AutoSwap autoSwap;
    private HitBoxes hitBoxes;
    private ItemHelper itemHelper;
    private NoServerDesync noServerDesync;
    private NoServerPack noServerPack;
    private NoSlotChange noSlotChange;
    private ShiftTAP shiftTAP;
    private TapeMouse tapeMouse;
    private Velocity velocity;
    private ScreenWalk f;
    private FreeCamera h;
    private AutoDodge l;
    private NoCrouch n;
    private Sprint o;
    private NoSlowDown q;
    private ElytraTarget G;
    private NoPush O;
    private SafeWalk ah;
    private WaterJump aq;
    private AirStuck av;
    private NoDelay ax;
    private Fly aQ;
    private WallClimb aR;
    private Scaffold aS;
    private FastBreak aX;
    private SwingAnimation R;
    private SeeInvisibles T;
    private EntityBox U;
    private EntityESP aa;
    private ShaderESP ad;
    private ItemPhysic ag;
    private Removals ai;
    private ViewModel ao;
    private Crosshair au;
    private ShulkerPreview aw;
    private ChinaHat ay;
    private AspectRatio aB;
    private Predictions aC;
    private WardenESP i;
    private SoundESP m;
    private BoardSpoofer x;
    private Pointers aL;
    private FullBright aO;
    private HandsShader aT;
    private Ambience aF;
    private AncientFarmer aA;
    private AntiAFK I;
    private AppleFarmer az;
    private AucReissue S;
    private AutoAccept K;
    private AutoAuth k;
    private AutoBuy ba;
    private AutoEat aV;
    private AutoFish al;
    private AutoLeave bb;
    private AutoRespawn P;
    private AutoTool N;
    private AutoWarden aU;
    private CaptchaSolver aH;
    private ChatHelper as;
    private ChestStealer aD;
    private ClanUpgrader ar;
    private ClickAction ap;
    private Collector_2 aJ;
    private Communication y;
    private DeathCoords J;
    private ElytraHelper F;
    private FakeLags g;
    private FastEXP aI;
    private FastLoad aN;
    private FunDeliver aY;
    private ItemScroller w;
    private LockSlot p;
    private MineAssistant ak;
    private NoInteract s;
    private Nuker aM;
    private OpenWalls a;
    private PortalBypass aG;
    private PotionThrower aZ;
    private ServerJoiner an;
    private SoundReducer r;
    private Sounds at;
    private Structures j;
    private ThirdPerson M;
    private UseTracker z;
    private XRay E;

    public ModuleProcessor() {
        EventManager.a(this);
    }

    @Override
    public void setup() {
        this.bd = new Interface_2();
        this.am = new NoCommands();
        this.noFriendDamage = new NoFriendDamage();
        this.blockESP = new BlockESP();
        this.B = new Aura();
        this.X = new TriggerBot();
        this.Q = new Animations();
        this.aj = new ServerAssistant();
        this.aE = new StreamerMode();
        this.V = new AutoTotem();
        this.D = new ProjectileHelper();
        this.aW = new WindHop();
        this.H = new MaceHelper();
        this.aimAssistant = new AimAssistant();
        this.antiBot = new AntiBot();
        this.autoArmor = new AutoArmor();
        this.autoEXP = new AutoEXP();
        this.autoExplosion = new AutoExplosion();
        this.autoSwap = new AutoSwap();
        this.hitBoxes = new HitBoxes();
        this.itemHelper = new ItemHelper();
        this.noServerDesync = new NoServerDesync();
        this.noServerPack = new NoServerPack();
        this.noSlotChange = new NoSlotChange();
        this.shiftTAP = new ShiftTAP();
        this.tapeMouse = new TapeMouse();
        this.velocity = new Velocity();
        this.f = new ScreenWalk();
        this.h = new FreeCamera();
        this.l = new AutoDodge();
        this.n = new NoCrouch();
        this.o = new Sprint();
        this.q = new NoSlowDown();
        this.G = new ElytraTarget();
        this.O = new NoPush();
        this.ah = new SafeWalk();
        this.aq = new WaterJump();
        this.av = new AirStuck();
        this.ax = new NoDelay();
        this.aQ = new Fly();
        this.aR = new WallClimb();
        this.aS = new Scaffold();
        this.aX = new FastBreak();
        this.R = new SwingAnimation();
        this.T = new SeeInvisibles();
        this.U = new EntityBox();
        this.aa = new EntityESP();
        this.ad = new ShaderESP();
        this.ag = new ItemPhysic();
        this.ai = new Removals();
        this.ao = new ViewModel();
        this.au = new Crosshair();
        this.aw = new ShulkerPreview();
        this.ay = new ChinaHat();
        this.aB = new AspectRatio();
        this.aC = new Predictions();
        this.i = new WardenESP();
        this.m = new SoundESP();
        this.x = new BoardSpoofer();
        this.aL = new Pointers();
        this.aO = new FullBright();
        this.aT = new HandsShader();
        this.aF = new Ambience();
        this.aA = new AncientFarmer();
        this.I = new AntiAFK();
        this.az = new AppleFarmer();
        this.S = new AucReissue();
        this.K = new AutoAccept();
        this.k = new AutoAuth();
        this.ba = new AutoBuy();
        this.aV = new AutoEat();
        this.al = new AutoFish();
        this.bb = new AutoLeave();
        this.P = new AutoRespawn();
        this.N = new AutoTool();
        this.aU = new AutoWarden();
        this.aH = new CaptchaSolver();
        this.as = new ChatHelper();
        this.aD = new ChestStealer();
        this.ar = new ClanUpgrader();
        this.ap = new ClickAction();
        this.aJ = new Collector_2();
        this.y = new Communication();
        this.J = new DeathCoords();
        this.F = new ElytraHelper();
        this.g = new FakeLags();
        this.aI = new FastEXP();
        this.aN = new FastLoad();
        this.aY = new FunDeliver();
        this.w = new ItemScroller();
        this.p = new LockSlot();
        this.ak = new MineAssistant();
        this.s = new NoInteract();
        this.aM = new Nuker();
        this.a = new OpenWalls();
        this.aG = new PortalBypass();
        this.aZ = new PotionThrower();
        this.an = new ServerJoiner();
        this.r = new SoundReducer();
        this.at = new Sounds();
        this.j = new Structures();
        this.M = new ThirdPerson();
        this.z = new UseTracker();
        this.E = new XRay();
        a(this.bd, this.am, this.noFriendDamage, this.blockESP, this.B, this.X, this.Q, this.aj, this.aE, this.V, this.D, this.aW, this.H,
                this.velocity, this.aimAssistant, this.antiBot, this.autoArmor, this.autoEXP, this.autoExplosion, this.autoSwap, this.hitBoxes,
                this.itemHelper, this.noServerDesync, this.noServerPack, this.noSlotChange, this.shiftTAP, this.tapeMouse);
        a(this.av, this.n, this.h, this.aQ, this.aR, this.aS, this.aq, this.ax, this.ah, this.q, this.l, this.G, this.o, this.O, this.f, this.aX);
        a(this.T, this.i, this.m, this.x, this.au, this.U, this.aa, this.aT, this.ad, this.ag, this.aL, this.aC, this.ai, this.aw, this.R, this.ao, this.ay, this.aB, this.aO);
        a(this.aF, this.aA, this.I, this.az, this.S, this.K, this.k, this.ba, this.aV, this.al, this.bb, this.P, this.N, this.aU, this.aH, this.as, this.aD, this.ar, this.ap, this.aJ, this.y, this.J, this.F, this.g, this.aI, this.aN, this.aY, this.w, this.p, this.ak, this.s, this.aM, this.a, this.aG, this.aZ, this.an, this.r, this.at, this.j, this.M, this.z, this.E);
        super.setup();
    }

    @Generated
    public MaceHelper H() {
        return this.H;
    }

    @Generated
    public AutoTotem V() {
        return this.V;
    }

    @Generated
    public ProjectileHelper D() {
        return this.D;
    }

    @Generated
    public WindHop aW() {
        return this.aW;
    }

    @Generated
    public Interface_2 bd() {
        return this.bd;
    }

    @Generated
    public NoCommands am() {
        return this.am;
    }

    @Generated
    public NoFriendDamage getNoFriendDamage() {
        return this.noFriendDamage;
    }

    @Generated
    public NoFriendDamage ac() {
        return this.noFriendDamage;
    }

    @Generated
    public BlockESP getBlockESP() {
        return this.blockESP;
    }

    @Generated
    public Aura B() {
        return this.B;
    }

    @Generated
    public TriggerBot X() {
        return this.X;
    }

    @Generated
    public Animations Q() {
        return this.Q;
    }

    @Generated
    public ServerAssistant aj() {
        return this.aj;
    }

    @Generated
    public StreamerMode aE() {
        return this.aE;
    }

    @Generated
    public ScreenWalk f() {
        return this.f;
    }

    @Generated
    public FreeCamera h() {
        return this.h;
    }

    @Generated
    public AutoDodge l() {
        return this.l;
    }

    @Generated
    public NoCrouch n() {
        return this.n;
    }

    @Generated
    public Sprint o() {
        return this.o;
    }

    @Generated
    public NoSlowDown q() {
        return this.q;
    }

    @Generated
    public ElytraTarget G() {
        return this.G;
    }

    @Generated
    public NoPush O() {
        return this.O;
    }

    @Generated
    public SafeWalk ah() {
        return this.ah;
    }

    @Generated
    public WaterJump aq() {
        return this.aq;
    }

    @Generated
    public AirStuck av() {
        return this.av;
    }

    @Generated
    public NoDelay ax() {
        return this.ax;
    }

    @Generated
    public Fly aQ() {
        return this.aQ;
    }

    @Generated
    public WallClimb aR() {
        return this.aR;
    }

    @Generated
    public Scaffold aS() {
        return this.aS;
    }

    @Generated
    public FastBreak aX() {
        return this.aX;
    }

    @Generated
    public AutoSwap L() {
        return this.autoSwap;
    }

    @Generated
    public SwingAnimation R() {
        return this.R;
    }

    @Generated
    public SeeInvisibles T() {
        return this.T;
    }

    @Generated
    public EntityBox U() {
        return this.U;
    }

    @Generated
    public EntityESP aa() {
        return this.aa;
    }

    @Generated
    public ShaderESP ad() {
        return this.ad;
    }

    @Generated
    public ItemPhysic ag() {
        return this.ag;
    }

    @Generated
    public Removals ai() {
        return this.ai;
    }

    @Generated
    public ViewModel ao() {
        return this.ao;
    }

    @Generated
    public Crosshair au() {
        return this.au;
    }

    @Generated
    public ShulkerPreview aw() {
        return this.aw;
    }

    @Generated
    public ChinaHat ay() {
        return this.ay;
    }

    @Generated
    public AspectRatio aB() {
        return this.aB;
    }

    @Generated
    public Predictions aC() {
        return this.aC;
    }

    @Generated
    public WardenESP i() {
        return this.i;
    }

    @Generated
    public SoundESP m() {
        return this.m;
    }

    @Generated
    public BoardSpoofer x() {
        return this.x;
    }

    @Generated
    public Pointers aL() {
        return this.aL;
    }

    @Generated
    public FullBright aO() {
        return this.aO;
    }

    @Generated
    public HandsShader aT() {
        return this.aT;
    }

    @Generated
    public AutoExplosion C() {
        return this.autoExplosion;
    }
    @Generated
    public BlockESP ab() {
        return this.blockESP;
    }
    @Generated
    public NoServerDesync ae() {
        return this.noServerDesync;
    }
    @Generated
    public TapeMouse u() {
        return this.tapeMouse;
    }

    @Generated
    public Ambience aF() {
        return this.aF;
    }

    @Generated
    public AncientFarmer aA() {
        return this.aA;
    }

    @Generated
    public AntiAFK I() {
        return this.I;
    }

    @Generated
    public AppleFarmer az() {
        return this.az;
    }

    @Generated
    public AucReissue S() {
        return this.S;
    }

    @Generated
    public AutoAccept K() {
        return this.K;
    }

    @Generated
    public AutoAuth k() {
        return this.k;
    }

    @Generated
    public AutoBuy ba() {
        return this.ba;
    }

    @Generated
    public AutoEXP aP() {
        return this.autoEXP;
    }

    @Generated
    public AutoEat aV() {
        return this.aV;
    }

    @Generated
    public AutoFish al() {
        return this.al;
    }

    @Generated
    public AutoLeave bb() {
        return this.bb;
    }

    @Generated
    public AutoRespawn P() {
        return this.P;
    }

    @Generated
    public AutoTool N() {
        return this.N;
    }

    @Generated
    public AutoWarden aU() {
        return this.aU;
    }

    @Generated
    public CaptchaSolver aH() {
        return this.aH;
    }

    @Generated
    public ChatHelper as() {
        return this.as;
    }

    @Generated
    public ChestStealer aD() {
        return this.aD;
    }

    @Generated
    public ClanUpgrader ar() {
        return this.ar;
    }

    @Generated
    public ClickAction ap() {
        return this.ap;
    }

    @Generated
    public Collector_2 aJ() {
        return this.aJ;
    }

    @Generated
    public Communication y() {
        return this.y;
    }

    @Generated
    public DeathCoords J() {
        return this.J;
    }

    @Generated
    public ElytraHelper F() {
        return this.F;
    }

    @Generated
    public FakeLags g() {
        return this.g;
    }

    @Generated
    public FastEXP aI() {
        return this.aI;
    }

    @Generated
    public FastLoad aN() {
        return this.aN;
    }

    @Generated
    public FunDeliver aY() {
        return this.aY;
    }

    @Generated
    public ItemHelper aK() {
        return this.itemHelper;
    }

    @Generated
    public ItemScroller w() {
        return this.w;
    }

    @Generated
    public LockSlot p() {
        return this.p;
    }

    @Generated
    public MineAssistant ak() {
        return this.ak;
    }

    @Generated
    public NoInteract s() {
        return this.s;
    }

    @Generated
    public NoServerPack v() {
        return this.noServerPack;
    }

    @Generated
    public NoSlotChange af() {
        return this.noSlotChange;
    }

    @Generated
    public Nuker aM() {
        return this.aM;
    }

    @Generated
    public OpenWalls a() {
        return this.a;
    }

    @Generated
    public PortalBypass aG() {
        return this.aG;
    }

    @Generated
    public PotionThrower aZ() {
        return this.aZ;
    }

    @Generated
    public ServerJoiner an() {
        return this.an;
    }

    @Generated
    public SoundReducer r() {
        return this.r;
    }

    @Generated
    public Sounds at() {
        return this.at;
    }

    @Generated
    public Structures j() {
        return this.j;
    }

    @Generated
    public ThirdPerson M() {
        return this.M;
    }

    @Generated
    public UseTracker z() {
        return this.z;
    }

    @Generated
    public Velocity bc() {
        return this.velocity;
    }

    @Generated
    public XRay E() {
        return this.E;
    }

    @Generated
    public ShiftTAP A() {
        return this.shiftTAP;
    }

    @Generated
    public AimAssistant Y() {
        return this.aimAssistant;
    }

    @Generated
    public AntiBot Z() {
        return this.antiBot;
    }

    @Generated
    public AutoArmor W() {
        return this.autoArmor;
    }

    @Generated
    public HitBoxes t() {
        return this.hitBoxes;
    }

    @Override
    public File d() {
        return this.b;
    }

    @Override
    protected String b() {
        return "default.json";
    }

    @Override
    protected List<Module> a(String json) {
        if (json == null || json.isBlank() || json.trim().startsWith("[")) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(json);
        JSONArray jSONArrayI = jSONObject.i("modules");
        if (jSONArrayI != null) {
            for (int i = 0; i < jSONArrayI.a(); i++) {
                JSONObject jSONObjectJ = jSONArrayI.j(i);
                if (jSONObjectJ != null) {
                    String strL = jSONObjectJ.l("name");
                    if (strL != null) {
                        for (Module module : e()) {
                            if (module.j().equalsIgnoreCase(strL)) {
                                a(jSONObjectJ, module);
                                break;
                            }
                        }
                    }
                }
            }
        }
        return new ArrayList<>(e());
    }

    @Override
    protected String a(List<Module> data) {
        JSONArray jSONArray = new JSONArray();
        if (data != null) {
            for (Module module : data) {
                if (module != null) {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.c("name", module.j());
                    jSONObject.b("activated", module.m());
                    jSONObject.b("bind", module.p());
                    JSONObject jSONObject2 = new JSONObject();
                    for (Setting<?> setting : module.e()) {
                        if (setting != null && setting.j()) {
                            jSONObject2.c(setting.i(), ConverterUtil.a(setting));
                        }
                    }
                    jSONObject.c("settings", jSONObject2);
                    jSONArray.a(jSONObject);
                }
            }
        }
        JSONObject jSONObject4 = new JSONObject();
        jSONObject4.c("modules", jSONArray);
        return jSONObject4.a(2);
    }

    public static void a(JSONObject obj, Module module) {
        module.a(obj.a("activated", false));
        module.a(obj.a("bind", -1));
        if (obj.m("settings")) {
            JSONObject settingsObj = obj.j("settings");
            for (Setting<?> setting : module.e()) {
                if (settingsObj.m(setting.i())) {
                    ConverterUtil.a(setting, settingsObj.a(setting.i()));
                }
            }
        }
    }

    public void b(String configName) {
        try {
            Files.writeString(new File(d(), configName + ".json").toPath(), a(this.d), new OpenOption[0]);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean c(String str) {
        try {
            File file = new File(d(), str + ".json");
            if (!file.exists()) {
                return false;
            }
            List<Module> listA = a(Files.readString(file.toPath()));
            if (listA != null) {
                this.d.clear();
                this.d.addAll(listA);
                return true;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean d(String configName) {
        File configFile = new File(d(), configName + ".json");
        if (configFile.exists() && !configName.equals(b())) {
            return configFile.delete();
        }
        return false;
    }

    @EventTarget
    public void a(KeyEvent event) {
        int action = event.d();
        int key = event.b();

        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT && action == 1) {
            if (Interface.aM_.currentScreen == null || Interface.aM_.currentScreen instanceof aethereal.ui.screen.MainScreen) {
                Interface.aM_.setScreen(new GUIScreen(Text.literal("GUI"), Interface.aM_.currentScreen));
                event.a(true);
                return;
            }
        }

        for (Module module : e()) {
            if (module.p() != -1 && module.p() == key && action == 1) {
                module.a();
            }
            if (module.m()) {
                for (Setting<?> setting : module.e()) {
                    if (setting instanceof BindSetting) {
                        BindSetting bind = (BindSetting) setting;
                        if (bind.e().get().booleanValue() && bind.c().intValue() != -1 && bind.c().intValue() == key) {
                            if (action == 1) {
                                bind.k().execute();
                            } else if (action == 0 && bind.m() == 0) {
                                bind.l().execute();
                            }
                        }
                    }
                }
            }
        }
    }

    public void a(Module... modules) {
        Collections.addAll(this.d, modules);
    }
}
