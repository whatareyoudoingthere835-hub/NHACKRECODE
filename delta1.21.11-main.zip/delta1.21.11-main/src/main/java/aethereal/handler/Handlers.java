package aethereal.handler;

public final class Handlers {
    private static final InventoryHandler INVENTORY = new InventoryHandler();
    private static final UseableHandler USEABLE = new UseableHandler();
    private static final RotationProcessor ROTATION = new RotationProcessor();
    private static final aethereal.module.combat.AuraHandler AURA = new aethereal.module.combat.AuraHandler();
    private static final StopHandler STOP = new StopHandler();

    public static InventoryHandler inventory() {
        return INVENTORY;
    }

    public static UseableHandler useable() {
        return USEABLE;
    }

    public static RotationProcessor rotation() {
        return ROTATION;
    }

    public static aethereal.module.combat.AuraHandler aura() {
        return AURA;
    }

    public static StopHandler stop() {
        return STOP;
    }

    private Handlers() {
    }
}
