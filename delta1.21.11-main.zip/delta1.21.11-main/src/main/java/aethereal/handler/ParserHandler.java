package aethereal.handler;

import aethereal.handler.Handler_2;

@Handler_2
public class ParserHandler extends BaseHandler {
}
