package aethereal.handler;

import aethereal.lib.javassist.TokenId;
import aethereal.handler.Handler_2;
import aethereal.util.StringUtils;
import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.util.ChatUtil;
import aethereal.util.ServerUtil;

import aethereal.core.Client;
import aethereal.core.EventTarget;
import aethereal.core.GlobalEvent;
import aethereal.core.Interface;
import aethereal.event.ConsumeEvent;
import aethereal.event.CooldownEvent;
import aethereal.event.PacketEvent;
import aethereal.handler.BaseHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.StreamSupport;
import lombok.Generated;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.text.Text;
import net.minecraft.text.HoverEvent;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.network.packet.c2s.play.ChatCommandSignedC2SPacket;

@Handler_2
public class MainHandler extends BaseHandler implements Interface {
    private ServerInfo b;
    private String c;

    @Generated
    public void a(ServerInfo serverInfo) {
        this.b = serverInfo;
    }

    @Generated
    public ServerInfo a() {
        return this.b;
    }

    @Generated
    public void a(String confirm) {
        this.c = confirm;
    }

    @Generated
    public String b() {
        return this.c;
    }

    @EventTarget
    public void a(PacketEvent event) throws MatchException {
        String strComp_2532;
        HoverEvent hover;
        Text hoverText;

        if (event.c() && event.d() instanceof GameMessageS2CPacket packet) {
            for (Text component : a(packet.content())) {
                if (component.getString().contains("Подробнее") && (hover = component.getStyle().getHoverEvent()) != null && hover.getAction() == HoverEvent.Action.SHOW_TEXT && hover instanceof HoverEvent.ShowText showTextEvent && (hoverText = showTextEvent.value()) != null) {
                    List<String> lines = Arrays.stream(hoverText.getString().split(StringUtils.d)).map((v0) -> {
                        return v0.trim();
                    }).toList();
                    String userLine = lines.stream().filter(line -> {
                        return line.startsWith("[") && line.contains("]");
                    }).findFirst().orElse(null);
                    String reason = (String) lines.stream().filter(line2 -> {
                        return line2.startsWith("Причина:");
                    }).map(line3 -> {
                        return line3.substring("Причина:".length()).trim();
                    }).findFirst().orElse(null);
                    String expiration = (String) lines.stream().filter(line4 -> {
                        return line4.startsWith("Окончание:");
                    }).map(line5 -> {
                        return line5.substring("Окончание:".length()).trim();
                    }).findFirst().orElse(null);
                    if (userLine != null && reason != null && expiration != null) {
                        aM_.player.sendMessage(Text.literal("§c[♨] §6" + userLine.substring(userLine.indexOf(93) + 1).trim() + "§e забанен с причиной: §c\"" + reason + "\"§e на §c\"" + expiration + "\" ").append(ChatUtil.a((Object) "&c[Подробнее]", hoverText)), false);
                        event.a(true);
                        break;
                    }
                }
            }
        }
        if (event.b()) {
            String message = event.d() instanceof ChatMessageC2SPacket chatPacket ? chatPacket.chatMessage()
                    : event.d() instanceof CommandExecutionC2SPacket commandPacket ? commandPacket.command()
                    : event.d() instanceof ChatCommandSignedC2SPacket signedPacket ? signedPacket.command()
                    : null;
            if (message != null && aM_.player != null) {
                int sell = message.trim().toLowerCase(Locale.ROOT).startsWith("/ah sell") ? 8 : message.trim().toLowerCase(Locale.ROOT).startsWith("ah sell") ? 7 : -1;
                if (sell >= 0 && message.trim().endsWith("!")) {
                    String body = message.trim().substring(sell, message.trim().length() - 1).trim();
                    int numEnd = 0;
                    while (numEnd < body.length() && (Character.isDigit(body.charAt(numEnd)) || body.charAt(numEnd) == '.')) {
                        numEnd++;
                    }
                    if (numEnd > 0) {
                        ClientPlayNetworkHandler class_634Var = aM_.player.networkHandler;
                        long jRound = Math.round(Double.parseDouble(body.substring(0, numEnd)) * ((double) Math.max(1, aM_.player.getMainHandStack().getCount())));

                        class_634Var.sendChatMessage("/ah sell " + jRound);
                        event.a(true);
                        return;
                    }
                }
            }
            if (message != null && aM_.player != null) {
                int pay = message.trim().toLowerCase(Locale.ROOT).startsWith("/pay ") ? 5 : message.trim().toLowerCase(Locale.ROOT).startsWith("pay ") ? 4 : -1;
                if (pay >= 0) {
                    String[] parts = message.trim().substring(pay).trim().split("\\s+");
                    long balance = ServerUtil.a.e();
                    if (parts.length == 2 && parts[1].equalsIgnoreCase("all") && balance > 0) {
                        aM_.player.networkHandler.sendChatMessage("/pay " + parts[0] + " " + balance);
                        event.a(true);
                        return;
                    }
                }
            }
            if (message != null) {
                String trimmed = message.trim();
                boolean dangerous = trimmed.toLowerCase().startsWith("hub") || trimmed.toLowerCase().startsWith("an");
                if (!ServerUtil.e() || !dangerous) {
                    this.c = null;
                    return;
                }
                if (trimmed.equals(this.c)) {
                    this.c = null;
                    return;
                }
                this.c = trimmed;
                ChatUtil.a((Object) "&cВы находитесь в PvP режиме! &7Чтобы отправить эту команду, повторите её");
                Delta.h().d().u().f().d();
                event.a(true);
            }
        }
    }

    @EventTarget
    public void a(CooldownEvent event) {
        if (ServerUtil.a.b()) {
            if ((event.b() == Items.WIND_CHARGE && event.c() <= 10) || (event.b() == Items.CHORUS_FRUIT && event.c() <= 20)) {
                event.a(true);
            }
        }
    }

    private List<Text> a(Text text) {
        List<Text> components = new ArrayList<>();
        components.add(text);
        for (Text sibling : text.getSiblings()) {
            components.addAll(a(sibling));
        }
        return components;
    }

    @EventTarget
    public void a(ConsumeEvent event) {
        PotionContentsComponent contents;
        if (ServerUtil.e()) {
            if ((ServerUtil.a.a() || ServerUtil.d.a()) && event.b().getItem() == Items.POTION && (contents = (PotionContentsComponent) event.b().get(DataComponentTypes.POTION_CONTENTS)) != null) {
                boolean heal = StreamSupport.stream(contents.getEffects().spliterator(), false).anyMatch(effect -> {
                    return effect.getEffectType() == StatusEffects.INSTANT_HEALTH;
                });
                if (heal) {
                    ((aethereal.mixin.IItemCooldownManager) (Object) aM_.player.getItemCooldownManager()).setHealCooldown(TokenId.au_);
                }
            }
        }
    }

    @EventTarget
    public void a(GlobalEvent globalEvent) {
        String str;
        if (aM_.player != null || (aM_.currentScreen instanceof MultiplayerScreen)) {
            Client clientF = Delta.h().f();
            Object[] objArr = new Object[6];
            objArr[0] = "uuid";
            objArr[1] = aM_.player != null ? aM_.player.getUuid() : null;
            objArr[2] = "minecraft";
            objArr[3] = aM_.getSession().getUsername();
            objArr[4] = "server";
            if (ServerUtil.a.a()) {
                str = "funtime";
            } else if (ServerUtil.b.a()) {
                str = "holyworld";
            } else {
                str = ServerUtil.d.a() ? "spookytime" : null;
            }
            objArr[5] = str;
            clientF.a(true, "minecraft", objArr);
        }
    }
}
