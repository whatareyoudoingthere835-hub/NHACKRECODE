package aethereal.handler;

import aethereal.handler.Handler_2;
import aethereal.core.EventTarget;
import aethereal.event.PacketEvent;
import aethereal.handler.BaseHandler;

import lombok.Generated;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;

@Handler_2
public class TPSHandler extends BaseHandler {
    private long a = -1;
    private long b = -1;
    private float c = 20.0f;

    @Generated
    public float a() {
        return this.c;
    }

    @EventTarget
    public void a(PacketEvent event) {

        if (event.c() && event.d() instanceof WorldTimeUpdateS2CPacket packet) {
            long now = System.currentTimeMillis();
            long worldTime = packet.time();
            if (this.b > 0 && worldTime > this.a) {
                long ticksDelta = worldTime - this.a;
                long msDelta = now - this.b;
                this.c = Math.min(20.0f, (ticksDelta * 1000.0f) / msDelta);
            }
            this.b = now;
            this.a = worldTime;
        }
    }
}
