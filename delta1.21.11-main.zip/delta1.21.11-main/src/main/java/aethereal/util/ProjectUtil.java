package aethereal.util;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;

import aethereal.core.Interface;

import lombok.Generated;
import platform.inject.invokers.GameRendererInvoker;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Vector2f;
import org.joml.Vector3f;

public class ProjectUtil implements Interface {
    @Generated
    private ProjectUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Vector2f a(double x, double y, double z) {

        net.minecraft.client.render.Camera camera = aM_.gameRenderer.getCamera();
        Quaternionf yawQuat = RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw());
        Quaternionf pitchQuat = RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch());
        Quaternionf cameraRotation = yawQuat.mul(pitchQuat, new Quaternionf());
        Quaternionf cameraRotation2 = cameraRotation.conjugate(new Quaternionf());
        Vec3d camPos = camera.getCameraPos();
        Vector3f result3f = new Vector3f((float) (camPos.x - x), (float) (camPos.y - y), (float) (camPos.z - z));
        result3f.rotate(cameraRotation2);
        return a(result3f, ((GameRendererInvoker) (Object) aM_.gameRenderer).invokeGetFov(camera, aM_.getRenderTickCounter().getTickProgress(false), true));
    }

    private static Vector2f a(Vector3f result3f, double fov) {
        float realAspect = aM_.getWindow().getFramebufferWidth() / aM_.getWindow().getFramebufferHeight();
        float modifiedAspect = realAspect;
        double scaleFactorY = ((double) (aM_.getWindow().getScaledHeight() / 2.0f)) / (((double) result3f.z) * Math.tan(Math.toRadians(fov / 2.0d)));
        double scaleFactorX = (scaleFactorY * ((double) realAspect)) / ((double) modifiedAspect);
        return result3f.z < 0.0f ? new Vector2f((float) ((((double) (-result3f.x())) * scaleFactorX) + ((double) (aM_.getWindow().getScaledWidth() / 2.0f))), (float) (((double) (aM_.getWindow().getScaledHeight() / 2.0f)) - (((double) result3f.y()) * scaleFactorY))) : new Vector2f(Float.MAX_VALUE, Float.MAX_VALUE);
    }

    public static float[] a(Box box) {
        float minX = Float.MAX_VALUE;
        float minY = Float.MAX_VALUE;
        float maxX = -3.4028235E38f;
        float maxY = -3.4028235E38f;
        for (int corner = 0; corner < 8; corner++) {
            double x = (corner & 1) == 0 ? box.minX : box.maxX;
            double y = (corner & 2) == 0 ? box.minY : box.maxY;
            double z = (corner & 4) == 0 ? box.minZ : box.maxZ;
            Vector2f screen = a(x, y, z);
            if (screen.x() == Float.MAX_VALUE) {
                return null;
            }
            minX = Math.min(minX, screen.x());
            minY = Math.min(minY, screen.y());
            maxX = Math.max(maxX, screen.x());
            maxY = Math.max(maxY, screen.y());
        }
        if (maxX <= minX || maxY <= minY) {
            return null;
        }
        return new float[]{minX, minY, maxX, maxY};
    }

    public static boolean a(Vector2f screen) {
        return screen.x() != Float.MAX_VALUE && screen.y() != Float.MAX_VALUE && screen.x() >= 0.0f && screen.y() >= 0.0f && screen.x() <= ((float) aM_.getWindow().getScaledWidth()) && screen.y() <= ((float) aM_.getWindow().getScaledHeight());
    }

    public static int getTextureGlId(net.minecraft.util.Identifier id) {
        if (id == null) return 0;
        try {
            var tex = aM_.getTextureManager().getTexture(id);
            if (tex != null && tex.getGlTexture() instanceof net.minecraft.client.texture.GlTexture glTexture) {
                return glTexture.getGlId();
            }
        } catch (Throwable ignored) {}
        return 0;
    }
}
