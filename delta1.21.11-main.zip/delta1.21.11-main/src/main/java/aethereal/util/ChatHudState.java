package aethereal.util;

public final class ChatHudState {

    public static float lineProgress = 1.0f;

    private ChatHudState() {
    }
}
