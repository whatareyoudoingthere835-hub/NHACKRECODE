package aethereal.autobuy;

import static aethereal.core.Interface.aM_;
import aethereal.core.Interface;
import aethereal.render.ColorUtil;
import aethereal.render.ImmediateRenderer;

import aethereal.config.BaseProcessor;

import aethereal.api.Compile;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;

public class BatchProcessor extends BaseProcessor {
    private static final float PIXEL_WORLD_SCALE = 0.0016f;
    private final List<b> b = new ArrayList();
    private final List<a> c = new ArrayList();

    @Override
    @Compile
    public void setup() {
        this.b.clear();
        this.c.clear();
    }

    @Override
    public void unSetup() {
        this.b.clear();
        this.c.clear();
    }

    public void a(b task) {
        this.b.add(task);
    }

    public void a(a task) {
        this.c.add(task);
    }

    public void a() {
        if (this.c.isEmpty()) {
            return;
        }
        int quadCount = 0;
        for (a task : this.c) {
            quadCount += task.j();
        }
        if (quadCount == 0) {
            this.c.clear();
            return;
        }
        ByteBuffer buffer = MemoryUtil.memAlloc(quadCount * 6 * 16);
        for (a task : this.c) {
            task.a(buffer);
        }
        buffer.flip();
        ImmediateRenderer.draw2D(VertexFormat.DrawMode.TRIANGLES, buffer, buffer.remaining() / 16);
        MemoryUtil.memFree(buffer);
        this.c.clear();
    }

    public void b() {
        if (this.b.isEmpty()) {
            return;
        }
        Camera camera = aM_.gameRenderer.getCamera();
        Vec3d cam = camera.getCameraPos();
        Matrix4f modelView = this.b.getFirst().a.getPositionMatrix();
        int vertexCount = 0;
        for (b task : this.b) {
            vertexCount += task.h();
        }
        if (vertexCount == 0) {
            this.b.clear();
            return;
        }
        ByteBuffer buffer = MemoryUtil.memAlloc(vertexCount * 16);
        for (b task : this.b) {
            task.a(buffer, cam);
        }
        buffer.flip();
        ImmediateRenderer.drawWorld(VertexFormat.DrawMode.TRIANGLES, modelView, buffer, buffer.remaining() / 16);
        MemoryUtil.memFree(buffer);
        this.b.clear();
    }

    public static class b {
        final MatrixStack.Entry a;
        final Box b;
        final int c;
        final float d;
        final Vec3d e;
        final Vec3d f;
        final Vec3d g;
        final boolean h;

        public b(MatrixStack.Entry entry, Box box, int color, float width) {
            this.a = entry;
            this.b = box.expand(9.999995420800828E-4d);
            this.c = color;
            this.d = width;
            this.e = null;
            this.f = null;
            this.g = null;
            this.h = false;
        }

        public b(MatrixStack.Entry entry, Vec3d start, Vec3d end, Vec3d control, int color, float width) {
            this.a = entry;
            this.b = null;
            this.c = color;
            this.d = width;
            this.e = start;
            this.f = end;
            this.g = control;
            this.h = true;
        }

        public static b a(MatrixStack matrices, Box box, int color, float width) {
            return new b(matrices.peek(), box, color, width);
        }

        public static b a(MatrixStack matrices, Vec3d start, Vec3d end, Vec3d control, int color, float width) {
            return new b(matrices.peek(), start, end, control, color, width);
        }

        private int h() {

            return this.h ? 32 * 6 : (this.b == null ? 12 * 6 : 12 * 6 + 36);
        }

        private void a(ByteBuffer buffer, Vec3d cam) {
            if (this.h) {
                c(buffer, cam);
                return;
            }
            float x0 = (float) (this.b.minX - cam.x);
            float y0 = (float) (this.b.minY - cam.y);
            float z0 = (float) (this.b.minZ - cam.z);
            float x1 = (float) (this.b.maxX - cam.x);
            float y1 = (float) (this.b.maxY - cam.y);
            float z1 = (float) (this.b.maxZ - cam.z);
            float dist = MathHelper.sqrt((x0 + x1) * (x0 + x1) + (y0 + y1) * (y0 + y1) + (z0 + z1) * (z0 + z1)) * 0.5f;
            float half = Math.max(0.004f, this.d * PIXEL_WORLD_SCALE * dist * 0.5f);
            float[][] edges = {
                    {x0, y0, z0, x1, y0, z0}, {x0, y0, z0, x0, y1, z0}, {x0, y0, z0, x0, y0, z1},
                    {x1, y1, z1, x0, y1, z1}, {x1, y1, z1, x1, y0, z1}, {x1, y1, z1, x1, y1, z0},
                    {x1, y0, z0, x1, y1, z0}, {x1, y0, z0, x0, y0, z1}, {x0, y1, z0, x1, y1, z0},
                    {x0, y1, z0, x0, y1, z1}, {x0, y0, z1, x1, y0, z1}, {x0, y0, z1, x0, y1, z1}};
            for (float[] edge : edges) {
                a(buffer, edge[0], edge[1], edge[2], edge[3], edge[4], edge[5], half, this.c);
            }
        }

        private void c(ByteBuffer buffer, Vec3d cam) {
            Vec3d prev = this.e;
            for (int i = 1; i <= 32; i++) {
                float t = i / 32.0f;
                float oneMinusT = 1.0f - t;
                Vec3d point = new Vec3d((((double) (oneMinusT * oneMinusT)) * this.e.x) + (((double) (2.0f * oneMinusT * t)) * this.g.x) + (((double) (t * t)) * this.f.x),
                        (((double) (oneMinusT * oneMinusT)) * this.e.y) + (((double) (2.0f * oneMinusT * t)) * this.g.y) + (((double) (t * t)) * this.f.y),
                        (((double) (oneMinusT * oneMinusT)) * this.e.z) + (((double) (2.0f * oneMinusT * t)) * this.g.z) + (((double) (t * t)) * this.f.z));
                float dist = (float) Math.max(3.0d, prev.distanceTo(aM_.player.getEntityPos()));
                float half = Math.max(0.004f, this.d * PIXEL_WORLD_SCALE * dist * 0.5f);
                a(buffer,
                        (float) (prev.x - cam.x), (float) (prev.y - cam.y), (float) (prev.z - cam.z),
                        (float) (point.x - cam.x), (float) (point.y - cam.y), (float) (point.z - cam.z),
                        half, this.c);
                prev = point;
            }
        }

        private static void a(ByteBuffer buffer, float ax, float ay, float az, float bx, float by, float bz, float half, int color) {
            int[] rgba = ColorUtil.b(color);
            float dx = bx - ax;
            float dy = by - ay;
            float dz = bz - az;
            float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1.0E-5f) {
                return;
            }
            float mx = (ax + bx) * 0.5f;
            float my = (ay + by) * 0.5f;
            float mz = (az + bz) * 0.5f;
            float vx = mx;
            float vy = my;
            float vz = mz;
            float vLen = MathHelper.sqrt(vx * vx + vy * vy + vz * vz);
            if (vLen < 1.0E-5f) {
                vx = 0.0f;
                vy = -1.0f;
                vz = 0.0f;
                vLen = 1.0f;
            }
            float sx = (dy * vz - dz * vy) / len;
            float sy = (dz * vx - dx * vz) / len;
            float sz = (dx * vy - dy * vx) / len;
            float sl = MathHelper.sqrt(sx * sx + sy * sy + sz * sz);
            if (sl < 1.0E-5f) {
                sx = 1.0f;
                sy = 0.0f;
                sz = 0.0f;
                sl = 1.0f;
            }
            sx = sx / sl * half;
            sy = sy / sl * half;
            sz = sz / sl * half;
            ImmediateRenderer.putVertexColor(buffer, ax + sx, ay + sy, az + sz, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, bx + sx, by + sy, bz + sz, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, bx - sx, by - sy, bz - sz, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, ax + sx, ay + sy, az + sz, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, bx - sx, by - sy, bz - sz, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, ax - sx, ay - sy, az - sz, rgba[0], rgba[1], rgba[2], rgba[3]);
        }
    }

    public static class a {
        private static final int k = ColorUtil.a(0, 0, 0, 255);
        private static final float l = 0.5f;
        final Matrix4f a;
        final float b;
        final float c;
        final float d;
        final float e;
        final int f;
        final boolean g;
        final boolean h;
        final float i;
        final int j;

        public a(Matrix4f matrix, float minX, float minY, float maxX, float maxY, int color, boolean corners, boolean healthBar, float healthPercent, int healthColor) {
            this.a = matrix;
            this.b = minX;
            this.c = minY;
            this.d = maxX;
            this.e = maxY;
            this.f = color;
            this.g = corners;
            this.h = healthBar;
            this.i = healthPercent;
            this.j = healthColor;
        }

        private int j() {
            return 16 + (this.h ? 2 : 0);
        }

        void a(ByteBuffer buffer) {
            float fMin = this.g ? Math.min(this.d - this.b, this.e - this.c) * 0.25f : Math.min(this.d - this.b, this.e - this.c) * l;
            float length = fMin;
            int pass = 0;
            while (pass < 2) {
                for (int corner = 0; corner < 4; corner++) {
                    float cornerX = (corner & 1) == 0 ? this.b : this.d;
                    float cornerY = (corner & 2) == 0 ? this.c : this.e;
                    float directionX = (corner & 1) == 0 ? 1.0f : -1.0f;
                    float directionY = (corner & 2) == 0 ? 1.0f : -1.0f;
                    a(buffer, cornerX, cornerY, directionX * length, 0.0f, pass == 0);
                    a(buffer, cornerX, cornerY, 0.0f, directionY * length, pass == 0);
                }
                pass++;
            }
            if (this.h) {
                float height = this.e - this.c;
                float x = (this.b - 2.0f) - l;
                a(buffer, x - l, this.c - l, 1.5f, height + 1.5f, k);
                a(buffer, x, this.c + (height * (1.0f - this.i)), l, (height * this.i) + l, this.j);
            }
        }

        private void a(ByteBuffer buffer, float x, float y, float lengthX, float lengthY, boolean outline) {
            float left = Math.min(x, x + lengthX) - (lengthX == 0.0f ? 0.25f : 0.0f);
            float top = Math.min(y, y + lengthY) - (lengthY == 0.0f ? 0.25f : 0.0f);
            float width = lengthX == 0.0f ? l : Math.abs(lengthX);
            float height = lengthY == 0.0f ? l : Math.abs(lengthY);
            if (outline) {
                a(buffer, left - l, top - l, width + 1.0f, height + 1.0f, k);
            } else {
                a(buffer, left, top, width, height, this.f);
            }
        }

        private void a(ByteBuffer buffer, float x, float y, float width, float height, int color) {
            int[] rgba = ColorUtil.b(color);
            ImmediateRenderer.putVertexColor(buffer, x, y, 0.0f, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, x, y + height, 0.0f, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, x + width, y + height, 0.0f, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, x, y, 0.0f, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, x + width, y + height, 0.0f, rgba[0], rgba[1], rgba[2], rgba[3]);
            ImmediateRenderer.putVertexColor(buffer, x + width, y, 0.0f, rgba[0], rgba[1], rgba[2], rgba[3]);
        }
    }
}
