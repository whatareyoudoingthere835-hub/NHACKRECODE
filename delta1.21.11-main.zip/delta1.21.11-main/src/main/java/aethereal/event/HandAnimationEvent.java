package aethereal.event;

import aethereal.core.Event;
import aethereal.core.IEvent;

import lombok.Generated;
import net.minecraft.util.Hand;
import net.minecraft.client.util.math.MatrixStack;

public class HandAnimationEvent extends Event implements IEvent {
    private final MatrixStack a;
    private final Hand b;
    private final float c;
    private final int d;

    @Generated
    public HandAnimationEvent(MatrixStack matrices, Hand hand, float swingProgress, int armX) {
        this.a = matrices;
        this.b = hand;
        this.c = swingProgress;
        this.d = armX;
    }

    @Generated
    public MatrixStack b() {
        return this.a;
    }

    @Generated
    public Hand c() {
        return this.b;
    }

    @Generated
    public float d() {
        return this.c;
    }

    @Generated
    public int e() {
        return this.d;
    }
}
