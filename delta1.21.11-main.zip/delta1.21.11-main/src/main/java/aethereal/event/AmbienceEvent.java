package aethereal.event;

import aethereal.core.Event;
import aethereal.core.IEvent;

import lombok.Generated;
import net.minecraft.world.biome.Biome;
import net.minecraft.client.render.Camera;

public class AmbienceEvent {

    public static class c extends Event implements IEvent {
        private long a;

        @Generated
        public void a(long time) {
            this.a = time;
        }

        @Generated
        public c(long time) {
            this.a = time;
        }

        @Generated
        public long b() {
            return this.a;
        }
    }

    public static class a extends Event implements IEvent {
        private float a;
        private float b;
        private float c;
        private float d;

        @Generated
        public void a(float red) {
            this.a = red;
        }

        @Generated
        public void b(float green) {
            this.b = green;
        }

        @Generated
        public void c(float blue) {
            this.c = blue;
        }

        @Generated
        public void d(float alpha) {
            this.d = alpha;
        }

        @Generated
        public a(float red, float green, float blue, float alpha) {
            this.a = red;
            this.b = green;
            this.c = blue;
            this.d = alpha;
        }

        @Generated
        public float b() {
            return this.a;
        }

        @Generated
        public float c() {
            return this.b;
        }

        @Generated
        public float d() {
            return this.c;
        }

        @Generated
        public float e() {
            return this.d;
        }
    }

    public static class b extends Event implements IEvent {
        private net.minecraft.client.render.Camera a;
        private net.minecraft.client.render.fog.FogData b;
        private org.joml.Vector4f c;

        public b(net.minecraft.client.render.Camera camera, net.minecraft.client.render.fog.FogData fogData, org.joml.Vector4f color) {
            this.a = camera;
            this.b = fogData;
            this.c = color;
        }

        public net.minecraft.client.render.Camera b() {
            return this.a;
        }

        public net.minecraft.client.render.fog.FogData c() {
            return this.b;
        }

        public org.joml.Vector4f d() {
            return this.c;
        }

        public void a(float red, float green, float blue, float alpha) {
            this.c.set(red, green, blue, alpha);
        }
    }

    public static class d extends Event implements IEvent {
        private final aethereal.event.AmbienceEvent.d.a a;
        private float b;
        private Biome.Precipitation c;

        public enum a {
            RAIN_GRADIENT,
            THUNDER_GRADIENT,
            PRECIPITATION_PARTICLES,
            PRECIPITATION
        }

        @Generated
        public aethereal.event.AmbienceEvent.d.a b() {
            return this.a;
        }

        @Generated
        public float c() {
            return this.b;
        }

        @Generated
        public void a(float floatValue) {
            this.b = floatValue;
        }

        @Generated
        public Biome.Precipitation d() {
            return this.c;
        }

        @Generated
        public void a(Biome.Precipitation precipitationValue) {
            this.c = precipitationValue;
        }

        public d(aethereal.event.AmbienceEvent.d.a type, float value) {
            this.a = type;
            this.b = value;
        }

        public d(aethereal.event.AmbienceEvent.d.a type, Biome.Precipitation value) {
            this.a = type;
            this.c = value;
        }
    }
}
