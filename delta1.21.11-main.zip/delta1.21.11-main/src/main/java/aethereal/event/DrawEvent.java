package aethereal.event;

import aethereal.core.Delta;
import aethereal.core.IEvent;
import aethereal.core.Event;
import aethereal.core.Interface;
import aethereal.render.Draw2DProcessor;
import lombok.Generated;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix3x2f;

public class DrawEvent extends Event implements Interface, IEvent {
    private final Draw2DProcessor b = Delta.h().d().i();
    private final aethereal.render.Draw3DProcessor c = Delta.h().d().j();
    private final a d;
    private final float e;
    private final Matrix3x2f f;
    private final MatrixStack h;
    private DrawContext g;

    public enum a {
        D2D,
        D3D
    }

    public DrawEvent(MatrixStack stack, float tickDelta, a type) {
        this.h = stack;
        this.f = null;
        this.e = tickDelta;
        this.d = type;
    }

    @Generated
    public Draw2DProcessor d() {
        return this.b;
    }

    @Generated
    public aethereal.render.Draw3DProcessor e() {
        return this.c;
    }

    @Generated
    public a f() {
        return this.d;
    }

    @Generated
    public float g() {
        return this.e;
    }

    @Generated
    public Matrix3x2f h() {
        return this.f;
    }

    @Generated
    public MatrixStack j() {
        return this.h;
    }

    @Generated
    public DrawContext i() {
        return this.g;
    }

    public DrawEvent(Matrix3x2f stack, float tickDelta, a type) {
        this.f = stack;
        this.h = null;
        this.e = tickDelta;
        this.d = type;
    }

    public DrawEvent(DrawContext context, float tickDelta, a type) {
        this.g = context;
        this.f = context.getMatrices();
        this.h = null;
        this.e = tickDelta;
        this.d = type;
    }

    public boolean b() {
        return this.d == a.D2D;
    }

    public boolean c() {
        return this.d == a.D3D;
    }
}
