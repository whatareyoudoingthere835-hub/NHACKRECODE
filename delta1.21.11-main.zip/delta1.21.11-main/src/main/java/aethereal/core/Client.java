package aethereal.core;

public class Client {
    public Client(boolean dev) {
    }

    public boolean g() {
        return false;
    }

    public void a(boolean flag, String channel, Object... data) {
    }
}
