package aethereal.core;

import aethereal.core.EventTarget;
import aethereal.core.IEvent;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventManager {
    private static final Map<Class<? extends IEvent>, List<a>> a = new HashMap();

    private EventManager() {
    }

    public static void a(Object object) {
        for (Method method : object.getClass().getDeclaredMethods()) {
            if (!a(method)) {
                a(method, object);
            }
        }
    }

    public static void a(Object object, Class<? extends IEvent> eventClass) {
        for (Method method : object.getClass().getDeclaredMethods()) {
            if (!a(method, eventClass)) {
                a(method, object);
            }
        }
    }

    public static void b(Object object) {
        for (List<a> dataList : a.values()) {
            for (a data : dataList) {
                if (data.a().equals(object)) {
                    dataList.remove(data);
                }
            }
        }
        a(true);
    }

    public static void b(Object object, Class<? extends IEvent> eventClass) {
        if (a.containsKey(eventClass)) {
            for (a data : a.get(eventClass)) {
                if (data.a().equals(object)) {
                    a.get(eventClass).remove(data);
                }
            }
            a(true);
        }
    }

    private static void a(Method method, Object obj) {
        Class<?> cls = method.getParameterTypes()[0];
        final a aVar = new a(obj, method, ((EventTarget) method.getAnnotation(EventTarget.class)).a());
        if (!aVar.b().isAccessible()) {
            aVar.b().setAccessible(true);
        }
        if (a.containsKey(cls)) {
            boolean z = false;
            for (a aVar2 : a.get(cls)) {
                if (aVar2.a() == obj && aVar2.b().equals(method)) {
                    z = true;
                    break;
                }
            }
            if (!z) {
                a.get(cls).add(aVar);
                b((Class<? extends IEvent>) cls);
                return;
            }
            return;
        }
        a.put((Class<? extends IEvent>) cls, new CopyOnWriteArrayList<a>() {
            private static final long serialVersionUID = 666;

            {
                add(aVar);
            }
        });
    }

    public static void a(Class<? extends IEvent> indexClass) {
        Iterator<Map.Entry<Class<? extends IEvent>, List<a>>> mapIterator = a.entrySet().iterator();
        while (mapIterator.hasNext()) {
            if (mapIterator.next().getKey().equals(indexClass)) {
                mapIterator.remove();
                return;
            }
        }
    }

    public static void a(boolean onlyEmptyEntries) {
        Iterator<Map.Entry<Class<? extends IEvent>, List<a>>> mapIterator = a.entrySet().iterator();
        while (mapIterator.hasNext()) {
            if (!onlyEmptyEntries || mapIterator.next().getValue().isEmpty()) {
                mapIterator.remove();
            }
        }
    }

    private static void b(Class<? extends IEvent> indexClass) {
        List<a> sortedList = new CopyOnWriteArrayList<>();
        for (byte priority : Priority.f) {
            for (a data : a.get(indexClass)) {
                if (data.c() == priority) {
                    sortedList.add(data);
                }
            }
        }
        a.put(indexClass, sortedList);
    }

    private static boolean a(Method method) {
        return (method.getParameterTypes().length == 1 && method.isAnnotationPresent(EventTarget.class)) ? false : true;
    }

    private static boolean a(Method method, Class<? extends IEvent> eventClass) {
        return a(method) || !method.getParameterTypes()[0].equals(eventClass);
    }

    public static IEvent a(IEvent event) {
        List<a> dataList = a.get(event.getClass());
        if (dataList != null) {
            for (a data : dataList) {
                a(data, event);
            }
        }
        return event;
    }

    private static void a(a data, IEvent argument) {
        try {
            data.b().invoke(data.a(), argument);
        } catch (IllegalAccessException e) {
        } catch (IllegalArgumentException e2) {
        } catch (InvocationTargetException e3) {

            Throwable cause = e3.getCause() != null ? e3.getCause() : e3;
            String key = data.a().getClass().getName() + "#" + data.b().getName() + ":" + cause.getClass().getName();
            if (a_logged.add(key)) {
                System.err.println("[Delta] Exception in event handler " + data.a().getClass().getName() + "#" + data.b().getName());
                cause.printStackTrace();
            }
        }
    }

    private static final java.util.Set<String> a_logged = new java.util.HashSet<>();

    static final class a {
        private final Object a;
        private final Method b;
        private final byte c;

        public a(Object source, Method target, byte priority) {
            this.a = source;
            this.b = target;
            this.c = priority;
        }

        public Object a() {
            return this.a;
        }

        public Method b() {
            return this.b;
        }

        public byte c() {
            return this.c;
        }
    }
}
