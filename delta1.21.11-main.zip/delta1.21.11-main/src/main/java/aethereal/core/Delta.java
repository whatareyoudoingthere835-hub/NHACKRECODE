package aethereal.core;

import aethereal.core.NativeMethodLookup;
import static aethereal.core.Interface.aM_;
import aethereal.core.EventManager;
import aethereal.core.Interface;
import aethereal.core.Client;
import aethereal.core.EventTarget;
import aethereal.core.Processor_2;
import aethereal.core.User;
import aethereal.api.Compile;
import aethereal.api.Ultra;
import lombok.Generated;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class Delta {
    private static Delta a;
    private Processor_2 b;
    private Client d;
    private User e;
    private static volatile User jc$unifiedPendingUser$;
    private static volatile Delta jc$unifiedClient$;

    @Compile
    @Ultra
    protected void a() {
        this.e = new User("1", "By Ded", "By Ded", "Владелец", "01.01.2099 00:00", "");
        a = this;
        jc$bindUnifiedClient$(this);
        this.b = new Processor_2();
        this.d = new Client(false);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> this.a(client));
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            EventManager.a((IEvent) new GlobalEvent());
        });
        EventManager.a(this);
        this.b.a();
    }

    @Compile
    @Ultra
    protected void b() {
        if (this.b != null) {
            this.b.b();
        }
    }

    static {
        NativeMethodLookup.lookup(Delta.class, 0);
    }

    public static void jc$publishUnifiedUser$(User user) {
        jc$unifiedPendingUser$ = user;
        Delta delta = jc$unifiedClient$;
        if (delta != null) {
            delta.e = user;
        }
    }

    private static void jc$bindUnifiedClient$(Delta delta) {
        jc$unifiedClient$ = delta;
        User user = jc$unifiedPendingUser$;
        if (user != null) {
            delta.e = user;
        }
    }

    @Generated
    public void a(Processor_2 processor) {
        this.b = processor;
    }

    @Generated
    public void a(Client client) {
        this.d = client;
    }

    @Generated
    public void a(User user) {
        this.e = user;
    }

    @Generated
    public static Delta h() {
        return a;
    }

    @Generated
    public Processor_2 d() {
        return this.b;
    }

    @Generated
    public Client f() {
        return this.d;
    }

    @Generated
    public User g() {
        return this.e;
    }

    public Delta() {
        a();
    }

    public void a(MinecraftClient client) {
        b();
    }

    @EventTarget(a = 0)
    public void a(aethereal.event.DrawEvent event) {
        if (event.b()) {
            aethereal.render.ScaleUtil.a(event.i(), 2);
            if (this.b != null && this.b.t() != null) {
                for (Module module : this.b.t().e()) {
                    module.f().a(0.0f, 1.0f, 0.3f, aethereal.render.EasingList.i, event.g());
                    module.f().a(module.m());
                    module.g().a(0.0f, 1.0f, 0.3f, aethereal.render.EasingList.i, event.g());
                    module.g().a(module.n());
                }
            }
        }
    }

    @EventTarget(a = 4)
    public void b(aethereal.event.DrawEvent event) {
        if (event.b()) {
            aethereal.render.ScaleUtil.a(event.i());
            aethereal.render.pipeline.DrawBatcher.flushPending();
        }
    }

    public String c() {
        return null;
    }
}
