package aethereal.core;

import aethereal.autobuy.AutoBuyProcessor;
import aethereal.command.CommandProcessor;
import aethereal.config.BaseProcessor;
import aethereal.config.ModuleProcessor;
import aethereal.config.ThemeProcessor;
import aethereal.friend.FriendProcessor;
import aethereal.macro.MacrosProcessor;
import aethereal.network.AccountProcessor;
import aethereal.render.Draw2DProcessor;
import aethereal.staff.StaffProcessor;
import aethereal.ui.element.DragProcessor;
import aethereal.notification.NotificationProcessor;
import aethereal.render.Draw3DProcessor;
import lombok.Generated;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Processor_2 implements Interface {
    private final List<BaseProcessor> c;
    private final AccountProcessor h;
    private final Draw2DProcessor i;
    private final Draw3DProcessor j;
    private final NotificationProcessor m;
    private final ThemeProcessor o;
    private final DragProcessor s;
    private final ModuleProcessor t;
    private final MacrosProcessor d;
    private final FriendProcessor e;
    private final StaffProcessor f;
    private final AutoBuyProcessor q;
    private final CommandProcessor u;

    public void a() {

        Collections.addAll(this.c, this.h, this.i, this.j, this.o, this.d, this.e, this.f, this.q, this.m, this.t, this.s, this.u);
        this.c.forEach(processor -> {
            try {
                processor.setup();
            } catch (Throwable th) {
                th.printStackTrace();
            }
        });
    }

    public Processor_2() {
        Delta.h().a(this);
        this.c = new ArrayList<>();
        this.h = new AccountProcessor();
        this.i = new Draw2DProcessor();
        this.j = new Draw3DProcessor();
        this.m = new NotificationProcessor();
        this.o = new ThemeProcessor();
        this.s = new DragProcessor();
        this.t = new ModuleProcessor();
        this.d = new MacrosProcessor();
        this.e = new FriendProcessor();
        this.f = new StaffProcessor();
        this.q = new AutoBuyProcessor();
        this.u = new CommandProcessor();
    }

    @Generated
    public DragProcessor s() {
        return this.s;
    }

    @Generated
    private final aethereal.handler.HandlerProcessor v = new aethereal.handler.HandlerProcessor();
private final aethereal.autobuy.BatchProcessor l = new aethereal.autobuy.BatchProcessor();
private final aethereal.autobuy.CollectorProcessor p = new aethereal.autobuy.CollectorProcessor();
private final aethereal.discord.DiscordProcessor g = new aethereal.discord.DiscordProcessor();
private final aethereal.config.ResourcePacksProcessor n = new aethereal.config.ResourcePacksProcessor();

    public aethereal.handler.HandlerProcessor v() {
        return this.v;
    }

public aethereal.autobuy.BatchProcessor l() { return this.l; }

public aethereal.autobuy.CollectorProcessor p() { return this.p; }

public aethereal.discord.DiscordProcessor g() { return this.g; }

public aethereal.config.ResourcePacksProcessor n() { return this.n; }

public aethereal.handler.RotationProcessor k() { return aethereal.handler.Handlers.rotation(); }

    public ModuleProcessor t() {
        return this.t;
    }

    @Generated
    public List<BaseProcessor> c() {
        return this.c;
    }

    @Generated
    public Draw2DProcessor i() {
        return this.i;
    }

    @Generated
    public AccountProcessor h() {
        return this.h;
    }

    @Generated
    public ThemeProcessor o() {
        return this.o;
    }

    @Generated
    public MacrosProcessor d() {
        return this.d;
    }

    @Generated
    public FriendProcessor e() {
        return this.e;
    }

    @Generated
    public StaffProcessor f() {
        return this.f;
    }

    @Generated
    public AutoBuyProcessor q() {
        return this.q;
    }

    @Generated
    public CommandProcessor u() {
        return this.u;
    }

    @Generated
    public Draw3DProcessor j() {
        return this.j;
    }

    @Generated
    public NotificationProcessor m() {
        return this.m;
    }

    public void b() {
        this.c.forEach(processor -> {
            try {
                processor.unSetup();
            } catch (Throwable ignored) {
            }
        });
    }
}
