package aethereal.module.movement;

import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.InputEvent;

@ModuleRegister(a = "No Crouch", b = "Убирает замедление от приседания на вашей стороне", c = Category.Movement)
public class NoCrouch extends Module {

    @EventTarget
    public void a(InputEvent e) {

        e.c(false);
    }
}
