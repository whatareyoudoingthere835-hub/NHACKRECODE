package aethereal.module.movement;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;

import aethereal.setting.SliderSetting;
import net.minecraft.client.input.Input;
import net.minecraft.util.math.Vec2f;
import platform.inject.accessors.InputAccessor;

@ModuleRegister(a = "Fly", b = "Позволяет свободно летать по миру", c = Category.Movement)
public class Fly extends Module {
    private final SliderSetting b = new SliderSetting("Скорость X и Z", 1.0f, 0.1f, 5.0f, 0.1f);
    private final SliderSetting c = new SliderSetting("Скорость Y", 1.0f, 0.1f, 5.0f, 0.1f);

    public Fly() {
        a(this.b, this.c);
    }

    @EventTarget
    public void a(TickEvent event) {
        q();
    }

    private void q() {
        double dFloatValue;
        float fSignum;
        float yaw = aM_.player.getYaw();
        if (aM_.options.sneakKey.isPressed()) {
            dFloatValue = -this.c.c().floatValue();
        } else {
            dFloatValue = aM_.options.jumpKey.isPressed() ? this.c.c().floatValue() : 0.0d;
        }
        double motionY = dFloatValue;

        Input input = aM_.player.input;
        Vec2f movement = input.getMovementInput();
        float forward = movement.y;
        float sideways = movement.x;
        if (forward == 0.0f && sideways == 0.0f) {
            aM_.player.setVelocity(0.0d, motionY, 0.0d);
            return;
        }
        if (forward != 0.0f) {
            if (sideways != 0.0f) {
                fSignum = (forward > 0.0f ? -45.0f : 45.0f) * Math.signum(sideways);
            } else {
                fSignum = 0.0f;
            }
            yaw += fSignum;
            sideways = 0.0f;
            forward = Math.signum(forward);
            ((InputAccessor) input).setMovementVector(new Vec2f(sideways, forward));
        }
        double radians = Math.toRadians(yaw + 90.0f);
        double speedXZ = this.b.c().floatValue();
        double motionX = (((double) forward) * speedXZ * Math.cos(radians)) + (((double) sideways) * speedXZ * Math.sin(radians));
        double motionZ = ((((double) forward) * speedXZ) * Math.sin(radians)) - ((((double) sideways) * speedXZ) * Math.cos(radians));
        aM_.player.setVelocity(motionX, motionY, motionZ);
    }
}
