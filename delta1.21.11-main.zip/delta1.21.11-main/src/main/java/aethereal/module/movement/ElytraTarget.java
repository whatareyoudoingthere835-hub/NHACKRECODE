package aethereal.module.movement;

import aethereal.module.combat.AuraUtil;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;
import aethereal.module.combat.Aura;
import aethereal.util.Rotation;

import aethereal.util.CounterUtil;
import net.minecraft.util.Hand;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;

@ModuleRegister(a = "Elytra Target", b = "Наводит на врага в полёте на элитре и ускоряется фейерверком из второй руки", c = Category.Movement)
public class ElytraTarget extends Module {
    private final CounterUtil b = new CounterUtil();

    @EventTarget
    public void a(TickEvent event) {
        Aura aura = Delta.h().d().t().B();
        if (aura.m() && aM_.player.isGliding()) {
            if (aM_.player.getOffHandStack().getItem() != Items.FIREWORK_ROCKET && !Delta.h().d().t().V().b) {
                if (aethereal.handler.Handlers.inventory().a().isEmpty()) {
                    aethereal.handler.Handlers.inventory().a(Items.FIREWORK_ROCKET, 45, 1);
                }
            } else if ((this.b.a(150L) && aM_.player.getVelocity().length() < 1.5d) || aura.b == 1) {
                aM_.interactionManager.interactItem(aM_.player, Hand.OFF_HAND);
                this.b.b();
            }
            LivingEntity target = aura.s();
            if (target == null) {
                return;
            }
            Vec3d eye = aM_.player.getEyePos();
            Vec3d enemy = target.getBoundingBox().getCenter();
            double dx = enemy.x - eye.x;
            double dz = enemy.z - eye.z;
            double horizontal = Math.sqrt((dx * dx) + (dz * dz));
            double nx = horizontal == 0.0d ? 0.0d : dx / horizontal;
            double nz = horizontal == 0.0d ? 0.0d : dz / horizontal;
            double lift = Math.max(0.0d, 3.0d - q());
            Vec3d aim = new Vec3d(enemy.x + (nx * 4.0d), enemy.y + lift, enemy.z + (nz * 4.0d));
            Rotation aimRotation = Rotation.a(eye, aim);
            float Yaw = AuraUtil.a(aM_.player.getYaw(), aimRotation.c(), 1.0f);
            float Pitch = AuraUtil.a(aM_.player.getPitch(), aura.b <= 3 ? 0.0f : aimRotation.d(), aura.b <= 3 ? 1.0f : Math.clamp(aura.b / 10.0f, 0.0f, 1.0f));
            aethereal.handler.Handlers.rotation().a(new Rotation(Yaw, Pitch), 180.0f, 1, 1);
        }
    }

    private double q() {
        Vec3d start = aM_.player.getEntityPos();
        Vec3d end = start.subtract(0.0d, 2.0d, 0.0d);
        BlockHitResult class_3965VarMethod_17742 = aM_.world.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, aM_.player));
        if (class_3965VarMethod_17742.getType() == HitResult.Type.MISS) {
            return 2.0d;
        }
        return start.getY() - class_3965VarMethod_17742.getPos().y;
    }
}
