package aethereal.module.movement;

import platform.inject.invokers.MinecraftClientInvoker;
import aethereal.handler.UseableHandler;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;
import aethereal.util.Look;
import aethereal.util.MoveUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.GlobalEvent;
import aethereal.core.ModuleRegister;
import aethereal.event.HotbarEvent;
import aethereal.event.InputEvent;
import aethereal.event.PacketEvent;
import aethereal.event.TickEvent;

import aethereal.setting.BooleanSetting;
import aethereal.util.Rotation;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import net.minecraft.util.Hand;
import net.minecraft.entity.Entity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.SnowBlock;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.block.BlockState;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;

@ModuleRegister(a = "Scaffold", b = "Автоматически ставит блоки под вами", c = Category.Movement)
public class Scaffold extends Module {
    private a c;
    private final BooleanSetting b = new BooleanSetting("Избегать падения", false);
    private Vec3d d = Vec3d.ZERO;
    private final int[] e = {-1, -1, -1};

    public Scaffold() {
        a(this.b);
    }

    @EventTarget
    public void a(InputEvent e) {
        if (r()) {
            return;
        }
        if (s() != null) {
            MoveUtil.a(e, Look.b(), 1);
            if (this.b.c().booleanValue()) {
                Delta.h().d().t().ah().b(e);
            }
        }
        if (a(aM_.player.getMainHandStack()) || a(aM_.player.getOffHandStack())) {
            return;
        }
        int hotbarSlot = d(true);
        if (hotbarSlot != -1) {
            if (aM_.player.getInventory().getSelectedSlot() != hotbarSlot && this.e[2] < 7 && aethereal.handler.Handlers.inventory().a().isEmpty()) {
                aM_.player.getInventory().setSelectedSlot(hotbarSlot);
                this.e[2] = 9;
                return;
            }
            return;
        }
        int invSlot = d(false);
        if (this.e[2] < 5 && invSlot != -1 && aethereal.handler.Handlers.inventory().a().isEmpty()) {
            if (this.e[1] == -1) {
                this.e[1] = invSlot;
            }
            if (aM_.player.getInventory().getSelectedSlot() != 5) {
                aM_.player.getInventory().setSelectedSlot(5);
            }
            aethereal.handler.Handlers.inventory().a(invSlot, 5, 1);
            this.e[2] = 9;
        }
    }

    @EventTarget
    public void a(HotbarEvent event) {
        if (this.e[2] <= 5 || d(false) == -1) {
            return;
        }
        event.a(true);
    }

    @EventTarget
    public void a(PacketEvent event) {
        if (!event.b() || !(event.d() instanceof UpdateSelectedSlotC2SPacket)) {
            return;
        }
        this.e[2] = 9;
    }

    @EventTarget
    public void a(TickEvent e) {
        int[] iArr = this.e;
        iArr[2] = iArr[2] - 1;
    }

    @EventTarget
    public void a(GlobalEvent e) throws MatchException {
        if (s() == null || r()) {
            return;
        }
        if (this.c == null || !a(this.c)) {
            this.c = null;
            for (BlockPos target : q()) {
                this.c = b(target);
                if (this.c != null) {
                    break;
                }
            }
        }
        if (this.c == null) {
            return;
        }
        float t = aM_.player.age + aM_.getRenderTickCounter().getTickProgress(false);
        float smoothYaw = ((float) ((Math.sin(((double) t) * 0.40000001611738834d) * 3.0d) + (Math.sin((((double) t) * 0.950000126718632d) + 1.4000003101900576d) * 2.0d))) / 10.0f;
        float smoothPitch = ((float) ((Math.cos((((double) t) * 0.5d) + 0.7000001047992626d) * 0.5d) + (Math.cos((((double) t) * 0.7800000028540086d) + 3.099999110838922d) * 1.5d))) / 4.0f;
        Rotation rotation = b(this.c);
        rotation.a(rotation.c() + smoothYaw);
        rotation.b(rotation.d() + smoothPitch);
        aethereal.handler.Handlers.rotation().a(rotation, 100.0f, 7, 1);
        if (u() && !v() && !aethereal.handler.Handlers.stop().a()) {
            ((platform.inject.invokers.MinecraftClientInvoker) aM_).invokeDoItemUse();
            this.e[2] = 9;
            this.c = null;
        }
    }

    private boolean a(a data) {
        BlockPos placePos = data.a.offset(data.b);
        return a(aM_.world.getBlockState(placePos)) && a(data.a) && !a(data.a, data.b).isEmpty();
    }

    private List<Vec3d> a(BlockPos pos, Direction face) throws MatchException {
        List<Vec3d> points = new ArrayList<>();
        Vec3d eye = t();
        double reach = aM_.player.getBlockInteractionRange();
        Vec3d normal = new Vec3d(face.getOffsetX(), face.getOffsetY(), face.getOffsetZ());
        double[] offsets = {0.0d, -0.20000000236855192d, 0.200000000060146d, -0.3500000030268554d, 0.3500000598673184d, -0.4500000079401218d, 0.4499998886196472d};
        for (double u : offsets) {
            for (double v : offsets) {
                Vec3d point = a(pos, face, u, v);
                if (eye.distanceTo(point) <= reach && eye.subtract(point).normalize().dotProduct(normal) > 0.1000000076546522d) {
                    BlockHitResult class_3965VarMethod_17742 = aM_.world.raycast(new RaycastContext(eye, point, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, aM_.player));
                    if (class_3965VarMethod_17742.getType() == HitResult.Type.MISS) {
                        points.add(point);
                    } else if (class_3965VarMethod_17742 instanceof BlockHitResult) {
                        BlockHitResult block = class_3965VarMethod_17742;
                        if (block.getBlockPos().equals(pos)) {
                            points.add(point);
                        }
                    }
                }
            }
        }
        return points;
    }

    private List<BlockPos> q() {
        List<BlockPos> list = new ArrayList<>();
        this.d = this.d.multiply(0.6000003608875443d).add(new Vec3d(aM_.player.getX() - aM_.player.lastX, 0.0d, aM_.player.getZ() - aM_.player.lastZ).multiply(0.200000000060146d));
        for (int i = 0; i <= 2; i++) {
            Vec3d at = aM_.player.getEntityPos().add(this.d.multiply(i));
            BlockPos pos = BlockPos.ofFloored(at.x, aM_.player.getY() - 1.0d, at.z);
            if (!list.contains(pos) && a(aM_.world.getBlockState(pos))) {
                list.add(pos);
            }
        }
        list.sort(Comparator.comparingDouble(pos2 -> {
            return pos2.getSquaredDistance(aM_.player.getEntityPos());
        }));
        return list;
    }

    private boolean r() {
        List<UseableHandler.a> tasks = aethereal.handler.Handlers.useable().a();
        return !tasks.isEmpty() && ((UseableHandler.a) tasks.getFirst()).d() <= 1;
    }

    @Override
    public void b() {
        super.b();
        this.c = null;
        this.d = Vec3d.ZERO;
        if (aM_.player != null) {
            this.e[0] = aM_.player.getInventory().getSelectedSlot();
        }
    }

    @Override
    public void c() {
        super.c();
        if (this.e[0] != -1 && aM_.player != null) {
            aM_.player.getInventory().setSelectedSlot(this.e[0]);
            if (this.e[1] != -1) {
                aethereal.handler.Handlers.inventory().a(this.e[1], 5, 1);
            }
        }
        this.e[0] = -1;
        this.e[1] = -1;
        this.e[2] = -1;
        this.c = null;
        this.d = Vec3d.ZERO;
    }

    private int d(boolean hotbarOnly) {
        int end = hotbarOnly ? 9 : 36;
        for (int i = 0; i < end; i++) {
            if (a(aM_.player.getInventory().getStack(i))) {
                return i;
            }
        }
        return -1;
    }

    private boolean a(ItemStack stack) {
        if (!stack.isEmpty()) {
            BlockItem class_1747VarMethod_7909 = (BlockItem) stack.getItem();
            if (class_1747VarMethod_7909 instanceof BlockItem) {
                BlockItem item = class_1747VarMethod_7909;
                if (item.getBlock().getDefaultState().isOpaqueFullCube()) {
                    return true;
                }
            }
        }
        return false;
    }

    private Hand s() {
        if (a(aM_.player.getMainHandStack())) {
            return Hand.MAIN_HAND;
        }
        if (a(aM_.player.getOffHandStack())) {
            return Hand.OFF_HAND;
        }
        return null;
    }

    private boolean a(BlockState state) {
        if (state.isReplaceable()) {
            return true;
        }
        return state.getBlock() == Blocks.SNOW && ((Integer) state.get(SnowBlock.LAYERS)).intValue() < 8;
    }

    private boolean a(BlockPos pos) {
        BlockState state = aM_.world.getBlockState(pos);
        return (state.isAir() || state.getBlock() == Blocks.SNOW || state.isReplaceable() || state.getCollisionShape(aM_.world, pos).isEmpty()) ? false : true;
    }

    private a b(BlockPos pos) throws MatchException {
        a data = c(pos);
        if (data != null) {
            return data;
        }
        int[][] offsets = {new int[]{-1, 0, 0}, new int[]{1, 0, 0}, new int[]{0, 0, -1}, new int[]{0, 0, 1}, new int[]{-1, 0, -1}, new int[]{1, 0, 1}, new int[]{-1, 0, 1}, new int[]{1, 0, -1}, new int[]{0, -1, 0}, new int[]{-1, -1, 0}, new int[]{1, -1, 0}, new int[]{0, -1, -1}, new int[]{0, -1, 1}};
        Vec3d feet = aM_.player.getEntityPos();
        return Arrays.stream(offsets).map(o -> {
            return pos.add(o[0], o[1], o[2]);
        }).sorted(Comparator.comparingDouble(p -> {
            return p.getSquaredDistance(feet);
        })).map(this::c).filter((v0) -> {
            return Objects.nonNull(v0);
        }).findFirst().orElse(null);
    }

    private a c(BlockPos pos) throws MatchException {
        if (!a(aM_.world.getBlockState(pos))) {
            return null;
        }
        a best = null;
        int bestCount = 0;
        for (Direction face : Direction.values()) {
            BlockPos neighbor = pos.offset(face);
            if (a(neighbor)) {
                Direction placeFace = face.getOpposite();
                List<Vec3d> points = a(neighbor, placeFace);
                if (points.size() > bestCount) {
                    bestCount = points.size();
                    best = new a(neighbor, placeFace, new BlockHitResult(a(neighbor, placeFace, 0.0d, 0.0d), placeFace, neighbor, false));
                }
            }
        }
        return best;
    }

    private Rotation b(a data) throws MatchException {
        Vec3d eye = t();
        List<Vec3d> points = a(data.a, data.b);
        if (points.isEmpty()) {
            return Rotation.a(eye, data.c.getPos());
        }
        Vec3d center = points.stream().reduce(Vec3d.ZERO, (v0, v1) -> {
            return v0.add(v1);
        }).multiply(1.0d / ((double) points.size()));
        Vec3d best = points.stream().min(Comparator.comparingDouble(point -> {
            return point.squaredDistanceTo(center);
        })).orElse(center);
        return Rotation.a(eye, best);
    }

    private Vec3d t() {
        Vec3d eye = aM_.player.getEyePos();
        double fall = aM_.player.getVelocity().y;
        return fall < 0.0d ? eye.add(0.0d, fall * 0.5d, 0.0d) : eye;
    }

    private Box d(BlockPos pos) {
        VoxelShape shape = aM_.world.getBlockState(pos).getCollisionShape(aM_.world, pos);
        return shape.isEmpty() ? new Box(0.0d, 0.0d, 0.0d, 1.0d, 1.0d, 1.0d) : shape.getBoundingBox();
    }

    private Vec3d a(BlockPos pos, Direction face, double u, double v) throws MatchException {
        Box shape = d(pos);
        double cx = ((double) pos.getX()) + ((shape.minX + shape.maxX) / 2.0d);
        double cy = ((double) pos.getY()) + ((shape.minY + shape.maxY) / 2.0d);
        double cz = ((double) pos.getZ()) + ((shape.minZ + shape.maxZ) / 2.0d);
        double sx = shape.getLengthX();
        double sy = shape.getLengthY();
        double sz = shape.getLengthZ();
        switch (AnonymousClass1.a[face.ordinal()]) {
            case 1:
                return new Vec3d(cx + (u * sx), ((double) pos.getY()) + shape.maxY, cz + (v * sz));
            case 2:
                return new Vec3d(cx + (u * sx), ((double) pos.getY()) + shape.minY, cz + (v * sz));
            case 3:
                return new Vec3d(cx + (u * sx), cy + (v * sy), ((double) pos.getZ()) + shape.minZ);
            case 4:
                return new Vec3d(cx + (u * sx), cy + (v * sy), ((double) pos.getZ()) + shape.maxZ);
            case 5:
                return new Vec3d(((double) pos.getX()) + shape.minX, cy + (v * sy), cz + (u * sz));
            case 6:
                return new Vec3d(((double) pos.getX()) + shape.maxX, cy + (v * sy), cz + (u * sz));
            default:
                throw new MatchException((String) null, (Throwable) null);
        }
    }

    static class AnonymousClass1 {
        static final int[] a = new int[Direction.values().length];

        static {
            try {
                a[Direction.UP.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                a[Direction.DOWN.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                a[Direction.NORTH.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                a[Direction.SOUTH.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                a[Direction.WEST.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                a[Direction.EAST.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
        }
    }

    private boolean u() {
        BlockHitResult class_3965Var = (aM_.crosshairTarget) instanceof BlockHitResult ? (BlockHitResult) aM_.crosshairTarget : null;
        if (!(class_3965Var instanceof BlockHitResult)) {
            return false;
        }
        BlockHitResult hit = class_3965Var;
        if (hit.getType() != HitResult.Type.BLOCK) {
            return false;
        }
        BlockPos placePos = this.c.a.offset(this.c.b);
        if (hit.getBlockPos().equals(this.c.a) && hit.getSide() == this.c.b) {
            return true;
        }
        return hit.getBlockPos().equals(placePos) && a(aM_.world.getBlockState(placePos));
    }

    private boolean v() {
        BlockPos placePos = this.c.a.offset(this.c.b);
        return !aM_.world.getEntitiesByClass(Entity.class, new Box(placePos), entity -> {
            return !entity.isSpectator() && entity.isAlive();
        }).isEmpty();
    }

    static final class a {
        final BlockPos a;
        final Direction b;
        final BlockHitResult c;

        a(BlockPos pos, Direction face, BlockHitResult result) {
            this.a = pos;
            this.b = face;
            this.c = result;
        }
public BlockPos a() {
            return this.a;
        }

        public Direction b() {
            return this.b;
        }

        public BlockHitResult c() {
            return this.c;
        }
    }
}
