package aethereal.module.combat;

import aethereal.handler.Handler_2;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.render.EasingList;
import aethereal.render.ColorUtil;
import aethereal.util.ProjectUtil;

import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.event.DrawEvent;
import aethereal.event.TickEvent;
import aethereal.handler.BaseHandler;
import aethereal.module.combat.ProjectileHelper;

import aethereal.render.AnimationUtil;
import lombok.Generated;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Vector2f;

@Handler_2
public class AimHandler extends BaseHandler implements Interface {
    private final AnimationUtil b = new AnimationUtil();
    private LivingEntity c;

    @Generated
    public AnimationUtil a() {
        return this.b;
    }

    @EventTarget
    public void a(DrawEvent event) {
        this.b.a(0.0f, 1.0f, 0.25f, EasingList.g, event.g());
        float alpha = this.b.c();
        if (event.b() && this.c != null && alpha > 0.0f) {
            Vec3d real = a(this.c, event.g());
            Vector2f screen = ProjectUtil.a(real.x, real.y, real.z);
            if (!ProjectUtil.a(screen)) {
                return;
            }
            float distance = (float) aM_.player.getEyePos().distanceTo(real);
            float size = ((float) Math.max(28.0d, 40.0d - (((double) distance) * 0.7000002488091963d))) * (1.2f - (0.2f * alpha));

            float angle = ((float) Math.sin(System.currentTimeMillis() / 820.0d)) * 350.0f;
            event.d().getTexturePipeline().drawTexture(Identifier.of("delta", "pictures/marker.png"), screen.x, screen.y, size, size, 0.0f, 0.0f, 1.0f, 1.0f, new int[]{ColorUtil.a(-1, alpha * 0.8f)}, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 1.0f, angle);
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        ProjectileHelper projectile = Delta.h().d().t().D();
        LivingEntity current = null;
        if (projectile.m() && projectile.r()) {
            current = projectile.q();
        }
        boolean visible = current != null;
        if (visible) {
            this.c = current;
        }
        this.b.a(visible);
        if (!visible && this.b.a() <= 0.0f) {
            this.c = null;
        }
    }

    private Vec3d a(LivingEntity entity, float delta) {
        return new Vec3d(MathHelper.lerp(delta, entity.lastRenderX, entity.getX()), MathHelper.lerp(delta, entity.lastRenderY, entity.getY()) + (((double) entity.getHeight()) / 2.0d), MathHelper.lerp(delta, entity.lastRenderZ, entity.getZ()));
    }
}
