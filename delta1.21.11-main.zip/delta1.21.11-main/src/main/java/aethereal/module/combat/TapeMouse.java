package aethereal.module.combat;

import platform.inject.invokers.MinecraftClientInvoker;
import static aethereal.core.Interface.aM_;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;

import aethereal.setting.BooleanSetting;
import aethereal.util.CounterUtil;
import aethereal.setting.ModeSetting;
import aethereal.setting.SliderSetting;
import lombok.Generated;

@ModuleRegister(a = "Tape Mouse", b = "Автоматически кликает выбранной кнопкой мыши через заданные промежутки времени", c = Category.Combat)
public class TapeMouse extends Module implements Interface {
    private final SliderSetting b = new SliderSetting("Задержка между кликами", 1000.0f, 10.0f, 5000.0f, 10.0f);
    private final BooleanSetting c = new BooleanSetting("Не кликать во время еды", true);
    private final ModeSetting d = new ModeSetting("Кнопка мыши", "Правая", "Правая", "Левая");
    private final CounterUtil e = new CounterUtil();

    @Generated
    public SliderSetting q() {
        return this.b;
    }

    @Generated
    public BooleanSetting r() {
        return this.c;
    }

    @Generated
    public ModeSetting s() {
        return this.d;
    }

    @Generated
    public CounterUtil t() {
        return this.e;
    }

    public TapeMouse() {
        a(this.d, this.c, this.b);
    }

    @EventTarget
    public void a(TickEvent event) {
        if ((!this.c.c().booleanValue() || !aM_.player.isUsingItem()) && this.e.a(this.b.c().intValue())) {
            switch (this.d.c()) {
                case "Правая":
                    ((platform.inject.invokers.MinecraftClientInvoker) aM_).invokeDoItemUse();
                    break;
                case "Левая":
                    ((platform.inject.invokers.MinecraftClientInvoker) aM_).invokeDoAttack();
                    break;
            }
            this.e.b();
        }
    }
}
