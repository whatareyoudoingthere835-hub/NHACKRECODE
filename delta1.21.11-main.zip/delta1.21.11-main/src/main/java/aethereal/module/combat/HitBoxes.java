package aethereal.module.combat;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.BoundingBoxEvent;

import aethereal.setting.BooleanSetting;
import aethereal.setting.MultiModeSetting;
import aethereal.setting.SliderSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.mob.AmbientEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.passive.AllayEntity;
import net.minecraft.entity.passive.GolemEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

@ModuleRegister(a = "Hit Boxes", b = "Увеличивает хитбоксы сущностей, упрощая попадания по ним", c = Category.Combat)
public class HitBoxes extends Module {
    private final MultiModeSetting a = new MultiModeSetting("Цели",
            new BooleanSetting("Игроки", true),
            new BooleanSetting("Враждебные мобы", true),
            new BooleanSetting("Животные", false));
    private final SliderSetting b = new SliderSetting("Расширение X и Z", 0.0f, 0.0f, 1.0f, 0.1f);
    private final SliderSetting c = new SliderSetting("Расширение Y", 0.0f, 0.0f, 1.0f, 0.1f);

    public HitBoxes() {
        a(this.a, this.b, this.c);
    }

    @EventTarget
    public void a(BoundingBoxEvent event) {
        if (this.b.h().floatValue() <= 0.0f && this.c.h().floatValue() <= 0.0f) {
            return;
        }
        if (aM_.player == null || aM_.world == null) {
            return;
        }
        Entity entity = event.c();
        if (entity == aM_.player || entity == aM_.getCameraEntity() || !(entity instanceof LivingEntity living) || !living.isAlive()) {
            return;
        }
        if (!this.a(living)) {
            return;
        }
        Box box = event.b();
        double halfXZ = this.b.h().floatValue() / 2.0;
        double halfY = this.c.h().floatValue() / 2.0;
        event.a(new Box(box.minX - halfXZ, box.minY - halfY, box.minZ - halfXZ, box.maxX + halfXZ, box.maxY + halfY, box.maxZ + halfXZ));
    }

    private boolean a(LivingEntity entity) {
        if (entity instanceof PlayerEntity) {
            return this.a("Игроки") && !Delta.h().d().e().d(entity.getName().getString());
        }
        if (entity instanceof HostileEntity || entity instanceof SlimeEntity || entity instanceof Monster || entity instanceof EnderDragonEntity) {
            return this.a("Враждебные мобы");
        }
        if (entity instanceof PassiveEntity || entity instanceof GolemEntity || entity instanceof AllayEntity || entity instanceof AmbientEntity) {
            return this.a("Животные");
        }
        return false;
    }

    private boolean a(String name) {
        BooleanSetting setting = this.a.a(name);
        return setting != null && setting.c().booleanValue();
    }
}
