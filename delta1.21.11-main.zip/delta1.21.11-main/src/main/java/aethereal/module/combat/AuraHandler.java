package aethereal.module.combat;

import aethereal.handler.Handler_2;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.render.EasingList;
import aethereal.render.ColorUtil;
import aethereal.render.ImmediateRenderer;

import aethereal.config.ThemeInfo;
import aethereal.core.EventTarget;
import aethereal.core.GlobalEvent;
import aethereal.core.Interface;
import aethereal.event.DrawEvent;
import aethereal.event.TickEvent;
import aethereal.handler.BaseHandler;
import aethereal.module.combat.Aura;

import aethereal.render.AnimationUtil;
import lombok.Generated;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.nio.ByteBuffer;
import org.lwjgl.system.MemoryUtil;

@Handler_2
public class AuraHandler extends BaseHandler implements Interface {
    private final Vector3f[] b = {new Vector3f(0.0f, 1.5f, 0.0f), new Vector3f(0.0f, -1.5f, 0.0f), new Vector3f(1.0f, 0.0f, 0.0f), new Vector3f(-1.0f, 0.0f, 0.0f), new Vector3f(0.0f, 0.0f, 1.0f), new Vector3f(0.0f, 0.0f, -1.0f)};
    private final int[][] c = {new int[]{0, 4, 2}, new int[]{0, 3, 4}, new int[]{0, 5, 3}, new int[]{0, 2, 5}, new int[]{1, 2, 4}, new int[]{1, 4, 3}, new int[]{1, 3, 5}, new int[]{1, 5, 2}};
    private final float[] d = {1.0f, 0.8f, 0.6f, 0.9f, 0.7f, 0.5f, 0.4f, 0.6f};
    private final AnimationUtil e = new AnimationUtil();
    private LivingEntity f;

    @Generated
    public AnimationUtil a() {
        return this.e;
    }

    @EventTarget
    public void a(DrawEvent event) {
        this.e.a(0.0f, 1.0f, 0.2f, EasingList.g, event.g());
        float moving = ((System.currentTimeMillis() % 360000) / 2.5f) + this.e.c();
        if (event.c() && this.f != null && event.j() != null) {
            if (!a_logged) {
                a_logged = true;
                System.out.println("[Delta] AuraHandler D3D draw start, anim=" + this.e.c());
            }
                try {
                    float anim = this.e.c();
                    if (anim > 0.0f) {
                        int themeColor = Delta.h().d().o().a(ThemeInfo.PRIMARY).a();
                        Vec3d renderPos = a(this.f, event.g());
                    float ringWidth = this.f.getWidth() * 1.5f;
                    float ringScale = 1.25f - (0.5f * anim);
                    MatrixStack stack = event.j();
                    if (Delta.h().d().t().B().r().l("Круг")) {
                        a(stack, renderPos, ColorUtil.a(themeColor, anim));
                    } else {
                        a(stack, renderPos, ringWidth, ringScale, moving, ColorUtil.a(themeColor, anim));
                        a(stack, renderPos, ringWidth, ringScale, moving, ColorUtil.a(themeColor, anim * 0.2f), anim);
                    }
                }
            } catch (Throwable t) {
                if (!a_errorLogged) {
                    a_errorLogged = true;
                    System.err.println("[Delta] AuraHandler draw error:");
                    t.printStackTrace();
                }
            }
        }
    }

    private static boolean a_logged = false;
    private static boolean a_errorLogged = false;

    @EventTarget
    public void a(GlobalEvent event) {
        if (aM_.player != null) {
            Delta.h().d().t().B().b++;
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        Aura aura = Delta.h().d().t().B();
        LivingEntity current = aura.s() != null ? aura.s() : Delta.h().d().t().X().s();
        boolean changed = (current == null || this.f == null || current == this.f) ? false : true;
        boolean visible = (current == null || changed) ? false : true;
        if (visible) {
            this.f = current;
        }
        this.e.a(visible);
        if (!visible && this.e.a() <= 0.0f) {
            this.f = changed ? current : null;
        }
    }

    private void a(MatrixStack stack, Vec3d renderPos, float ringWidth, float ringScale, float moving, int color) {
        Vec3d cam = aM_.gameRenderer.getCamera().getCameraPos();
        Vec3d targetCenter = renderPos.add(0.0d, ((double) this.f.getHeight()) / 2.0d, 0.0d);

        ByteBuffer buffer = MemoryUtil.memAlloc((360 / 20) * this.c.length * 3 * 16);
        Matrix4f base = new Matrix4f(stack.peek().getPositionMatrix());
        for (int i = 0; i < 360; i += 20) {
            float angle = (float) Math.toRadians(i + (moving * 0.3f));
            float offsetX = ((float) Math.sin(angle)) * ringWidth * ringScale;
            float offsetZ = ((float) Math.cos(angle)) * ringWidth * ringScale;
            float offsetY = 0.1f + (this.f.getHeight() * Math.abs((float) Math.sin(i)));
            Vec3d crystalPos = renderPos.add(offsetX, offsetY, offsetZ);
            Matrix4f local = new Matrix4f(base);
            local.translate((float) (crystalPos.getX() - cam.x), (float) (crystalPos.getY() - cam.y), (float) (crystalPos.getZ() - cam.z));
            local.rotate(new Quaternionf().rotationTo(new Vector3f(0.0f, 1.0f, 0.0f), new Vector3f((float) (targetCenter.x - crystalPos.getX()), (float) (targetCenter.y - crystalPos.getY()), (float) (targetCenter.z - crystalPos.getZ())).normalize()));
            local.scale(0.1f, 0.1f, 0.1f);
            int[] rgba = ColorUtil.b(color);
            for (int fi = 0; fi < this.c.length; fi++) {
                int[] face = this.c[fi];
                float brightness = this.d[fi];
                int shaded = ((rgba[3]) << 24) | (Math.min(255, (int) (rgba[0] * brightness)) << 16) | (Math.min(255, (int) (rgba[1] * brightness)) << 8) | Math.min(255, (int) (rgba[2] * brightness));
                for (int v = 0; v < 3; v++) {
                    Vector3f vertex = this.b[face[v]];
                    Vector3f transformed = new Vector3f(vertex).mulPosition(local);
                    ImmediateRenderer.putVertexColor(buffer, transformed.x, transformed.y, transformed.z, (shaded >> 16) & 0xFF, (shaded >> 8) & 0xFF, shaded & 0xFF, (shaded >> 24) & 0xFF);
                }
            }
        }
        buffer.flip();

        ImmediateRenderer.drawWorld(VertexFormat.DrawMode.TRIANGLES, new Matrix4f(), buffer, buffer.remaining() / 16, true);
        MemoryUtil.memFree(buffer);
    }

    private void a(MatrixStack stack, Vec3d renderPos, int color) {
        Matrix4f matrix = stack.peek().getPositionMatrix();
        Vec3d cam = aM_.gameRenderer.getCamera().getCameraPos();
        float height = this.f.getHeight() + 0.15f;
        float radius = this.f.getWidth() * 0.8f;
        double time = System.currentTimeMillis() % 1750.0d;
        boolean inverted = time > 875.0d;
        double progress = time / 875.0d;
        double progress2 = inverted ? progress - 1.0d : 1.0d - progress;
        double ease = progress2 < 0.5d ? 2.0d * progress2 * progress2 : 1.0d - (Math.pow(((-2.0d) * progress2) + 2.0d, 2.0d) / 2.0d);
        float y = (float) ((renderPos.getY() - cam.y) + (((double) height) * ease));
        float offset = (float) (((double) height) * 0.8000001435473696d * Math.min(ease, 1.0d - ease) * (inverted ? -1.0d : 1.0d));
        int[] c = ColorUtil.b(color);
        int r = c[0];
        int g = c[1];
        int bl = c[2];
        int a = c[3];
        double cx = renderPos.getX() - cam.x;
        double cz = renderPos.getZ() - cam.z;

        ByteBuffer skirt = MemoryUtil.memAlloc(362 * 2 * 16);
        for (int deg = 0; deg <= 360; deg++) {
            double rad = Math.toRadians(deg);
            float x = (float) (cx + (Math.cos(rad) * ((double) radius)));
            float z = (float) (cz + (Math.sin(rad) * ((double) radius)));
            ImmediateRenderer.putVertexColor(skirt, x, y, z, r, g, bl, (int) (a * 0.55f));
            ImmediateRenderer.putVertexColor(skirt, x, y + offset, z, r, g, bl, 0);
        }
        skirt.flip();
        ImmediateRenderer.drawWorld(VertexFormat.DrawMode.TRIANGLE_STRIP, matrix, skirt, skirt.remaining() / 16);
        MemoryUtil.memFree(skirt);

        ByteBuffer outline = MemoryUtil.memAlloc(360 * 2 * 16);
        for (int deg2 = 0; deg2 < 360; deg2++) {
            double a0 = Math.toRadians(deg2);
            double a1 = Math.toRadians(deg2 + 1);
            ImmediateRenderer.putVertexColor(outline, (float) (cx + (Math.cos(a0) * ((double) radius))), y, (float) (cz + (Math.sin(a0) * ((double) radius))), r, g, bl, a);
            ImmediateRenderer.putVertexColor(outline, (float) (cx + (Math.cos(a1) * ((double) radius))), y, (float) (cz + (Math.sin(a1) * ((double) radius))), r, g, bl, a);
        }
        outline.flip();
        ImmediateRenderer.drawWorld(VertexFormat.DrawMode.DEBUG_LINES, matrix, outline, outline.remaining() / 16);
        MemoryUtil.memFree(outline);
    }

    private void a(MatrixStack stack, Vec3d renderPos, float ringWidth, float ringScale, float moving, int color, float anim) {
        int[] rgba = ColorUtil.b(color);
        Identifier bloom = Identifier.of("delta", "pictures/bloom.png");
        a(stack, renderPos, ringWidth, ringScale, moving, 1.5f * anim, rgba[0], rgba[1], rgba[2], rgba[3], bloom);
        a(stack, renderPos, ringWidth, ringScale, moving, 0.6f * anim, rgba[0], rgba[1], rgba[2], rgba[3], bloom);
    }

    private void a(MatrixStack stack, Vec3d renderPos, float ringWidth, float ringScale, float moving, float size, int red, int green, int blue, int alpha, Identifier texture) {
        net.minecraft.client.texture.AbstractTexture abstractTexture = aM_.getTextureManager().getTexture(texture);
        if (abstractTexture == null || abstractTexture.getGlTexture() == null) return;
        com.mojang.blaze3d.textures.GpuTextureView view = com.mojang.blaze3d.systems.RenderSystem.getDevice().createTextureView(abstractTexture.getGlTexture());
        if (view == null) return;
        try {
            a(stack, renderPos, ringWidth, ringScale, moving, size, red, green, blue, alpha, view);
        } finally {
            view.close();
        }
        return;
    }

    private void a(MatrixStack stack, Vec3d renderPos, float ringWidth, float ringScale, float moving, float size, int red, int green, int blue, int alpha, com.mojang.blaze3d.textures.GpuTextureView view) {
        Quaternionf cameraRotation = aM_.gameRenderer.getCamera().getRotation();
        Vec3d cam = aM_.gameRenderer.getCamera().getCameraPos();
        float half = size / 2.0f;
        ByteBuffer buffer = MemoryUtil.memAlloc((360 / 20) * 6 * 24);
        Matrix4f base = new Matrix4f(stack.peek().getPositionMatrix());
        for (int i = 0; i < 360; i += 20) {
            float angle = (float) Math.toRadians(i + (moving * 0.3f));
            float offsetX = ((float) Math.sin(angle)) * ringWidth * ringScale;
            float offsetZ = ((float) Math.cos(angle)) * ringWidth * ringScale;
            float offsetY = 0.1f + (this.f.getHeight() * Math.abs((float) Math.sin(i)));
            Matrix4f local = new Matrix4f(base);
            local.translate((float) (renderPos.getX() + ((double) offsetX) - cam.x), (float) (renderPos.getY() + ((double) offsetY) - cam.y), (float) (renderPos.getZ() + ((double) offsetZ) - cam.z));
            local.rotate(cameraRotation);
            Vector3f v00 = new Vector3f(-half, -half, 0.0f).mulPosition(local);
            Vector3f v01 = new Vector3f(-half, half, 0.0f).mulPosition(local);
            Vector3f v11 = new Vector3f(half, half, 0.0f).mulPosition(local);
            Vector3f v10 = new Vector3f(half, -half, 0.0f).mulPosition(local);
            ImmediateRenderer.putVertexTextured(buffer, v00.x, v00.y, v00.z, 0.0f, 0.0f, red, green, blue, alpha);
            ImmediateRenderer.putVertexTextured(buffer, v01.x, v01.y, v01.z, 0.0f, 1.0f, red, green, blue, alpha);
            ImmediateRenderer.putVertexTextured(buffer, v11.x, v11.y, v11.z, 1.0f, 1.0f, red, green, blue, alpha);
            ImmediateRenderer.putVertexTextured(buffer, v00.x, v00.y, v00.z, 0.0f, 0.0f, red, green, blue, alpha);
            ImmediateRenderer.putVertexTextured(buffer, v11.x, v11.y, v11.z, 1.0f, 1.0f, red, green, blue, alpha);
            ImmediateRenderer.putVertexTextured(buffer, v10.x, v10.y, v10.z, 1.0f, 0.0f, red, green, blue, alpha);
        }
        buffer.flip();
        ImmediateRenderer.drawWorldTextured(view, new Matrix4f(), buffer, buffer.remaining() / 24, true);
        MemoryUtil.memFree(buffer);
    }

    private Vec3d a(LivingEntity entity, float tickDelta) {
        return new Vec3d(MathHelper.lerp(tickDelta, entity.lastX, entity.getX()), MathHelper.lerp(tickDelta, entity.lastY, entity.getY()), MathHelper.lerp(tickDelta, entity.lastZ, entity.getZ()));
    }
}
