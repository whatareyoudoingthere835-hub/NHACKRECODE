package aethereal.module.misc;

import aethereal.core.Category;
import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.core.Module;
import aethereal.core.ModuleRegister;
import aethereal.friend.FriendConstructor;
import aethereal.setting.BooleanSetting;
import lombok.Generated;

import java.util.regex.Pattern;

import static aethereal.core.Interface.aM_;

@ModuleRegister(a = "Streamer Mode", b = "Скрывает личные данные при стриминге и записи", c = Category.Misc)
public class StreamerMode extends Module {
    private final BooleanSetting b = new BooleanSetting("Скрывать скины игроков", true);
    private final BooleanSetting c = new BooleanSetting("Скрывать имена друзей", true);
    private final BooleanSetting d = new BooleanSetting("Скрывать номер анархии", true);

    @Generated
    public BooleanSetting q() {
        return this.b;
    }

    @Generated
    public BooleanSetting r() {
        return this.c;
    }

    @Generated
    public BooleanSetting s() {
        return this.d;
    }

    public StreamerMode() {
        a(this.b, this.c, this.d);
    }

    public String a(String text) {
        String username = (aM_.getSession() != null && aM_.getSession().getUsername() != null) ? aM_.getSession().getUsername() : "";
        String result = text.replaceAll("(?i)" + Pattern.quote(username), "Protected");
        if (this.c.c().booleanValue() && Delta.h() != null && Delta.h().d() != null && Delta.h().d().e() != null) {
            for (FriendConstructor friend : Delta.h().d().e().a()) {
                result = Pattern.compile(Pattern.quote(friend.a()), Pattern.CASE_INSENSITIVE).matcher(result).replaceAll("Protected");
            }
        }
        if (this.d.c().booleanValue()) {
            result = result.replaceAll("Анархия-\\d+", "Анархия-???");
        }
        return result;
    }
}
