package aethereal.module.player;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;
import aethereal.util.InventoryUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.ModuleRegister;
import aethereal.event.InputEvent;
import aethereal.event.PacketEvent;

import aethereal.setting.BindSetting;
import aethereal.setting.BooleanSetting;
import java.util.Objects;
import lombok.Generated;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;

@ModuleRegister(a = "Elytra Helper", b = "Выполняет действия с элитрой по нажатию назначенной клавиши", c = Category.Player)
public class ElytraHelper extends Module implements Interface {
    private final BooleanSetting b = new BooleanSetting("Автостарт после свапа", false);
    private final BooleanSetting c;
    private final BooleanSetting d;
    private final BindSetting e;
    private final BindSetting f;
    private boolean g;
    private boolean h;
    private int i;

    @Generated
    public BooleanSetting q() {
        return this.b;
    }

    @Generated
    public BooleanSetting r() {
        return this.c;
    }

    @Generated
    public BooleanSetting s() {
        return this.d;
    }

    @Generated
    public BindSetting t() {
        return this.e;
    }

    @Generated
    public BindSetting u() {
        return this.f;
    }

    @Generated
    public boolean v() {
        return this.g;
    }

    @Generated
    public boolean w() {
        return this.h;
    }

    @Generated
    public int x() {
        return this.i;
    }

    public ElytraHelper() {
        BooleanSetting booleanSetting = new BooleanSetting("Использовать /fly при свапе", false);
        BooleanSetting booleanSetting2 = this.b;
        Objects.requireNonNull(booleanSetting2);
        this.c = (BooleanSetting) booleanSetting.a(booleanSetting2::c);
        BooleanSetting booleanSetting3 = new BooleanSetting("Автофейерверк", false);
        BooleanSetting booleanSetting4 = this.b;
        Objects.requireNonNull(booleanSetting4);
        this.d = (BooleanSetting) booleanSetting3.a(booleanSetting4::c);
        this.e = new BindSetting("Кнопка фейерверка", -1).a(() -> {
            z();
        });
        this.f = new BindSetting("Кнопка переключения", -1).a(() -> {
            int slot = aM_.player.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA ? InventoryUtil.a() : InventoryUtil.b(Items.ELYTRA);
            Delta.h().d().v().a().b(slot, 1, 1);
            if (this.b.c().booleanValue() && InventoryUtil.b(Items.ELYTRA) == slot) {
                this.i = aM_.player.age;
                this.g = true;
            }
        });
        a(this.f, this.e, this.b, this.c, this.d);
    }

    @EventTarget
    public void a(InputEvent event) {
        if (aM_.player.age < 5) {
            this.g = false;
        } else if (this.g && y()) {
            b(event);
        }
    }

    private boolean y() {
        if (!this.c.c().booleanValue() || this.h) {
            return true;
        }
        if (this.i + 1 == aM_.player.age) {
            aM_.player.networkHandler.sendChatCommand("fly");
        }
        if (aM_.player.getAbilities().allowFlying && this.i <= aM_.player.age && aM_.player.isOnGround()) {
            double x = aM_.player.getX();
            double y = aM_.player.getY() + 0.19999997317790985d;
            double z = aM_.player.getZ();
            aM_.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, aM_.player.horizontalCollision));
            aM_.player.setPosition(x, y, z);
            this.i = aM_.player.age + 9;
        }
        if (aM_.player.getAbilities().allowFlying && !aM_.player.isOnGround()) {
            aM_.player.getAbilities().flying = true;
            aM_.player.setVelocity(0.0d, 0.0d, 0.0d);
            aM_.player.sendAbilitiesUpdate();
            this.g = false;
        }
        if (b(15) || (b(3) && aM_.player.getEquippedStack(EquipmentSlot.CHEST).getItem() != Items.ELYTRA)) {
            this.g = false;
            return false;
        }
        return false;
    }

    private void b(InputEvent event) {
        boolean wearingElytra = aM_.player.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA;
        if (!aM_.player.isGliding() && wearingElytra) {
            event.b(aM_.player.age % 2 == 0);
            this.i = aM_.player.age;
            if (!this.d.c().booleanValue()) {
                this.g = false;
            }
        }
        if (aM_.player.isGliding() && this.d.c().booleanValue() && !aM_.player.isTouchingWater() && !aM_.player.isOnGround() && b(2)) {
            z();
            this.g = false;
        }
        if (b(10)) {
            this.g = false;
        }
    }

    private void z() {
        if (aM_.player.isGliding()) {
            Delta.h().d().v().b().a(Items.FIREWORK_ROCKET.getDefaultStack());
        }
    }

    private boolean b(int delay) {
        return this.i + delay < aM_.player.age;
    }

    @EventTarget
    public void a(PacketEvent event) {
        if (event.c()) {
            GameMessageS2CPacket class_7439VarD = (GameMessageS2CPacket) event.d();
            if (class_7439VarD instanceof GameMessageS2CPacket) {
                GameMessageS2CPacket chat = class_7439VarD;
                if (this.g && chat.content().getString().contains("Эту команду могут писать только донатеры выше рангом")) {
                    this.h = true;
                }
            }
        }
    }

    @Override
    public void c() {
        super.c();
        this.g = false;
    }
}
