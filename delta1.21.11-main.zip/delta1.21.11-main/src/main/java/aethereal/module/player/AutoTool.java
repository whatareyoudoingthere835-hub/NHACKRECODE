package aethereal.module.player;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.core.ModuleRegister;
import aethereal.event.TickEvent;
import aethereal.handler.InventoryHandler;

import java.util.Comparator;
import java.util.stream.IntStream;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ShovelItem;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.hit.BlockHitResult;

@ModuleRegister(a = "Auto Tool", b = "Автоматически выбирает подходящий инструмент для блока", c = Category.Player)
public class AutoTool extends Module implements Interface {
    private final int[] b = {-1, -1};

    @EventTarget
    public void a(TickEvent event) {
        int bestSlot;
        InventoryHandler handler = Delta.h().d().v().a();
        if (handler.a().isEmpty()) {
            if (aM_.crosshairTarget instanceof BlockHitResult class_3965Var) {
                BlockHitResult hit = class_3965Var;
                if (aM_.options.attackKey.isPressed()) {
                    if (this.b[0] != -1 || (bestSlot = a(aM_.world.getBlockState(hit.getBlockPos()))) == -1) {
                        return;
                    }
                    this.b[0] = aM_.player.getInventory().getSelectedSlot();
                    if (bestSlot > 8) {
                        this.b[1] = bestSlot;
                        handler.a(bestSlot, this.b[0], 1);
                        return;
                    } else {
                        aM_.player.getInventory().setSelectedSlot(bestSlot);
                        return;
                    }
                }
            }
            if (this.b[0] == -1) {
                return;
            }
            if (this.b[1] == -1) {
                aM_.player.getInventory().setSelectedSlot(this.b[0]);
            } else {
                handler.a(this.b[1], this.b[0], 1);
            }
            this.b[0] = -1;
            this.b[1] = -1;
        }
    }

    private int a(BlockState state) {
        int shears;
        PlayerInventory inventory = aM_.player.getInventory();
        return (!state.isOf(Blocks.COBWEB) || (shears = IntStream.range(0, inventory.getMainStacks().size()).filter(i -> {
            return inventory.getStack(i).isOf(Items.SHEARS);
        }).findFirst().orElse(-1)) == -1) ? IntStream.range(0, inventory.getMainStacks().size()).filter(i2 -> {
            return inventory.getStack(i2).getMiningSpeedMultiplier(state) > 1.0f && a(inventory.getStack(i2), state);
        }).boxed().max(Comparator.comparingDouble(i3 -> {
            return inventory.getStack(i3.intValue()).getMiningSpeedMultiplier(state);
        })).orElse(-1).intValue() : shears;
    }

    private boolean a(ItemStack stack, BlockState state) {
        if (state.isIn(BlockTags.AXE_MINEABLE)) {
            return stack.getItem() instanceof AxeItem;
        }
        if (state.isIn(BlockTags.PICKAXE_MINEABLE)) {
            return net.minecraft.registry.Registries.ITEM.getId(stack.getItem()).getPath().endsWith("pickaxe");
        }
        if (state.isIn(BlockTags.SHOVEL_MINEABLE)) {
            return stack.getItem() instanceof ShovelItem;
        }
        if (state.isIn(BlockTags.HOE_MINEABLE)) {
            return stack.getItem() instanceof HoeItem;
        }
        return true;
    }
}
