package aethereal.module.render;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.core.Module;
import aethereal.render.ColorUtil;
import aethereal.util.Look;
import aethereal.util.MathUtil;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.DrawEvent;
import aethereal.setting.BooleanSetting;

import aethereal.setting.MultiModeSetting;
import aethereal.setting.SliderSetting;
import aethereal.render.ImmediateRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.network.ClientPlayerEntity;
import org.joml.Matrix4f;
import org.joml.Matrix3x2fStack;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import org.lwjgl.system.MemoryUtil;

@ModuleRegister(a = "Pointers", b = "Указывает лучами направление к игрокам", c = Category.Render)
public class Pointers extends Module {
    private final MultiModeSetting b = new MultiModeSetting("Визуальные настройки", new BooleanSetting("Фильтр по друзьям", false), new BooleanSetting("Трассировка до игрока", true), new BooleanSetting("Навигационная стрелка", true));
    private final SliderSetting c = new SliderSetting("Размер стрелки", 7.0f, 5.0f, 15.0f, 1.0f);
    private final SliderSetting d = new SliderSetting("Отступ от центра", 30.0f, 20.0f, 50.0f, 1.0f);
    private float e;

    public Pointers() {
        a(this.b, this.c, this.d);
    }

    @EventTarget
    public void a(DrawEvent event) {
        if (event.c() && this.b.a("Трассировка до игрока").c().booleanValue()) {

            Camera camera = aM_.gameRenderer.getCamera();
            Vec3d cam = camera.getCameraPos();
            Vec3d start = new Vec3d(0.0d, 0.0d, 27.0d).rotateX((float) (-Math.toRadians(camera.getPitch()))).rotateY((float) (-Math.toRadians(camera.getYaw()))).add(cam);
            Matrix4f matrix = event.j().peek().getPositionMatrix();
            List<float[]> segments = new ArrayList<>();
            for (Entity _e : aM_.world.getEntities()) {
                if (!(_e instanceof ClientPlayerEntity player)) continue;
                if (player != aM_.player && player.isAlive()) {
                    Vec3d pos = MathUtil.a(player, event.g()).add(0.0d, player.getHeight() / 2.0f, 0.0d);
                    boolean isFriend = Delta.h().d().e().d(player.getName().getString());
                    if (!this.b.a("Фильтр по друзьям").c().booleanValue() || isFriend) {
                        float r = isFriend ? 0.0f : 1.0f;
                        float g2 = 1.0f;
                        float b2 = 1.0f;
                        segments.add(new float[]{(float) (start.getX() - cam.x), (float) (start.getY() - cam.y), (float) (start.getZ() - cam.z), r, g2, b2});
                        segments.add(new float[]{(float) (pos.getX() - cam.x), (float) (pos.getY() - cam.y), (float) (pos.getZ() - cam.z), r, g2, b2});
                    }
                }
            }
            if (!segments.isEmpty()) {
                ByteBuffer buffer = MemoryUtil.memAlloc(segments.size() * 20);
                for (float[] v : segments) {
                    ImmediateRenderer.putVertexColor(buffer, v[0], v[1], v[2], (int) (v[3] * 255.0f), (int) (v[4] * 255.0f), (int) (v[5] * 255.0f), 255);
                }
                buffer.flip();
                ImmediateRenderer.drawWorld(VertexFormat.DrawMode.DEBUG_LINES, matrix, buffer, segments.size());
                MemoryUtil.memFree(buffer);
            }
        }
        if (event.b() && this.b.a("Навигационная стрелка").c().booleanValue()) {
            this.e = MathUtil.c(this.e, this.e + MathHelper.wrapDegrees(Look.b() - this.e), 2.0f);
            for (Entity _e : aM_.world.getEntities()) {
                if (!(_e instanceof ClientPlayerEntity player2)) continue;
                if (player2 != aM_.player && player2.isAlive()) {
                    boolean isFriend2 = Delta.h().d().e().d(player2.getName().getString());
                    if (!this.b.a("Фильтр по друзьям").c().booleanValue() || isFriend2) {
                        Vec3d pos2 = MathUtil.a(player2, event.g());
                        Vec3d eye = MathUtil.a(aM_.player, event.g());
                        float angle = MathHelper.wrapDegrees(((float) Math.toDegrees(Math.atan2(eye.x - pos2.getX(), pos2.getZ() - eye.z))) - this.e);
                        float radians = (float) Math.toRadians(angle);
                        Matrix3x2fStack stack = event.i().getMatrices();
                        stack.pushMatrix();
                        stack.translate((aM_.getWindow().getScaledWidth() / 2.0f) + (((float) Math.sin(radians)) * this.d.c().floatValue()), (aM_.getWindow().getScaledHeight() / 2.0f) - (((float) Math.cos(radians)) * this.d.c().floatValue()));
                        stack.rotate(radians);
                        event.d().a(stack, Identifier.of("delta", "pictures/pointer.png"), (-this.c.c().floatValue()) / 2.0f, (-this.c.c().floatValue()) / 2.0f, this.c.c().floatValue(), this.c.c().floatValue(), 0.0f, isFriend2 ? ColorUtil.a(85, 255, 85, InterfaceC0020Opcode.aL) : ColorUtil.a(255, 255, 255, InterfaceC0020Opcode.aL));
                        stack.popMatrix();
                    }
                }
            }
        }
    }
}
