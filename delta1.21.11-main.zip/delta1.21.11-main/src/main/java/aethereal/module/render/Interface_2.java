package aethereal.module.render;

import aethereal.ui.widget.Widget;
import aethereal.core.Delta;
import aethereal.core.Module;
import aethereal.config.ThemeInfo;
import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.GlobalEvent;
import aethereal.core.ModuleRegister;
import aethereal.event.DrawEvent;
import aethereal.setting.BooleanSetting;
import aethereal.setting.ColorSetting;
import aethereal.setting.MultiModeSetting;
import aethereal.ui.widget.ArmorWidget;
import aethereal.ui.widget.CooldownsWidget;
import aethereal.ui.widget.EnvironmentWidget;
import aethereal.ui.widget.HotkeysWidget;
import aethereal.ui.widget.ItemsWidget;
import aethereal.ui.widget.NotificationWidget;
import aethereal.ui.widget.PotionWidget;
import aethereal.ui.widget.StaffWidget;
import aethereal.ui.widget.TargetWidget;
import aethereal.ui.widget.WatermarkWidget;

import java.util.ArrayList;
import java.util.List;
import lombok.Generated;

@ModuleRegister(a = "Interface", b = "Отображает выбранные элементы интерфейса на экране", c = Category.Render)
public class Interface_2 extends Module {
    private final ColorSetting b = new ColorSetting("Глобальный цвет интерфейса", Integer.valueOf(Delta.h().d().o().a(ThemeInfo.PRIMARY).a()));
    private final MultiModeSetting c = new MultiModeSetting("Элементы интерфейса", new BooleanSetting("Клавиши", true), new BooleanSetting("Таргет-худ", true), new BooleanSetting("Задержки", true), new BooleanSetting("Инфо-панель", true), new BooleanSetting("Уведомления", true), new BooleanSetting("Зелья", true), new BooleanSetting("Предметы", true), new BooleanSetting("Броня", true), new BooleanSetting("Стафф", true), new BooleanSetting("Окружение", true));
    private final List<Widget> d = new ArrayList<>();

    @Generated
    public List<Widget> q() {
        return this.d;
    }

    public Interface_2() {
        this.b.a(color -> {
            Delta.h().d().o().a(ThemeInfo.PRIMARY).a(color.intValue());
        });
        a(this.b, this.c);
        this.d.add(new ArmorWidget());
        this.d.add(new HotkeysWidget());
        this.d.add(new CooldownsWidget());
        this.d.add(new TargetWidget());
        this.d.add(new WatermarkWidget());
        this.d.add(new PotionWidget());
        this.d.add(new ItemsWidget());
        this.d.add(new NotificationWidget());
        this.d.add(new StaffWidget());
        this.d.add(new EnvironmentWidget());
        a(true);
    }

    @EventTarget
    public void a(DrawEvent event) {
        if (event.b()) {
            Delta.h().d().o().a(ThemeInfo.PRIMARY).a(this.b.c().intValue());
            for (Widget widget : this.d) {
                BooleanSetting setting = this.c.a(widget.j().j());
                if (setting != null && setting.c().booleanValue()) {
                    try {
                        widget.a(event);
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }

    @EventTarget
    public void a(GlobalEvent event) {
        for (Widget widget : this.d) {
            BooleanSetting setting = this.c.a(widget.j().j());
            if (setting != null && setting.c().booleanValue()) {
                try {
                    widget.a(event);
                } catch (Exception ignored) {
                }
            }
        }
    }

    @Generated
    public ColorSetting r() {
        return this.b;
    }
}
