package aethereal.module.render;

import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Module;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;
import aethereal.util.ProjectUtil;
import aethereal.util.ServerUtil;

import aethereal.config.ThemeInfo;
import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.DrawEvent;

import aethereal.setting.ColorSetting;
import aethereal.setting.ModeSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;

@ModuleRegister(a = "Entity Box", b = "Отображает боксы вокруг сущностей", c = Category.Render)
public class EntityBox extends Module {
    private final ModeSetting b = new ModeSetting("Тип визуализации", "Квадрат", "Квадрат", "Углы", "Заливка", "Отключен");
    private final ModeSetting c = new ModeSetting("Источник цвета", "Клиентский", "Клиентский", "Статичный");
    private final ModeSetting d = (ModeSetting) new ModeSetting("Бар здоровья", "Отключен", "Отключен", "Стандартный").a(() -> {
        return Boolean.valueOf(this.b.l("Квадрат") || this.b.l("Углы"));
    });
    private final ColorSetting e = (ColorSetting) new ColorSetting("Цвет визуализации", Integer.valueOf(ColorUtil.a(255, 255, 255, 255))).a(() -> {
        return Boolean.valueOf(this.c.l("Статичный"));
    });

    public EntityBox() {
        a(this.b, this.c, this.d, this.e);
    }

    @EventTarget
    public void a(DrawEvent event) {
        if (this.b.l("Заливка")) {
            if (event.c()) {
                for (Entity entity : aM_.world.getEntities()) {
                    if (a(entity)) {
                        event.e().a(event.j(), entity.getBoundingBox().offset(MathUtil.a(entity, event.g()).subtract(entity.getEntityPos())), this.c.l("Статичный") ? this.e.c().intValue() : Delta.h().d().o().a(ThemeInfo.PRIMARY).a(), 0.75f, true);
                    }
                }
                return;
            }
            return;
        }
        if (event.b()) {
            if (this.b.l("Квадрат") || this.b.l("Углы")) {
                Matrix4f matrix = new Matrix4f();
                for (LivingEntity living : aM_.world.getEntitiesByClass(LivingEntity.class, aM_.player.getBoundingBox().expand(256.0), e -> true)) {
                    if (living == aM_.player) continue;
                    if (!a(living)) continue;
                    Box box = living.getBoundingBox().offset(MathUtil.a(living, event.g()).subtract(living.getEntityPos()));
                    float[] bounds = ProjectUtil.a(box);
                    if (bounds != null) {
                        boolean healthBar = !this.d.l("Отключен");
                        float percent = healthBar ? Math.min(Math.max(0.0f, ServerUtil.a.a(living)) / Math.max(1.0f, living.getMaxHealth()), 1.0f) : 0.0f;
                        int healthColor = ColorUtil.b(ColorUtil.a(255, 0, 0, 255), ColorUtil.a(0, 255, 0, 255), percent);
                        int color = this.c.l("Статичный") ? this.e.c().intValue() : ColorUtil.a(Delta.h().d().o().a(ThemeInfo.PRIMARY).a(), 255);
                        event.e().a(matrix, bounds[0], bounds[1], bounds[2], bounds[3], color, this.b.l("Углы"), healthBar, percent, healthColor);
                    }
                }
            }
        }
    }

    private boolean a(Entity entity) {
        if ((entity instanceof PlayerEntity) || (entity instanceof ItemEntity)) {
            return (entity == aM_.player && aM_.options.getPerspective().isFirstPerson()) ? false : true;
        }
        return false;
    }

}
