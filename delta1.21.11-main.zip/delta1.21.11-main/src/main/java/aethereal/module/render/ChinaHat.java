package aethereal.module.render;

import aethereal.ui.shader.GradientUtil;
import aethereal.core.Interface;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.core.Module;
import aethereal.render.ColorUtil;
import aethereal.render.ImmediateRenderer;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.ModuleRegister;
import aethereal.event.DrawEvent;

import aethereal.setting.ColorSetting;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import org.lwjgl.system.MemoryUtil;

@ModuleRegister(a = "China Hat", b = "Надевает китайскую шляпу на голову вашего персонажа", c = Category.Render)
public class ChinaHat extends Module {
    private final ColorSetting b = new ColorSetting("Цвет визуализации шляпы", Integer.valueOf(ColorUtil.a(InterfaceC0020Opcode.aS, InterfaceC0020Opcode.bh, 255, 255)));

    public ChinaHat() {
        a(this.b);
    }

    @EventTarget
    public void a(DrawEvent event) {
        if (!event.c() || aM_.world == null || aM_.player == null) {
            return;
        }
        Camera camera = aM_.gameRenderer.getCamera();
        Vec3d cam = camera.getCameraPos();
        List<float[]> tris = new ArrayList<>();
        long time = System.currentTimeMillis();
        for (PlayerEntity player : aM_.world.getEntitiesByClass(PlayerEntity.class, aM_.player.getBoundingBox().expand(64.0d), p -> true)) {
            boolean friend = Delta.h().d().e().d(player.getName().getString());
            if (player != aM_.player && !friend) {
                continue;
            }
            if (player == aM_.player && aM_.options.getPerspective().isFirstPerson()) {
                continue;
            }
            if (!player.isAlive()) {
                continue;
            }
            int postColor = player == aM_.player ? this.b.c().intValue() : ColorUtil.a(0, InterfaceC0020Opcode.bk, 0, 255);
            Vec3d feet = player.getEntityPos();
            float yawRad = (float) Math.toRadians(player.getHeadYaw());
            float pitchRad = (float) Math.toRadians(player.getPitch());
            float fx = -MathHelper.sin(yawRad);
            float fz = MathHelper.cos(yawRad);
            float rx = MathHelper.cos(yawRad);
            float rz = MathHelper.sin(yawRad);
            float cosP = MathHelper.cos(pitchRad);
            float sinP = MathHelper.sin(pitchRad);
            float brimY = (float) (player.getEyePos().y - feet.y) + (player.getInventory().getStack(39).isEmpty() ? 0.25f : 0.31f);
            float px = (float) (feet.x - cam.x);
            float py = (float) (feet.y - cam.y);
            float pz = (float) (feet.z - cam.z);
            float radius = (float) (player.getBoundingBox().maxX - player.getBoundingBox().minX);
            int segments = 180;
            for (int i = 0; i < segments; i++) {
                float a1 = (float) (i * Math.PI * 2.0d / segments);
                float a2 = (float) ((i + 1) * Math.PI * 2.0d / segments);
                int col = GradientUtil.a(3, i * 8, postColor, ColorUtil.b(postColor, 0.5f), time);

                float[] t1 = local(px, py + brimY, pz, rx, rz, fx, fz, cosP, sinP, MathHelper.sin(a1) * radius, 0.0f, MathHelper.cos(a1) * radius);
                float[] t2 = local(px, py + brimY, pz, rx, rz, fx, fz, cosP, sinP, MathHelper.sin(a2) * radius, 0.0f, MathHelper.cos(a2) * radius);
                float[] tip = local(px, py + brimY, pz, rx, rz, fx, fz, cosP, sinP, 0.0f, 0.3f, 0.0f);
                tris.add(withColor(t1, col));
                tris.add(withColor(t2, col));
                tris.add(withColor(tip, col));

                float rIn = radius - 0.02f;
                float[] b1 = local(px, py + brimY, pz, rx, rz, fx, fz, cosP, sinP, MathHelper.sin(a1) * radius, 0.0f, MathHelper.cos(a1) * radius);
                float[] b2 = local(px, py + brimY, pz, rx, rz, fx, fz, cosP, sinP, MathHelper.sin(a2) * radius, 0.0f, MathHelper.cos(a2) * radius);
                float[] b3 = local(px, py + brimY, pz, rx, rz, fx, fz, cosP, sinP, MathHelper.sin(a2) * rIn, 0.0f, MathHelper.cos(a2) * rIn);
                float[] b4 = local(px, py + brimY, pz, rx, rz, fx, fz, cosP, sinP, MathHelper.sin(a1) * rIn, 0.0f, MathHelper.cos(a1) * rIn);
                tris.add(withColor(b1, col));
                tris.add(withColor(b2, col));
                tris.add(withColor(b3, col));
                tris.add(withColor(b1, col));
                tris.add(withColor(b3, col));
                tris.add(withColor(b4, col));
            }
        }
        if (tris.isEmpty()) {
            return;
        }
        Matrix4f matrix = event.j().peek().getPositionMatrix();
        ByteBuffer buffer = MemoryUtil.memAlloc(tris.size() * 20);
        for (float[] v : tris) {
            ImmediateRenderer.putVertexColor(buffer, v[0], v[1], v[2], (int) v[3], (int) v[4], (int) v[5], (int) v[6]);
        }
        buffer.flip();
        ImmediateRenderer.drawWorld(com.mojang.blaze3d.vertex.VertexFormat.DrawMode.TRIANGLES, matrix, buffer, tris.size());
        MemoryUtil.memFree(buffer);
    }

    private static float[] local(float px, float py, float pz, float rx, float rz, float fx, float fz,
                                 float cosP, float sinP, float x, float y, float z) {
        float worldX = x * rx + (z * cosP + y * sinP) * fx;
        float worldY = y * cosP - z * sinP;
        float worldZ = x * rz + (z * cosP + y * sinP) * fz;
        return new float[]{px + worldX, py + worldY, pz + worldZ};
    }

    private static float[] withColor(float[] pos, int rgba) {
        int[] c = ColorUtil.b(rgba);
        return new float[]{pos[0], pos[1], pos[2], c[0], c[1], c[2], c[3]};
    }
}
