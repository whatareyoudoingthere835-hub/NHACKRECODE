package aethereal.render;

import static aethereal.core.Interface.aM_;

import aethereal.config.BaseProcessor;
import aethereal.core.EventTarget;
import aethereal.core.Interface;
import aethereal.api.Compile;
import aethereal.event.DrawEvent;

import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.render.Camera;
import net.minecraft.item.ItemStack;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;

public class Draw3DProcessor extends BaseProcessor implements Interface {
    private static final float PIXEL_WORLD_SCALE = 0.0016f;

    @Override
    @Compile
    public void setup() {
    }

    @Override
    public void unSetup() {
    }

    @EventTarget(a = 4)
    public void a(DrawEvent event) {
    }

    public void a(MatrixStack matrices, Box box, int color, float width) {
        a(matrices, box, color, width, false);
    }

    public void a(MatrixStack matrices, Box box, int color, float width, boolean filled) {
        Camera camera = aM_.gameRenderer.getCamera();
        Vec3d cam = camera.getCameraPos();
        ByteBuffer buffer = MemoryUtil.memAlloc((12 * 6 + (filled ? 36 : 0)) * 16);
        float x0 = (float) (box.minX - cam.x);
        float y0 = (float) (box.minY - cam.y);
        float z0 = (float) (box.minZ - cam.z);
        float x1 = (float) (box.maxX - cam.x);
        float y1 = (float) (box.maxY - cam.y);
        float z1 = (float) (box.maxZ - cam.z);
        float dist = (float) Math.sqrt((double) ((x0 + x1) * (x0 + x1) + (y0 + y1) * (y0 + y1) + (z0 + z1) * (z0 + z1))) * 0.5f;
        float half = Math.max(0.004f, width * PIXEL_WORLD_SCALE * dist * 0.5f);
        float[][] edges = {
                {x0, y0, z0, x1, y0, z0},
                {x1, y0, z0, x1, y0, z1},
                {x1, y0, z1, x0, y0, z1},
                {x0, y0, z1, x0, y0, z0},
                {x0, y1, z0, x1, y1, z0},
                {x1, y1, z0, x1, y1, z1},
                {x1, y1, z1, x0, y1, z1},
                {x0, y1, z1, x0, y1, z0},
                {x0, y0, z0, x0, y1, z0},
                {x1, y0, z0, x1, y1, z0},
                {x1, y0, z1, x1, y1, z1},
                {x0, y0, z1, x0, y1, z1}};
        for (float[] e : edges) {
            putRibbon(buffer, e[0], e[1], e[2], e[3], e[4], e[5], half, color);
        }
        if (filled) {
            int[] rgba = ColorUtil.b(color);
            int fill = ColorUtil.a(rgba[0], rgba[1], rgba[2], (int) (rgba[3] * 0.28f));
            float[][][] faces = {
                    {{x0, y0, z0}, {x1, y0, z0}, {x1, y1, z0}, {x0, y1, z0}},
                    {{x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}},
                    {{x0, y0, z0}, {x0, y1, z0}, {x0, y1, z1}, {x0, y0, z1}},
                    {{x1, y0, z0}, {x1, y1, z0}, {x1, y1, z1}, {x1, y0, z1}},
                    {{x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}},
                    {{x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}}};
            for (float[][] f : faces) {
                for (int i = 0; i < 6; i++) {
                    int v = new int[]{0, 1, 2, 2, 3, 0}[i];
                    ImmediateRenderer.putVertexColor(buffer, f[v][0], f[v][1], f[v][2], (fill >> 16) & 0xFF, (fill >> 8) & 0xFF, fill & 0xFF, (fill >> 24) & 0xFF);
                }
            }
        }
        buffer.flip();
        ImmediateRenderer.drawWorld(VertexFormat.DrawMode.TRIANGLES, matrices.peek().getPositionMatrix(), buffer, buffer.remaining() / 16);
        MemoryUtil.memFree(buffer);
    }

    public void a(Matrix4f matrix, float minX, float minY, float maxX, float maxY, int color, boolean corners, boolean healthBar, float healthPercent, int healthColor) {
        float left = Math.min(minX, maxX);
        float right = Math.max(minX, maxX);
        float top = Math.min(minY, maxY);
        float bottom = Math.max(minY, maxY);
        float w = right - left;
        float h = bottom - top;
        float screenW = (float) aethereal.core.Interface.aM_.getWindow().getScaledWidth();
        float screenH = (float) aethereal.core.Interface.aM_.getWindow().getScaledHeight();
        if (w <= 0.0f || h <= 0.0f || w > screenW * 1.5f || h > screenH * 1.5f) {
            return;
        }
        if (right < 0.0f || left > screenW || bottom < 0.0f || top > screenH) {
            return;
        }
        float lengthX = corners ? w * 0.25f : w * 0.5f;
        float lengthY = corners ? h * 0.25f : h * 0.5f;

        int quadCount = 16 + (healthBar ? 2 : 0);
        ByteBuffer buffer = MemoryUtil.memAlloc(quadCount * 6 * 16);

        int outlineColor = ColorUtil.a(0, 0, 0, 255);

        for (int pass = 0; pass < 2; pass++) {
            boolean isOutline = (pass == 0);
            for (int corner = 0; corner < 4; corner++) {
                float cornerX = (corner & 1) == 0 ? left : right;
                float cornerY = (corner & 2) == 0 ? top : bottom;
                float directionX = (corner & 1) == 0 ? 1.0f : -1.0f;
                float directionY = (corner & 2) == 0 ? 1.0f : -1.0f;
                putBoxSegment(buffer, cornerX, cornerY, directionX * lengthX, 0.0f, isOutline, color, outlineColor);
                putBoxSegment(buffer, cornerX, cornerY, 0.0f, directionY * lengthY, isOutline, color, outlineColor);
            }
        }
        if (healthBar) {
            float l = 0.5f;
            float barHeight = bottom - top;
            float x = (left - 2.0f) - l;
            put2DQuad(buffer, x - l, top - l, 1.5f, barHeight + 1.5f, outlineColor);
            put2DQuad(buffer, x, top + (barHeight * (1.0f - healthPercent)), l, (barHeight * healthPercent) + l, healthColor);
        }
        buffer.flip();
        ImmediateRenderer.draw2D(VertexFormat.DrawMode.TRIANGLES, buffer, buffer.remaining() / 16);
        MemoryUtil.memFree(buffer);
    }

    private static void putBoxSegment(ByteBuffer buffer, float x, float y, float lengthX, float lengthY, boolean outline, int color, int outlineColor) {
        float l = 0.5f;
        float segLeft = Math.min(x, x + lengthX) - (lengthX == 0.0f ? 0.25f : 0.0f);
        float segTop = Math.min(y, y + lengthY) - (lengthY == 0.0f ? 0.25f : 0.0f);
        float segWidth = lengthX == 0.0f ? l : Math.abs(lengthX);
        float segHeight = lengthY == 0.0f ? l : Math.abs(lengthY);
        if (outline) {
            put2DQuad(buffer, segLeft - l, segTop - l, segWidth + 1.0f, segHeight + 1.0f, outlineColor);
        } else {
            put2DQuad(buffer, segLeft, segTop, segWidth, segHeight, color);
        }
    }

    private static void put2DQuad(ByteBuffer buffer, float x, float y, float width, float height, int color) {
        int[] c = ColorUtil.b(color);
        float x1 = x;
        float y1 = y;
        float x2 = x + width;
        float y2 = y + height;

        ImmediateRenderer.putVertexColor(buffer, x1, y1, 0.0f, c[0], c[1], c[2], c[3]);
        ImmediateRenderer.putVertexColor(buffer, x1, y2, 0.0f, c[0], c[1], c[2], c[3]);
        ImmediateRenderer.putVertexColor(buffer, x2, y2, 0.0f, c[0], c[1], c[2], c[3]);

        ImmediateRenderer.putVertexColor(buffer, x1, y1, 0.0f, c[0], c[1], c[2], c[3]);
        ImmediateRenderer.putVertexColor(buffer, x2, y2, 0.0f, c[0], c[1], c[2], c[3]);
        ImmediateRenderer.putVertexColor(buffer, x2, y1, 0.0f, c[0], c[1], c[2], c[3]);
    }

    public void a(MatrixStack matrices, Vec3d start, Vec3d end, Vec3d control, int color, float width) {

        Vec3d ctrl = control != null ? control : start.add(end).multiply(0.5d);
        Camera camera = aM_.gameRenderer.getCamera();
        Vec3d cam = camera.getCameraPos();
        Matrix4f modelView = matrices.peek().getPositionMatrix();
        int segments = control != null ? 40 : 1;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        int aCh = (color >> 24) & 0xFF;

        int vertSize = ImmediateRenderer.worldLineVertexSize();
        ByteBuffer buffer = MemoryUtil.memAlloc(segments * 6 * vertSize);
        Matrix4f projView = ImmediateRenderer.worldLineProjView(modelView);
        Vector4f clip = new Vector4f();
        final float clipEps = 0.05f;

        Vec3d prev = a(start, ctrl, end, 0.0d);
        float ax = (float) (prev.x - cam.x);
        float ay = (float) (prev.y - cam.y);
        float az = (float) (prev.z - cam.z);
        clip.set(ax, ay, az, 1.0f);
        projView.transform(clip);
        float prevW = clip.w;

        for (int i = 1; i <= segments; i++) {
            double t = (double) i / (double) segments;
            Vec3d cur = a(start, ctrl, end, t);
            float bx = (float) (cur.x - cam.x);
            float by = (float) (cur.y - cam.y);
            float bz = (float) (cur.z - cam.z);
            clip.set(bx, by, bz, 1.0f);
            projView.transform(clip);
            float curW = clip.w;

            if (prevW > clipEps || curW > clipEps) {
                float aX = ax;
                float aY = ay;
                float aZ = az;
                float bX = bx;
                float bY = by;
                float bZ = bz;
                float aW = prevW;
                float bW = curW;
                if (aW < clipEps) {
                    float k = (clipEps - aW) / (bW - aW);
                    aX = aX + (bX - aX) * k;
                    aY = aY + (bY - aY) * k;
                    aZ = aZ + (bZ - aZ) * k;
                }
                if (bW < clipEps) {
                    float k = (clipEps - bW) / (aW - bW);
                    bX = bX + (aX - bX) * k;
                    bY = bY + (aY - bY) * k;
                    bZ = bZ + (aZ - bZ) * k;
                }
                float dx = bX - aX;
                float dy = bY - aY;
                float dz = bZ - aZ;
                float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
                if (len > 1.0E-5f) {
                    dx /= len;
                    dy /= len;
                    dz /= len;

                    ImmediateRenderer.putWorldLineVertex(buffer, aX, aY, aZ, dx, dy, dz, r, g, b, aCh, width);
                    ImmediateRenderer.putWorldLineVertex(buffer, bX, bY, bZ, -dx, -dy, -dz, r, g, b, aCh, width);
                    ImmediateRenderer.putWorldLineVertex(buffer, bX, bY, bZ, -dx, -dy, -dz, r, g, b, aCh, -width);
                    ImmediateRenderer.putWorldLineVertex(buffer, aX, aY, aZ, dx, dy, dz, r, g, b, aCh, width);
                    ImmediateRenderer.putWorldLineVertex(buffer, bX, bY, bZ, -dx, -dy, -dz, r, g, b, aCh, -width);
                    ImmediateRenderer.putWorldLineVertex(buffer, aX, aY, aZ, dx, dy, dz, r, g, b, aCh, -width);
                }
            }
            ax = bx;
            ay = by;
            az = bz;
            prevW = curW;
            prev = cur;
        }
        buffer.flip();
        ImmediateRenderer.drawWorldLines(modelView, buffer, buffer.remaining() / (6 * vertSize));
        MemoryUtil.memFree(buffer);
    }

    public void a(DrawContext context, ItemStack stack, float x, float y, int z, float alpha, float scale, boolean overlay) {
        if (!stack.isEmpty()) {
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(x, y);
            context.getMatrices().scale(scale, scale);
            context.drawItem(stack, 0, 0);
            if (overlay) {
                context.drawStackOverlay(aM_.textRenderer, stack, 0, 0);
            }
            context.getMatrices().popMatrix();
        }
    }

    public void a(DrawContext context, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> effect, float x, float y, float z, float scale, float alpha) {
        net.minecraft.util.Identifier texture = net.minecraft.client.gui.hud.InGameHud.getEffectTexture(effect);
        if (texture != null) {
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(x, y);
            context.getMatrices().scale(scale, scale);
            context.drawGuiTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, texture, 0, 0, 18, 18, ColorUtil.a(-1, alpha));
            context.getMatrices().popMatrix();
        }
    }

    private static Vec3d a(Vec3d start, Vec3d control, Vec3d end, double t) {
        double u = 1.0d - t;
        double w0 = u * u;
        double w1 = 2.0d * u * t;
        double w2 = t * t;
        return new Vec3d(
                start.x * w0 + control.x * w1 + end.x * w2,
                start.y * w0 + control.y * w1 + end.y * w2,
                start.z * w0 + control.z * w1 + end.z * w2);
    }

    private static void putRibbon(ByteBuffer buffer, float ax, float ay, float az, float bx, float by, float bz, float half, int color) {
        float dx = bx - ax;
        float dy = by - ay;
        float dz = bz - az;
        float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-5f) {
            return;
        }
        float mx = (ax + bx) * 0.5f;
        float my = (ay + by) * 0.5f;
        float mz = (az + bz) * 0.5f;
        float vx = mx;
        float vy = my;
        float vz = mz;
        float vLen = MathHelper.sqrt(vx * vx + vy * vy + vz * vz);
        if (vLen < 1.0E-5f) {
            vx = 0.0f;
            vy = -1.0f;
            vz = 0.0f;
            vLen = 1.0f;
        }
        float sx = (dy * vz - dz * vy) / len;
        float sy = (dz * vx - dx * vz) / len;
        float sz = (dx * vy - dy * vx) / len;
        float sl = MathHelper.sqrt(sx * sx + sy * sy + sz * sz);
        if (sl < 1.0E-5f) {
            sx = 1.0f;
            sy = 0.0f;
            sz = 0.0f;
            sl = 1.0f;
        }
        sx = sx / sl * half;
        sy = sy / sl * half;
        sz = sz / sl * half;
        int[] c = ColorUtil.b(color);
        ImmediateRenderer.putVertexColor(buffer, ax + sx, ay + sy, az + sz, c[0], c[1], c[2], c[3]);
        ImmediateRenderer.putVertexColor(buffer, bx + sx, by + sy, bz + sz, c[0], c[1], c[2], c[3]);
        ImmediateRenderer.putVertexColor(buffer, bx - sx, by - sy, bz - sz, c[0], c[1], c[2], c[3]);
        ImmediateRenderer.putVertexColor(buffer, ax + sx, ay + sy, az + sz, c[0], c[1], c[2], c[3]);
        ImmediateRenderer.putVertexColor(buffer, bx - sx, by - sy, bz - sz, c[0], c[1], c[2], c[3]);
        ImmediateRenderer.putVertexColor(buffer, ax - sx, ay - sy, az - sz, c[0], c[1], c[2], c[3]);
    }

}
