package aethereal.render;

public class Fonts {
    public static final Font a = new Font("icons");
    public static final Font b = new Font("sf_regular");
    public static final Font c = new Font("onest_regular");
    public static final Font d = new Font("sf_medium");
    public static final Font e = new Font("gt_regular");

    private Fonts() {
    }
}
