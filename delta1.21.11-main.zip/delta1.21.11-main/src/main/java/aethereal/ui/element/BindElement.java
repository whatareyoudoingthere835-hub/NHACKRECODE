package aethereal.ui.element;

import aethereal.util.KeyUtil;
import aethereal.render.ScissorUtil;
import aethereal.core.Delta;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;
import aethereal.config.ThemeInfo;
import aethereal.config.ThemeProcessor;
import aethereal.render.Draw2DProcessor;
import aethereal.setting.BindSetting;

import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2f;
import org.joml.Vector4f;

public class BindElement extends Element_2<BindSetting> {
    private boolean d;

    public boolean isBinding() {
        return this.d;
    }

    public void cancelBinding() {
        this.d = false;
    }

    @Override
    public boolean a(double mouseX, double mouseY, int button) {
        Vector4f vector4f = this.a;
        var setting = this.b;
        if (this.d) {
            if (!(setting instanceof BindSetting)) {
                throw new ClassCastException();
            }
            ((BindSetting) setting).a(Integer.valueOf(-100 + button));
            this.d = false;
            return true;
        }
        if (!MathUtil.a(mouseX, mouseY, vector4f.x, vector4f.y, vector4f.z, vector4f.w)) {
            return false;
        }
        if (button == 0) {
            this.d = true;
            return true;
        }
        if (button != 2) {
            return false;
        }
        if (!(setting instanceof BindSetting)) {
            throw new ClassCastException();
        }
        ((BindSetting) setting).b();
        return true;
    }

    @Override
    public boolean a(int keyCode, int scanCode, int modifiers) {
        if (!this.d) {
            return false;
        }
        var setting = this.b;
        if (!(setting instanceof BindSetting)) {
            throw new ClassCastException();
        }
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_DELETE || keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_BACKSPACE) {
            ((BindSetting) setting).a(Integer.valueOf(-1));
        } else if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {

        } else {
            ((BindSetting) setting).a(Integer.valueOf(keyCode));
        }
        this.d = false;
        return true;
    }

    public BindElement(BindSetting setting) {
        super(setting);
        this.a.w = 11.0f;
    }

    @Override
    public void a(DrawContext context, double mouseX, double mouseY, float delta, float extend) {
        Matrix3x2f matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.h().d().i();
        ThemeProcessor theme = Delta.h().d().o();
        b().a(this.d);
        b().a(0.0f, 1.0f, 0.4f, EasingList.p, delta);
        float centerY = this.a.y + (this.a.w / 2.0f) + 0.5f;
        boolean hovered = MathUtil.a(mouseX, mouseY, this.a.x, this.a.y, this.a.z, this.a.w) && extend >= 1.0f;
        float anim = b().c();
        float reverse = 1.0f - anim;
        String value = ((BindSetting) this.b).c().intValue() == -1 ? "None" : KeyUtil.b(((BindSetting) this.b).c().intValue());
        float total = (Fonts.c.a(value, 6.5f) * reverse) + (Fonts.c.a("...", 6.5f) * anim);
        float boxWidth = total + 8.0f;
        float boxHeight = Fonts.c.a(6.5f) + 3.0f;
        float boxX = (this.a.x + this.a.z) - boxWidth;
        float boxY = centerY - (boxHeight / 2.0f);
        float textY = (boxY + ((boxHeight - Fonts.c.a(6.5f)) / 2.0f)) - 0.75f;
        a(matrices, Fonts.c, ((BindSetting) this.b).i(), this.a.x, this.a.y, this.a.w, 6.5f, theme.a(ThemeInfo.TEXT).a(), (boxX - this.a.x) - 4.0f, hovered, extend, delta);
        draw.a(matrices, boxX, boxY, boxWidth, boxHeight, 2.0f, ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), 0.039215688f * extend));
        draw.a(matrices, boxX, boxY, boxWidth, boxHeight, 2.0f, 0.5f, ColorUtil.a(theme.a(ThemeInfo.OUTLINE_MEDIUM).a(), theme.a(ThemeInfo.OUTLINE_MEDIUM).b() * extend));
        ScissorUtil.a(matrices, boxX, boxY, boxWidth, boxHeight);
        if (reverse > 0.0f) {
            Fonts.c.a(matrices, value, boxX + 4.0f, textY, 6.5f, ColorUtil.a(theme.a(ThemeInfo.TEXT).a(), extend * reverse));
        }
        if (anim > 0.0f) {
            Fonts.c.a(matrices, "...", boxX + 4.0f, textY, 6.5f, ColorUtil.a(theme.a(ThemeInfo.TEXT).a(), extend * anim));
        }
        ScissorUtil.a(matrices);
    }
}
