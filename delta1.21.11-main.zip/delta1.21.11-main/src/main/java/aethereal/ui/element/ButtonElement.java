package aethereal.ui.element;

import aethereal.core.Delta;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;
import aethereal.config.ThemeInfo;
import aethereal.config.ThemeProcessor;
import aethereal.render.Draw2DProcessor;
import aethereal.setting.ButtonSetting;

import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2f;
import org.joml.Vector4f;

public class ButtonElement extends Element_2<ButtonSetting> {
    @Override
    public boolean a(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return false;
        }
        Vector4f vector4f = this.a;
        var setting = this.b;
        if (!MathUtil.a(mouseX, mouseY, vector4f.x, vector4f.y, vector4f.z, vector4f.w)) {
            return false;
        }
        if (!(setting instanceof ButtonSetting)) {
            throw new ClassCastException();
        }
        ((ButtonSetting) setting).k();
        return true;
    }

    public ButtonElement(ButtonSetting setting) {
        super(setting);
        this.a.w = 14.0f;
    }

    @Override
    public void a(DrawContext context, double mouseX, double mouseY, float delta, float extend) {
        Matrix3x2f matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.h().d().i();
        ThemeProcessor theme = Delta.h().d().o();
        b().a(MathUtil.a(mouseX, mouseY, this.a.x, this.a.y, this.a.z, this.a.w) && extend >= 1.0f);
        b().a(0.0f, 1.0f, 0.3f, EasingList.i, delta);
        float hover = b().c();
        int text = ColorUtil.a(255, 255, 255, 255);
        draw.a(matrices, this.a.x, this.a.y, this.a.z, this.a.w, 4.0f, ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), ((10.0f + (20.0f * hover)) / 255.0f) * extend));
        draw.a(matrices, this.a.x, this.a.y, this.a.z, this.a.w, 4.0f, 0.5f, ColorUtil.a(theme.a(ThemeInfo.OUTLINE_MEDIUM).a(), theme.a(ThemeInfo.OUTLINE_MEDIUM).b() * extend));
        Fonts.c.b(matrices, ((ButtonSetting) this.b).i(), this.a.x + (this.a.z / 2.0f), (this.a.y + ((this.a.w - Fonts.c.a(7.0f)) / 2.0f)) - 0.5f, 7.0f, ColorUtil.a(text, extend));
    }
}
