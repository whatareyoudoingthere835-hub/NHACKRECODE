package aethereal.ui.element;

import aethereal.setting.StringSetting;

import net.minecraft.client.gui.DrawContext;
import org.joml.Vector2f;

public class StringElement extends Element_2<StringSetting> {
    private TextField d;

    @Override
    public boolean a(double mouseX, double mouseY, int button) {
        TextField textField = g();
        if (textField != null) {
            textField.a(mouseX, mouseY, button);
            return textField.j();
        }
        return false;
    }

    @Override
    public boolean a(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.d == null) {
            return false;
        }
        this.d.b(mouseX, mouseY, button);
        return this.d.j();
    }

    @Override
    public boolean a(int keyCode, int scanCode, int modifiers) {
        if (this.d == null || !this.d.j()) {
            return false;
        }
        this.d.a(keyCode, scanCode, modifiers);
        return true;
    }

    @Override
    public boolean a(char chr, int modifiers) {
        if (this.d == null || !this.d.j()) {
            return false;
        }
        this.d.a(chr, modifiers);
        return true;
    }

    public StringElement(StringSetting setting) {
        super(setting);
        this.a.w = 12.0f;
    }

    private TextField g() {
        if (this.d == null) {
            this.d = new TextField(TextField.a.GUI_SETTING, ((StringSetting) this.b).k());
            this.d.a(((StringSetting) this.b).i());
            this.d.g().append(((StringSetting) this.b).c());
        }
        return this.d;
    }

    @Override
    public void a(DrawContext context, double mouseX, double mouseY, float delta, float extend) {
        TextField field = g();
        field.b(new Vector2f(this.a.z, this.a.w));
        field.a(new Vector2f(this.a.x, this.a.y));
        String currentSetting = ((StringSetting) this.b).c();
        if (!field.j() && !field.g().toString().equals(currentSetting)) {
            field.g().setLength(0);
            field.g().append(currentSetting != null ? currentSetting : "");
        }
        field.a(context, mouseX, mouseY, delta, extend);
        if (field.j()) {
            String text = field.g().toString();
            if (!text.equals(currentSetting)) {
                ((StringSetting) this.b).a(text);
            }
        }
    }
}
