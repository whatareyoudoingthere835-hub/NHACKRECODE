package aethereal.ui.widget;

import aethereal.core.Delta;
import aethereal.render.EasingList;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;
import aethereal.render.AnimationUtil;
import java.util.List;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

public class EffectMarker {
    private static final Identifier WHITE_TEX = Identifier.of("delta", "textures/white.png");

    private EffectMarker() {
    }

    public static void a(List<a> list, float x, float y) {
        if (list != null) {
            list.add(new a(x, y));
        }
    }

    public static void a(Matrix3x2fStack matrices, float partialTicks, List<a> list) {
        if (list == null || list.isEmpty()) {
            return;
        }
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).a(matrices, partialTicks)) {
                list.remove(i);
            }
        }
    }

    public static final class a {
        private final AnimationUtil a = new AnimationUtil();
        private final long b = System.nanoTime() + 300000000;
        private final float c;
        private final float d;
        private boolean e;

        a(float x, float y) {
            this.c = x;
            this.d = y;
        }

        boolean a(Matrix3x2fStack matrices, float partialTicks) {
            this.a.a(0.0f, 1.0f, 0.2f, EasingList.h, partialTicks);
            if (!this.e && System.nanoTime() >= this.b) {
                this.e = true;
            }
            this.a.a(!this.e);
            float progress = MathUtil.b(this.a.c(), 0.0f, 1.0f);
            float scale = this.e ? progress : a(progress);
            float length = 4.0f * Math.max(1.0E-4f, scale);
            int color = ColorUtil.a(255, 255, 255, Math.round(250.0f * progress));

            float matScale = matrices != null ? (float) Math.hypot(matrices.m00, matrices.m01) : 1.0f;
            float matRot = matrices != null ? (float) Math.toDegrees(Math.atan2(matrices.m01, matrices.m00)) : 0.0f;
            float thickness = 0.5f;

            for (int i = 0; i < 4; i++) {
                float angleDeg = 45.0f + (90.0f * i);
                float rad = (float) Math.toRadians(angleDeg);
                float offset = length;
                float cx = this.c + (float) Math.cos(rad) * offset;
                float cy = this.d + (float) Math.sin(rad) * offset;

                float tcx = matrices != null ? (matrices.m00 * cx + matrices.m10 * cy + matrices.m20) : cx;
                float tcy = matrices != null ? (matrices.m01 * cx + matrices.m11 * cy + matrices.m21) : cy;

                float drawLen = length * matScale;
                float drawThick = thickness * matScale;
                float radius = drawThick * 0.5f;

                Delta.h().d().i().getTexturePipeline().drawTexture(
                        WHITE_TEX,
                        tcx - drawLen * 0.5f,
                        tcy - drawThick * 0.5f,
                        drawLen,
                        drawThick,
                        0.0f, 0.0f, 1.0f, 1.0f,
                        new int[]{color},
                        new float[]{radius, radius, radius, radius},
                        0.5f,
                        angleDeg + matRot
                );
            }
            return this.e && progress <= 0.01f;
        }

        private float a(float scale) {
            if (scale <= 0.0f) {
                return 0.0f;
            }
            if (scale < 0.6f) {
                return scale / 0.6f;
            }
            return scale < 0.8f ? 1.0f + (((scale - 0.6f) / 0.5f) * 0.5f) : 1.2f - (((scale - 0.8f) / 0.2f) * 0.2f);
        }
    }
}
