package aethereal.ui.screen;

import aethereal.render.ScissorUtil;
import aethereal.core.Delta;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.core.Module;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.KeyUtil;
import aethereal.util.MathUtil;

import aethereal.config.ThemeInfo;
import aethereal.config.ThemeProcessor;
import aethereal.render.Draw2DProcessor;
import aethereal.ui.element.Element_2;

import aethereal.render.AnimationUtil;
import aethereal.core.Category;
import java.util.Iterator;
import java.util.List;
import lombok.Generated;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fStack;
import org.joml.Vector4f;

public class GUIPanel {
    private final Vector4f a = new Vector4f(0.0f, 0.0f, 125.0f, 270.0f);
    private final AnimationUtil b = new AnimationUtil();
    private final AnimationUtil c = new AnimationUtil();
    private final Category d;
    private List<Module> e;
    private Module f;

    private Module getModuleAt(double mouseX, double mouseY) {
        if (this.e == null) return null;
        float y = this.a.y + 24.0f + 4.0f;
        float view = (((this.a.y + this.a.w) - 6.0f) - y) + 4.0f;
        float content = 0.0f;
        for (Module m : this.e) {
            content += b(m) + 4.0f;
        }
        float y2 = y + this.b.a(Math.min(0.0f, view - content), 0.0f, 8.0f);
        float bottom = y + view;
        for (Module module : this.e) {
            if (((float) mouseY) >= y && ((float) mouseY) <= bottom && MathUtil.a(mouseX, mouseY, this.a.x + 6.0f, y2, this.a.z - 12.0f, 16.0f)) {
                return module;
            }
            float total = b(module);
            y2 += total + 4.0f;
        }
        return null;
    }

    public boolean a(final double mouseX, final double mouseY, final int button) {
        if (this.e == null) return false;
        for (Module module : this.e) {
            if (module.n()) {
                module.a(-100 + button);
                module.b(false);
                return true;
            }
        }
        Module target = getModuleAt(mouseX, mouseY);
        if (target == null) {
            target = this.f;
        }
        if (target != null) {
            if (button == 0) {
                target.a();
                return true;
            }
            if (button == 1) {
                target.c(!target.o());
                return true;
            }
            if (button == 2) {
                this.e.forEach(obj -> this.i((Module) obj));
                return true;
            }
        }
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element_2::a).anyMatch(element -> element.a(mouseX, mouseY, button));
    }

    public boolean b(final double mouseX, final double mouseY, final int button) {
        if (this.e == null) return false;
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element_2::a).anyMatch(element -> element.b(mouseX, mouseY, button));
    }

    public boolean a(final double mouseX, final double mouseY, final int button, final double deltaX, final double deltaY) {
        if (this.e == null) return false;
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element_2::a).anyMatch(element -> element.a(mouseX, mouseY, button, deltaX, deltaY));
    }

    public boolean a(final int keyCode, final int scanCode, final int modifiers) {
        if (this.e == null) return false;
        for (Module module : this.e) {
            if (module.n()) {
                if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_DELETE || keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_BACKSPACE) {
                    module.a(-1);
                } else if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {

                } else {
                    module.a(keyCode);
                }
                module.b(false);
                return true;
            }
        }
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element_2::a).anyMatch(element -> element.a(keyCode, scanCode, modifiers));
    }

    public boolean hasActiveBinding() {
        if (this.e == null) return false;
        for (Module module : this.e) {
            if (module.n()) return true;
            if (module.o()) {
                for (Element_2<?> el : module.d()) {
                    if (el instanceof aethereal.ui.element.BindElement bindEl && bindEl.isBinding()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void cancelActiveBindings() {
        if (this.e == null) return;
        for (Module module : this.e) {
            module.b(false);
            if (module.o()) {
                for (Element_2<?> el : module.d()) {
                    if (el instanceof aethereal.ui.element.BindElement bindEl) {
                        bindEl.cancelBinding();
                    }
                }
            }
        }
    }

    public boolean a(final char chr, final int modifiers) {
        if (this.e == null) return false;
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element_2::a).anyMatch(element -> element.a(chr, modifiers));
    }

    public boolean a(final double mouseX, final double mouseY, final double amount) {
        if (!MathUtil.a(mouseX, mouseY, this.a.x, this.a.y, this.a.z, this.a.w)) {
            return false;
        }
        if (this.e != null && this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element_2::a).anyMatch(element -> element.a(mouseX, mouseY, amount))) {
            return true;
        }
        this.b.a((float) amount * 15.0f);
        return true;
    }

    @Generated
    public void a(List<Module> modules) {
        this.e = modules;
    }

    @Generated
    public void a(Module hovered) {
        this.f = hovered;
    }

    @Generated
    public Vector4f f() {
        return this.a;
    }

    @Generated
    public AnimationUtil a() {
        return this.b;
    }

    @Generated
    public AnimationUtil b() {
        return this.c;
    }

    @Generated
    public Category c() {
        return this.d;
    }

    @Generated
    public List<Module> d() {
        return this.e;
    }

    @Generated
    public Module e() {
        return this.f;
    }

    public GUIPanel(Category category) {
        this.d = category;
    }

    public void a(DrawContext context, int mouseX, int mouseY, float delta) {
        Matrix3x2fStack matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.h().d().i();
        ThemeProcessor theme = Delta.h().d().o();
        this.c.a(0.0f, 1.0f, 0.35f, EasingList.i, delta);
        this.c.a(true);
        float scale = 0.8f + (0.2f * EasingList.s.ease(this.c.c()));
        matrices.pushMatrix();
        matrices.translate(this.a.x + (this.a.z / 2.0f), this.a.y + (this.a.w / 2.0f) + ((1.0f - EasingList.p.ease(this.c.c())) * 14.0f));
        matrices.scale(scale, scale);
        matrices.translate(-(this.a.x + (this.a.z / 2.0f)), -(this.a.y + (this.a.w / 2.0f)));
        int background = ColorUtil.a(ColorUtil.a(theme.a(ThemeInfo.BACKGROUND_GUI).a(), theme.a(ThemeInfo.PRIMARY).a(), theme.a(ThemeInfo.PRIMARY).b() / 4.0f), InterfaceC0020Opcode.aN);
        int shadowColor = ColorUtil.a(0, 0, 0, (int) (70.0f * this.c.c()));
        draw.a(matrices, this.a.x, this.a.y, this.a.z, this.a.w, 8.0f, background, 1.0f, shadowColor, 8.0f);
        draw.a(matrices, this.a.x, this.a.y, this.a.z, this.a.w, 8.0f, 0.5f, theme.a(ThemeInfo.OUTLINE_MEDIUM).a());
        a(matrices, theme, 24.0f);
        a(context, mouseX, mouseY, this.a.y + 24.0f + 4.0f, delta);
        matrices.popMatrix();
    }

    private void a(Matrix3x2f matrices, ThemeProcessor theme, float header) {
        float headerCenter = this.a.y + (header / 2.0f);
        float titleX = this.a.x + 6.0f + 4.0f;
        float iconWidth = Fonts.a.b(this.d.a(), 9.0f);
        float iconX = (((this.a.x + this.a.z) - 6.0f) - 4.0f) - iconWidth;
        int color = ColorUtil.a(ColorUtil.a(255, 255, 255, 255), ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), 1.0f), 0.25f);
        Fonts.c.a(matrices, this.d.name(), titleX, Fonts.c.a(this.d.name(), 9.0f, headerCenter), 9.0f, color);
        Fonts.a.a(matrices, this.d.a(), iconX, Fonts.a.a(this.d.a(), 9.0f, headerCenter), 9.0f, color);
    }

    private void a(DrawContext context, int mouseX, int mouseY, float y, float delta) {
        if (this.e == null) return;
        Matrix3x2fStack matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.h().d().i();
        ThemeProcessor theme = Delta.h().d().o();
        float view = (((this.a.y + this.a.w) - 6.0f) - y) + 4.0f;
        float content = 0.0f;
        Iterator<Module> it = this.e.iterator();
        while (it.hasNext()) {
            content += b(it.next()) + 4.0f;
        }
        float y2 = y + this.b.a(Math.min(0.0f, view - content), 0.0f, 8.0f);
        this.f = null;
        ScissorUtil.a(matrices, this.a.x, y, this.a.z, view);
        float bottom = y + view;
        Iterator<Module> it2 = this.e.iterator();
        while (it2.hasNext()) {
            Module module = it2.next();
            float center = y2 + 8.0f;
            float activation = module.f().c();
            float fade = (float) Math.pow(MathUtil.a(MathUtil.b((bottom - y2) / 16.0f, 0.0f, 1.0f)), 1.0d);
            boolean hover = ((float) mouseY) >= y && ((float) mouseY) <= bottom && MathUtil.a((double) mouseX, (double) mouseY, this.a.x + 6.0f, y2, this.a.z - 12.0f, 16.0f);
            if (hover) {
                this.f = module;
            }
            module.f().a(0.0f, 1.0f, 0.3f, EasingList.i, delta);
            module.f().a(module.m());
            module.g().a(0.0f, 1.0f, 0.3f, EasingList.i, delta);
            module.g().a(module.n());
            module.h().a(0.0f, 1.0f, 0.5f, EasingList.i, delta);
            module.i().a(0.0f, 1.0f, 0.25f, EasingList.i, delta);
            module.h().a(module.o());
            module.i().a(module == this.f);
            float total = b(module);
            if (y2 + total > y && y2 < bottom) {
                draw.a(matrices, this.a.x + 6.0f, y2, this.a.z - 12.0f, total, 4.0f, ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), 0.039215688f * activation * fade));
                draw.a(matrices, this.a.x + 6.0f, y2, this.a.z - 12.0f, total, 4.0f, ColorUtil.a(ColorUtil.a(255, 255, 255, 255), 0.023529412f * module.i().c() * fade));
                draw.a(matrices, this.a.x + 6.0f, y2, this.a.z - 12.0f, total, 4.0f, 0.5f, ColorUtil.a(theme.a(ThemeInfo.OUTLINE_SMALL).a(), theme.a(ThemeInfo.OUTLINE_SMALL).b() * activation * fade));
                Fonts.c.a(matrices, module.j(), this.a.x + 6.0f + 4.0f, (center - (Fonts.c.a(7.25f) / 2.0f)) - 0.5f, 7.25f, ColorUtil.a(theme.a(ThemeInfo.TEXT).a(), fade));
                if (module.g().c() > 0.0f) {
                    float bind = module.g().c();
                    String bindText = module.n() ? "?" : KeyUtil.b(module.p());
                    float iconWidth = Fonts.a.b("C", 6.0f);
                    float boxWidth = 4.0f + iconWidth + 2.5f + Fonts.c.a(bindText, 6.0f) + 4.0f;
                    float boxX = this.a.x + 6.0f + 4.0f + Fonts.c.a(module.j(), 7.25f) + 4.0f;
                    float boxY = center - 4.5f;
                    draw.a(matrices, boxX, boxY, boxWidth, 9.0f, 2.0f, ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), 0.15686275f * bind));
                    draw.a(matrices, boxX, boxY, boxWidth, 9.0f, 2.0f, 0.5f, ColorUtil.a(theme.a(ThemeInfo.OUTLINE_MEDIUM).a(), theme.a(ThemeInfo.OUTLINE_MEDIUM).b() * bind));
                    Fonts.a.a(matrices, "C", boxX + 4.0f, Fonts.a.a("C", 6.0f, center), 6.0f, ColorUtil.a(theme.a(ThemeInfo.TEXT).a(), bind));
                    Fonts.c.a(matrices, bindText, boxX + 4.0f + iconWidth + 2.5f, Fonts.c.a(bindText, 6.0f, center), 6.0f, ColorUtil.a(theme.a(ThemeInfo.TEXT).a(), bind));
                }
                if (module.d().stream().anyMatch(v0 -> v0.a())) {
                    Fonts.c.a(matrices, "...", ((((this.a.x + this.a.z) - 6.0f) - 4.0f) - Fonts.c.a("...", 10.0f)) - (activation > 0.0f ? 18.0f : 0.0f), Fonts.c.a("...", 10.0f, center), 10.0f, ColorUtil.a(theme.a(ThemeInfo.TEXT_DISABLED).a(), fade));
                }
                if (activation > 0.0f) {
                    float toggleX = (((this.a.x + this.a.z) - 6.0f) - 4.0f) - 14.0f;
                    float toggleY = center - 4.25f;
                    draw.a(matrices, toggleX, toggleY, 14.0f, 8.5f, 3.25f, ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), 0.49019608f * activation * fade));
                    draw.a(matrices, toggleX, toggleY, 14.0f, 8.5f, 3.25f, 0.3f, ColorUtil.a(theme.a(ThemeInfo.OUTLINE_SMALL).a(), theme.a(ThemeInfo.OUTLINE_SMALL).b() * activation * fade));
                    draw.a(matrices, toggleX + 1.5f + (5.5f * activation), toggleY + 1.5f, 5.5f, 5.5f, 1.75f, ColorUtil.a(ColorUtil.a(ColorUtil.a(InterfaceC0020Opcode.ap, InterfaceC0020Opcode.ap, InterfaceC0020Opcode.bk, 255), ColorUtil.a(255, 255, 255, 255), activation), activation * fade));
                }
                float extend = module.h().c();
                if (extend > 0.0f) {
                    ScissorUtil.a(matrices, this.a.x + 6.0f, y2, this.a.z - 12.0f, total);
                    float baseY = (y2 + 16.0f) - (4.0f * (1.0f - extend));
                    float offset = 0.0f;
                    for (Element_2<?> element : module.d()) {
                        element.c().a(element.a());
                        element.c().a(0.0f, 1.0f, 0.4f, EasingList.i, delta);
                        float visible = element.c().c();
                        if (visible > 0.0f) {
                            float targetY = (baseY + offset) - (4.0f * (1.0f - visible));
                            float currentY = baseY + ((targetY - baseY) * extend);
                            element.d().set(this.a.x + 6.0f + 4.5f, currentY, (this.a.z - 12.0f) - 8.0f, element.d().w());
                            element.a(context, mouseX, mouseY, delta, extend * visible);
                            offset += (element.d().w() + 4.0f) * visible;
                        }
                    }
                    ScissorUtil.a(matrices);
                }
            }
            y2 += total + 4.0f;
        }
        ScissorUtil.a(matrices);
    }

    public void a(DrawContext context, double mouseX, double mouseY, float delta) {
        if (this.e == null) return;
        for (Module module : this.e) {
            if (!module.o() || module.h().c() <= 0.01f) continue;
            for (Element_2<?> element : module.d()) {
                element.a(context, mouseX, mouseY, delta);
            }
        }
    }

    private float b(Module module) {
        return 16.0f + (module.d().isEmpty() ? 0.0f : ((float) module.d().stream().mapToDouble(e -> (e.d().w() + 4.0f) * e.c().c()).sum()) * module.h().c());
    }

    public void i(Module module) {
        module.b(module == this.f && !module.n());
    }
}
