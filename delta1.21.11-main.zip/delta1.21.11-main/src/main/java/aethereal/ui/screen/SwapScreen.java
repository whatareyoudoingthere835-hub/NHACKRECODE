package aethereal.ui.screen;

import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;

import aethereal.core.Interface;
import aethereal.ui.screen.RadialScreen;

import lombok.Generated;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import org.joml.Vector2f;

public class SwapScreen extends Screen implements Interface {
    private final RadialScreen b;
    private boolean c;

    @Generated
    public boolean b() {
        return this.c;
    }

    @Generated
    public void a(boolean open) {
        this.c = open;
    }

    public SwapScreen(Text title) {
        super(title);
        this.b = new RadialScreen(3, 75.0f, 101.25f);
        for (int i = 0; i < 3; i++) {
            int slot = i;
            this.b.a(slot, ItemStack.EMPTY, () -> {
                c(slot);
            }, true);
        }
    }

    private void c(int slot) {
        ItemStack stack = this.b.c(slot);
        if (stack.isEmpty()) {
            aM_.setScreen(new InventoryScreen(aM_.player));
            a(true);
        } else {
            aethereal.handler.Handlers.inventory().a(stack, 45, 1);
            aM_.player.closeScreen();
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        return this.b.a(click.x(), click.y(), click.button(), new Vector2f(this.width / 2.0f, this.height / 2.0f));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.b.a(context, mouseX, mouseY, new Vector2f(this.width / 2.0f, this.height / 2.0f));
        aethereal.render.pipeline.DrawBatcher.flushPending();
    }

    public void executeIfHovered() {
        if (aM_.getWindow().getFramebufferWidth() <= 0 || aM_.getWindow().getFramebufferHeight() <= 0) return;
        double mouseX = aM_.mouse.getX() * (double) this.width / (double) aM_.getWindow().getFramebufferWidth();
        double mouseY = aM_.mouse.getY() * (double) this.height / (double) aM_.getWindow().getFramebufferHeight();
        int slot = this.b.a(mouseX, mouseY, new Vector2f(this.width / 2.0f, this.height / 2.0f));
        if (slot >= 0) {
            ItemStack stack = this.b.c(slot);
            if (!stack.isEmpty()) {
                c(slot);
            }
        }
    }

    public int a() {
        return this.b.b();
    }

    public void a(int slot) {
        this.b.e(slot);
    }

    public void a(int segment, ItemStack stack) {
        this.b.a(segment, stack);
    }

    public ItemStack b(int segment) {
        return this.b.c(segment);
    }
}
