package aethereal.ui.screen;

import aethereal.core.NativeMethodLookup;
import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;

import aethereal.autobuy.AutoBuySection;
import aethereal.autobuy.CollectorSection;
import aethereal.config.ThemeInfo;
import aethereal.config.ThemeProcessor;
import aethereal.render.Draw2DProcessor;

import aethereal.render.AnimationUtil;
import aethereal.ui.element.Section;
import aethereal.api.Compile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import lombok.Generated;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Vector4f;

public class StationScreen extends Screen {
    private final List<Section> a;
    private final Vector4f b;
    private final Vector4f c;
    private final Vector4f d;
    private final AnimationUtil e;
    private final AnimationUtil f;
    private int g;
    private float h;

    @Compile
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        Vector4f vector4f = this.b;
        MinecraftClient class_310Var = Interface.aM_;
        vector4f.x = (class_310Var.getWindow().getScaledWidth() - this.b.z) * 0.5f;
        this.b.y = (class_310Var.getWindow().getScaledHeight() - this.b.w) * 0.5f;
        this.f.a(0.0f, 1.0f, 0.3f, EasingList.g, delta);
        this.f.a(true);
        Vector4f vector4f2 = this.b;
        float f = vector4f2.x;
        float f2 = 0.5f * vector4f2.z;
        float f3 = vector4f2.y;
        float f4 = 0.5f * vector4f2.w;
        float fEase = 0.85f + (EasingList.s.ease(this.f.c()) * 0.15f);
        org.joml.Matrix3x2fStack class_4587VarMethod_51448 = context.getMatrices();
        class_4587VarMethod_51448.pushMatrix();
        float f5 = f2 + f;
        float f6 = f4 + f3;
        class_4587VarMethod_51448.translate(f5, ((1.0f - EasingList.p.ease(this.f.c())) * 14.0f) + f6);
        class_4587VarMethod_51448.scale(fEase, fEase);
        class_4587VarMethod_51448.translate(-f5, -f6);
        Draw2DProcessor draw2DProcessorI = Delta.h().d().i();
        ThemeProcessor themeProcessorO = Delta.h().d().o();
        int iA = themeProcessorO.a(ThemeInfo.BACKGROUND_GUI).a();
        ThemeInfo themeInfo = ThemeInfo.PRIMARY;
        int iA2 = ColorUtil.a(ColorUtil.a(iA, themeProcessorO.a(themeInfo).a(), themeProcessorO.a(themeInfo).b() * 0.25f), 220);
        draw2DProcessorI.a(context.getMatrices(), vector4f2.x, vector4f2.y, vector4f2.z, vector4f2.w, 8.0f, iA2, 1.0f, iA2, 16.0f);
        draw2DProcessorI.a(context.getMatrices(), vector4f2.x, vector4f2.y, vector4f2.z, vector4f2.w, 8.0f, 0.5f, themeProcessorO.a(ThemeInfo.OUTLINE_MEDIUM).a());
        a(context, delta, iA2);
        this.d.set(vector4f2.x, this.c.y + this.c.w + 8.0f, vector4f2.z, ((vector4f2.y + vector4f2.w) - 8.0f) - ((this.c.y + this.c.w) + 12.0f));
        b().a(context, this.d, mouseX, mouseY, this.e.a(), delta);
        Draw2DProcessor draw2DProcessorI2 = Delta.h().d().i();
        float f7 = this.h;
        draw2DProcessorI2.a(context, f7 - 3.0f, this.c.y + this.c.w, 6.0f, 0.5f, Delta.h().d().o().a(ThemeInfo.PRIMARY).a());
        class_4587VarMethod_51448.popMatrix();
        this.e.a(Math.min(0.0f, this.d.w - b().a(this.d)), 0.0f, 1.0f);
    }

    @Compile
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (b().a(mouseX, mouseY, verticalAmount)) {
            return true;
        }
        this.e.a(((float) verticalAmount) * 15.0f);
        return true;
    }

    @Compile
    public boolean mouseClicked(net.minecraft.client.gui.Click click, boolean doubleClick) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();
        Vector4f vector4f = this.c;
        List<Section> list = this.a;
        Vector4f vector4f2 = this.d;
        AnimationUtil animationUtil = this.e;
        float f = vector4f.x + 12.0f;
        for (int i = 0; list.size() > i; i++) {
            float fB = Fonts.a.b(list.get(i).b(), 8.5f);
            if (MathUtil.a(mouseX, mouseY, f - 6.0f, vector4f.y, fB + 12.0f, vector4f.w)) {
                this.g = i;
                animationUtil.b(0.0f);
                return true;
            }
            f += fB + 12.0f;
        }
        if (vector4f2.y > mouseY || !b().a(mouseX, mouseY, button)) {
            return super.mouseClicked(click, doubleClick);
        }
        return true;
    }

    @Compile
    public boolean mouseReleased(net.minecraft.client.gui.Click click) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();
        if (b().b(mouseX, mouseY, button)) {
            return true;
        }
        return super.mouseReleased(click);
    }

    @Compile
    public boolean mouseDragged(net.minecraft.client.gui.Click click, double deltaX, double deltaY) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();
        if (b().a(mouseX, mouseY, button, deltaX, deltaY)) {
            return true;
        }
        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Compile
    public boolean charTyped(net.minecraft.client.input.CharInput input) {
        char character = input.isValidChar() ? input.asString().charAt(0) : '\0';
        int modifiers = input.modifiers();
        if (b().a(character, modifiers)) {
            return true;
        }
        return super.charTyped(input);
    }

    @Compile
    public boolean keyPressed(net.minecraft.client.input.KeyInput input) {
        int keyCode = input.key();
        int scanCode = input.scancode();
        int modifiers = input.modifiers();
        Section sectionB = b();
        if (sectionB == null) {
            throw new NullPointerException();
        }
        if (sectionB.a(keyCode, scanCode, modifiers)) {
            return true;
        }
        return super.keyPressed(input);
    }

    static {
        NativeMethodLookup.lookup(StationScreen.class, 17);
    }

    @Generated
    public AnimationUtil a() {
        return this.e;
    }

    public StationScreen(Text title) {
        this(title, 0);
    }

    public StationScreen(Text title, int selected) {
        super(title);
        this.a = new ArrayList();
        this.b = new Vector4f(0.0f, 0.0f, 425.0f, 235.0f);
        this.c = new Vector4f(0.0f, 0.0f, 0.0f, 16.0f);
        this.d = new Vector4f(0.0f, 0.0f, 0.0f, 0.0f);
        this.e = new AnimationUtil();
        this.f = new AnimationUtil();
        this.a.add(new CollectorSection());
        this.a.add(new AutoBuySection());
        this.g = selected;
    }

    public void close() {
        super.close();
        this.f.c(0.0f);
    }

    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    private Section b() {
        return this.a.get(this.g);
    }

    private void a(DrawContext context, float delta, int background) {
        Draw2DProcessor draw = Delta.h().d().i();
        ThemeProcessor theme = Delta.h().d().o();
        float iconsWidth = 12.0f * (this.a.size() - 1);
        Iterator<Section> it = this.a.iterator();
        while (it.hasNext()) {
            iconsWidth += Fonts.a.b(it.next().b(), 8.5f);
        }
        this.c.z = iconsWidth + 24.0f;
        this.c.x = this.b.x + ((this.b.z - this.c.z) / 2.0f);
        this.c.y = this.b.y + 8.0f;
        draw.a(context.getMatrices(), this.c.x, this.c.y, this.c.z, this.c.w, 6.0f, 0.5f, ColorUtil.a(255, 255, 255, 4));
        Fonts.a.a(context.getMatrices(), "a", this.b.x + 8.0f, this.c.y + ((this.c.w - Fonts.a.a(12.0f)) / 2.0f), 12.0f, ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), 0.75f));
        float separatorX = this.b.x + 8.0f + Fonts.a.a("a", 12.0f) + 8.0f;
        draw.a(context.getMatrices(), separatorX, this.c.y + ((this.c.w - 8.0f) / 2.0f), 0.75f, 8.0f, 0.0f, ColorUtil.a(255, 255, 255, 25));
        Fonts.c.a(context.getMatrices(), "By Ded", separatorX + 8.0f, (this.c.y + ((this.c.w - Fonts.c.a(6.75f)) / 2.0f)) - 0.5f, 6.75f, theme.a(ThemeInfo.TEXT_DISABLED).a());
        float avatarX = ((this.b.x + this.b.z) - 12.0f) - 8.0f;
        draw.a(context.getMatrices(), Identifier.of("delta", "icon.png"), avatarX, this.c.y + ((this.c.w - 12.0f) / 2.0f), 12.0f, 12.0f, 5.0f, -1);
        String sectionName = b().c();
        float separatorX2 = avatarX - 8.0f;
        draw.a(context.getMatrices(), separatorX2, this.c.y + ((this.c.w - 8.0f) / 2.0f), 0.75f, 8.0f, 0.0f, ColorUtil.a(255, 255, 255, 25));
        Fonts.c.a(context.getMatrices(), sectionName, (separatorX2 - 8.0f) - Fonts.c.a(sectionName, 6.75f), (this.c.y + ((this.c.w - Fonts.c.a(6.75f)) / 2.0f)) - 0.5f, 6.75f, theme.a(ThemeInfo.TEXT_DISABLED).a());
        float x = this.c.x + 12.0f;
        float y = this.c.y + ((this.c.w - Fonts.a.a(8.5f)) / 2.0f);
        float target = this.h;
        int i = 0;
        while (i < this.a.size()) {
            Section section = this.a.get(i);
            float iconWidth = Fonts.a.b(section.b(), 8.5f);
            section.a().a(i == this.g);
            section.a().a(0.0f, 1.0f, 0.3f, EasingList.i, delta);
            Fonts.a.a(context.getMatrices(), section.b(), x, y, 8.5f, ColorUtil.a(theme.a(ThemeInfo.TEXT_DISABLED).a(), ColorUtil.a(theme.a(ThemeInfo.PRIMARY).a(), 1.0f), section.a().c()));
            if (i == this.g) {
                target = x + (iconWidth / 2.0f);
            }
            x += iconWidth + 12.0f;
            i++;
        }
        this.h = this.h == 0.0f ? target : MathUtil.c(this.h, target, 1.25f);
    }
}
