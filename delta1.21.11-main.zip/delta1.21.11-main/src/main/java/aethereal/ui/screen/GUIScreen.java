package aethereal.ui.screen;

import aethereal.render.ScaleUtil;
import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.core.Category;
import aethereal.core.Module;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;
import aethereal.render.AnimationUtil;
import aethereal.ui.element.TextField;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import lombok.Generated;
import net.minecraft.client.gui.Click;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.joml.Vector2f;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fStack;
import org.joml.Vector4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

public class GUIScreen extends Screen {
    private final Screen parent;
    private final TextField a;
    private final AnimationUtil b;
    private final List<GUIPanel> c;
    private String d;

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    @Override
    protected void applyBlur(DrawContext context) {

    }

    @Override
    public void renderInGameBackground(DrawContext context) {

    }

    private String lastSearch = null;

    private void updateFilteredModules() {
        String currentSearch = this.a.g().toString().trim().toLowerCase();
        for (final GUIPanel gUIPanel : this.c) {
            List<Module> filtered = Delta.h().d().t().e().stream()
                    .filter(obj -> this.a(gUIPanel, obj, currentSearch))
                    .sorted(Comparator.comparing(Module::j, String.CASE_INSENSITIVE_ORDER))
                    .toList();
            gUIPanel.a(filtered);
        }
        this.lastSearch = currentSearch;
    }

    public boolean a(GUIPanel panel, Module module, String search) {
        return module.l() == panel.c() && (search.isEmpty() || module.j().toLowerCase().contains(search));
    }

    private DrawContext lateContext;
    private double lateMouseX;
    private double lateMouseY;
    private float lateDelta;
    private boolean latePending;

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        MinecraftClient client = this.client != null ? this.client : MinecraftClient.getInstance();
        double dA = MathUtil.scale(mouseX, 2);
        double dA2 = MathUtil.scale(mouseY, 2);
        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();

        String currentSearch = this.a.g().toString().trim().toLowerCase();
        if (this.lastSearch == null || !this.lastSearch.equals(currentSearch)) {
            updateFilteredModules();
        }

        double dSum = this.c.stream().mapToDouble(obj -> ((GUIPanel) obj).f().z).sum();
        float size = (this.c.size() - 1) * 8.0f;
        float f = size + ((float) dSum);
        float f2 = (screenWidth - f) * 0.5f;
        float f3 = f2;
        for (final GUIPanel gUIPanel : this.c) {
            Vector4f vector4fF = gUIPanel.f();
            vector4fF.x = f3;
            vector4fF.y = (client.getWindow().getScaledHeight() - vector4fF.w) * 0.5f;
            f3 += vector4fF.z + 8.0f;
        }

        this.lateContext = context;
        this.lateMouseX = dA;
        this.lateMouseY = dA2;
        this.lateDelta = delta;
        this.latePending = true;
    }

    public void renderLate() {
        if (!this.latePending || this.lateContext == null) {
            return;
        }
        this.latePending = false;
        DrawContext context = this.lateContext;
        double dA = this.lateMouseX;
        double dA2 = this.lateMouseY;
        float delta = this.lateDelta;
        int screenWidth = MinecraftClient.getInstance().getWindow().getScaledWidth();
        int screenHeight = MinecraftClient.getInstance().getWindow().getScaledHeight();
        ScaleUtil.a(context, 2);

        Delta.h().d().i().captureBlur();
        float openAnim = this.c.getFirst().b().c();
        if (openAnim > 0.0f) {
            Delta.h().d().i().a(context.getMatrices(), 0.0f, 0.0f, (float) screenWidth, (float) screenHeight, 0.0f, ColorUtil.a(0, 0, 0, (int) (60.0f * openAnim)));
        }
        for (GUIPanel panel : this.c) {
            panel.a(context, (int) dA, (int) dA2, delta);
        }
        for (GUIPanel panel : this.c) {
            panel.a(context, dA, dA2, delta);
        }
        float f5 = this.c.getFirst().f().w;
        Matrix3x2fStack matrices = context.getMatrices();
        float fC = this.c.getFirst().b().c();
        float fEase = EasingList.s.ease(fC);
        matrices.pushMatrix();
        double dSum = this.c.stream().mapToDouble(obj -> ((GUIPanel) obj).f().z).sum();
        float f = (this.c.size() - 1) * 8.0f + (float) dSum;
        float f4 = this.c.getFirst().f().y;
        float f6 = (0.5f * f) + ((screenWidth - f) * 0.5f);
        float fEase2 = EasingList.p.ease(fC);
        float f7 = f5 + f4;
        float targetSearchY = f7 + 12.0f;
        if (targetSearchY + 25.0f > screenHeight) {
            targetSearchY = Math.max(5.0f, f4 - 28.0f);
        }
        float f8 = targetSearchY + 10.0f;
        float f9 = ((1.0f - fEase2) * 14.0f) + f8;
        float f10 = (0.15f * fEase) + 0.85f;
        matrices.translate(f6, f9);
        matrices.scale(f10, f10);
        matrices.translate(-f6, -f8);
        a(context, f6, targetSearchY, (int) dA, (int) dA2, delta);
        matrices.popMatrix();
        a(context.getMatrices(), f6, f4, delta);
        aethereal.render.pipeline.DrawBatcher.flushPending();
        ScaleUtil.a(context);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();
        this.a.a(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button);
        if (this.c.stream().filter(GUIScreen::f).anyMatch(panel -> panel.a(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button))) {
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseReleased(Click click) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();
        if (this.c.stream().filter(GUIScreen::e).anyMatch(panel -> panel.b(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button))) {
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();
        this.a.b(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button);
        if (this.c.stream().filter(GUIScreen::d).anyMatch(panel -> panel.a(MathUtil.scale(mouseX, 2), MathUtil.scale(mouseY, 2), button, MathUtil.scale(deltaX, 2), MathUtil.scale(deltaY, 2)))) {
            return true;
        }
        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        double scaledX = MathUtil.scale(mouseX, 2);
        double scaledY = MathUtil.scale(mouseY, 2);
        for (GUIPanel panel : this.c) {
            if (panel.d() == null) {
                continue;
            }
            Vector4f bounds = panel.f();
            if (MathUtil.a(scaledX, scaledY, bounds.x, bounds.y, bounds.z, bounds.w)) {
                return panel.a(scaledX, scaledY, verticalAmount);
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int keyCode = input.key();
        int scanCode = input.scancode();
        int modifiers = input.modifiers();
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            boolean hadBinding = false;
            for (GUIPanel panel : this.c) {
                if (panel.hasActiveBinding()) {
                    panel.cancelActiveBindings();
                    hadBinding = true;
                }
            }
            if (hadBinding) {
                return true;
            }
            if (this.a.j()) {
                this.a.a(false);
                return true;
            }
            close();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        if (keyCode == 70 && (modifiers & 2) != 0) {
            this.a.a(!this.a.j());
            return true;
        }
        if (this.a.j()) {
            this.a.a(keyCode, scanCode, modifiers);
            return true;
        }
        if (this.c.stream().filter(GUIScreen::b).anyMatch(panel -> panel.a(keyCode, scanCode, modifiers))) {
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        char character = (char) input.codepoint();
        int modifiers = input.modifiers();
        if (this.a.j()) {
            this.a.a(character, modifiers);
            return true;
        }
        if (this.c.stream().filter(GUIScreen::a).anyMatch(panel -> panel.a(character, modifiers))) {
            return true;
        }
        return super.charTyped(input);
    }

    @Generated
    public TextField a() {
        return this.a;
    }

    @Generated
    public AnimationUtil b() {
        return this.b;
    }

    @Generated
    public List<GUIPanel> c() {
        return this.c;
    }

    @Generated
    public String d() {
        return this.d;
    }

    public GUIScreen(Text title, Screen parent) {
        super(title);
        this.parent = parent;
        this.a = new TextField(TextField.a.GUI);
        this.b = new AnimationUtil();
        this.c = new ArrayList<>();
        for (Category category : Category.values()) {
            this.c.add(new GUIPanel(category));
        }
        this.a.a("Поиск по модулям");
        updateFilteredModules();
    }

    public GUIScreen(Text title) {
        this(title, null);
    }

    @Override
    public void close() {
        aethereal.util.CursorUtil.a(aethereal.util.CursorUtil.a.DEFAULT);
        this.a.a(false);
        this.c.forEach(panel -> {
            panel.b().c(0.0f);
            panel.cancelActiveBindings();
        });
        if (this.client != null) {
            this.client.setScreen(this.parent != null ? this.parent : (this.client.world == null ? new MainScreen() : null));
        }
    }

    private void a(DrawContext context, float centerX, float searchY, int mouseX, int mouseY, float delta) {
        this.a.b(new Vector2f(100.0f, 20.0f));
        this.a.a(new Vector2f(centerX - 50.0f, searchY));
        this.a.a(context, mouseX, mouseY, delta, 1.0f);
    }

    private void a(Matrix3x2f matrices, float centerX, float panelTop, float delta) {
        Delta.h().d().o();
        Module hovered = this.c.stream().map(GUIPanel::e).filter(module -> module != null && module.k() != null && !module.k().isEmpty()).findFirst().orElse(null);
        if (hovered != null && !hovered.k().equals(this.d)) {
            this.d = hovered.k();
            this.b.c(0.0f);
        }
        this.b.a(0.0f, 1.0f, 0.3f, EasingList.i, delta);
        this.b.a(hovered != null);
        float fade = EasingList.p.ease(this.b.c());
        if (fade > 0.0f && this.d != null) {
            float x = centerX - (Fonts.c.a(this.d, 10.0f) / 2.0f);
            float y = Math.max(2.0f, ((panelTop - Fonts.c.a(10.0f)) - 8.0f) + ((1.0f - fade) * 4.0f));
            Fonts.c.a(matrices, this.d, x + 0.5f, y + 0.5f, 10.0f, ColorUtil.a(ColorUtil.a(0, 0, 0, 255), 0.5f * fade));
            Fonts.c.a(matrices, this.d, x, y, 10.0f, ColorUtil.a(ColorUtil.a(255, 255, 255, 255), fade));
        }
    }

    public static boolean f(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean e(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean d(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean c(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean b(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean a(GUIPanel panel) {
        return panel.d() != null;
    }
}
