package aethereal.ui.shader;

public class Shader {
    public void a() {}
}
