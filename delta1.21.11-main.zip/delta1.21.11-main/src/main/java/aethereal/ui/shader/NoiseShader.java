package aethereal.ui.shader;

import static aethereal.core.Interface.aM_;

import aethereal.core.EventManager;
import aethereal.core.EventTarget;
import aethereal.event.ResizeEvent;
import aethereal.ui.shader.Shader;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.OptionalInt;

public class NoiseShader extends Shader {
    private static final Identifier PIPELINE_ID = Identifier.of("delta", "pipeline/noise");
    private static final Identifier SHADER_ID = Identifier.of("delta", "core/noise/noise_shader");

    private static final RenderPipeline PIPELINE = RenderPipelines.register(
            RenderPipeline.builder()
                    .withLocation(PIPELINE_ID)
                    .withVertexShader(SHADER_ID)
                    .withFragmentShader(SHADER_ID)
                    .withVertexFormat(VertexFormats.EMPTY, VertexFormat.DrawMode.TRIANGLES)
                    .withUniform("NoiseData", UniformType.UNIFORM_BUFFER)
                    .withSampler("Sampler1")
                    .withSampler("Sampler2")
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .build());

    private GpuTexture depthCopy;
    private GpuTextureView depthCopyView;
    private GpuBuffer uniformBuffer;
    private ByteBuffer uniformData;
    private GpuBuffer dummyVertexBuffer;
    private int targetWidth;
    private int targetHeight;

    public NoiseShader() {
        EventManager.a(this);
    }

    @EventTarget
    public void a(ResizeEvent event) {
        closeTargets();
    }

    public void e() {
        if (aM_.getFramebuffer() == null) {
            return;
        }
        GpuTexture mainDepth = aM_.getFramebuffer().getDepthAttachment();
        if (mainDepth == null) {
            return;
        }
        int width = aM_.getFramebuffer().textureWidth;
        int height = aM_.getFramebuffer().textureHeight;
        if (width <= 0 || height <= 0) {
            return;
        }
        if (!ensureTargets(width, height)) {
            return;
        }
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        encoder.copyTextureToTexture(mainDepth, this.depthCopy, 0, 0, 0, 0, 0, width, height);
    }

    public void a(float[] color) {
        if (this.depthCopy == null || this.uniformBuffer == null || aM_.getFramebuffer() == null) {
            return;
        }
        if (this.uniformData == null || this.dummyVertexBuffer == null) {
            return;
        }
        this.uniformData.clear();
        this.uniformData.putFloat(color[0]).putFloat(color[1]).putFloat(color[2]).putFloat(color[3]);
        this.uniformData.putFloat((System.currentTimeMillis() % 100000L) / 1000.0f);
        this.uniformData.putFloat(0.0f).putFloat(0.0f).putFloat(0.0f);
        this.uniformData.rewind();
        RenderSystem.getDevice().createCommandEncoder()
                .writeToBuffer(this.uniformBuffer.slice(0, this.uniformData.remaining()), this.uniformData);

        GpuSampler depthSampler = RenderSystem.getSamplerCache().get(FilterMode.NEAREST);
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (RenderPass pass = encoder.createRenderPass(
                () -> "delta:noise_pass",
                aM_.getFramebuffer().getColorAttachmentView(),
                OptionalInt.empty())) {
            pass.setPipeline(PIPELINE);
            pass.setVertexBuffer(0, this.dummyVertexBuffer);
            pass.bindTexture("Sampler1", aM_.getFramebuffer().getDepthAttachmentView(), depthSampler);
            pass.bindTexture("Sampler2", this.depthCopyView, depthSampler);
            pass.setUniform("NoiseData", this.uniformBuffer);
            pass.draw(0, 6);
        }
    }

    private boolean ensureTargets(int width, int height) {
        if (this.depthCopy != null && this.targetWidth == width && this.targetHeight == height) {
            return true;
        }
        closeTargets();
        GpuDevice device = RenderSystem.getDevice();
        this.depthCopy = device.createTexture(
                () -> "delta:noise_depth_copy",
                GpuTexture.USAGE_COPY_DST | GpuTexture.USAGE_COPY_SRC | GpuTexture.USAGE_TEXTURE_BINDING,
                TextureFormat.DEPTH32,
                width, height, 1, 1);
        this.depthCopyView = device.createTextureView(this.depthCopy);
        this.uniformBuffer = device.createBuffer(
                () -> "delta:noise_uniform",
                GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                32);
        this.uniformData = MemoryUtil.memAlloc(32);
        ByteBuffer dummyData = MemoryUtil.memAlloc(4);
        dummyData.putInt(0);
        dummyData.flip();
        this.dummyVertexBuffer = device.createBuffer(
                () -> "delta:noise_dummy_vertex",
                GpuBuffer.USAGE_VERTEX,
                dummyData);
        MemoryUtil.memFree(dummyData);
        this.targetWidth = width;
        this.targetHeight = height;
        return true;
    }

    private void closeTargets() {
        if (this.depthCopyView != null) {
            this.depthCopyView.close();
            this.depthCopyView = null;
        }
        if (this.depthCopy != null) {
            this.depthCopy.close();
            this.depthCopy = null;
        }
        if (this.uniformBuffer != null) {
            this.uniformBuffer.close();
            this.uniformBuffer = null;
        }
        if (this.uniformData != null) {
            MemoryUtil.memFree(this.uniformData);
            this.uniformData = null;
        }
        if (this.dummyVertexBuffer != null) {
            this.dummyVertexBuffer.close();
            this.dummyVertexBuffer = null;
        }
        this.targetWidth = 0;
        this.targetHeight = 0;
    }

    public void close() {
        closeTargets();
    }
}
