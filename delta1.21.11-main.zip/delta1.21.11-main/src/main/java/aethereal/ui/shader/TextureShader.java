package aethereal.ui.shader;

import org.joml.Vector4f;

public class TextureShader extends Shader {
    public void a(float width, float height) {}
    public void a(Vector4f radius) {}
    public void a(float smoothness) {}
}
