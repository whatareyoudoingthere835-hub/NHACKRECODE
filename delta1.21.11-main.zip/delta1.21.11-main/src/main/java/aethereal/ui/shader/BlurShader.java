package aethereal.ui.shader;

import aethereal.core.Interface;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix3x2f;
import java.util.ArrayList;
import java.util.List;

public class BlurShader implements Interface {
    private final List<Object> n = new ArrayList<>();

    public List<Object> e() {
        return this.n;
    }

    public void a(MatrixStack matrixStack) {
        a();
    }

    public void a(Matrix3x2f matrixStack) {
        a();
    }

    public void a() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.gameRenderer != null) {
            try {
                mc.gameRenderer.renderBlur();
            } catch (Throwable ignored) {
            }
        }
    }
}

