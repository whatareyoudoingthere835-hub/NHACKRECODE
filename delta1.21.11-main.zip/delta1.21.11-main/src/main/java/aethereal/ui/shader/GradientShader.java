package aethereal.ui.shader;

import org.joml.Vector4f;

public class GradientShader extends Shader {
    public void a(float width, float height) {}
    public void a(Vector4f radius) {}
    public void a(float smoothness) {}
    public void a(float r, float g, float b, float a) {}
    public void b(float r, float g, float b, float a) {}
    public void c(float r, float g, float b, float a) {}
    public void d(float r, float g, float b, float a) {}
}
