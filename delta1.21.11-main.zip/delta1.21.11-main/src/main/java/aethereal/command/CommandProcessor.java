package aethereal.command;

import aethereal.core.NativeMethodLookup;
import aethereal.lib.log4j.LoggerFactory;

import aethereal.command.AHCommand;
import aethereal.command.BindCommand;
import aethereal.command.BlockESPCommand;
import aethereal.command.CCCommand;
import aethereal.command.ConfigCommand;
import aethereal.command.FriendCommand;
import aethereal.command.GPSCommand;
import aethereal.command.HClipCommand;
import aethereal.command.LayoutCommand;
import aethereal.command.MacrosCommand;
import aethereal.command.RCTCommand;
import aethereal.command.StaffCommand;
import aethereal.command.VClipCommand;
import aethereal.command.WayCommand;
import aethereal.config.BaseProcessor;

import aethereal.lib.log4j.Logger_2;
import aethereal.api.Compile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.ParsedCommandNode;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;
import aethereal.util.ChatUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.Generated;
import net.minecraft.command.CommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientCommandSource;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class CommandProcessor extends BaseProcessor {

    @Generated
    private static final Logger_2 b;
    private final List<BaseCommand> d = new ArrayList();
    private final WayCommand e = new WayCommand();
    private final GPSCommand f = new GPSCommand();
    private final LayoutCommand g = new LayoutCommand();
    private final RCTCommand h = new RCTCommand();
    private final BlockESPCommand i = new BlockESPCommand();
    private final String k = ".";
    private final CommandDispatcher<CommandSource> c = new CommandDispatcher<>(new CaseInsensitiveLiteral.a());
    private final ClientCommandSource j = new ClientCommandSource((ClientPlayNetworkHandler) null, MinecraftClient.getInstance(), net.minecraft.command.permission.PermissionPredicate.ALL);

    @Override
    @Compile
    public void setup() {
        a(this.e, this.f, this.g, this.h, this.i, new AHCommand(), new MacrosCommand(), new FriendCommand(), new StaffCommand(), new ConfigCommand(), new BindCommand(), new VClipCommand(), new HClipCommand(), new CCCommand());
    }

    static {
        NativeMethodLookup.lookup(CommandProcessor.class, 22);
        b = LoggerFactory.a((Class<?>) CommandProcessor.class);
    }

    @Generated
    public CommandDispatcher<CommandSource> a() {
        return this.c;
    }

    @Generated
    public List<BaseCommand> b() {
        return this.d;
    }

    @Generated
    public WayCommand c() {
        return this.e;
    }

    @Generated
    public GPSCommand d() {
        return this.f;
    }

    @Generated
    public LayoutCommand e() {
        return this.g;
    }

    @Generated
    public RCTCommand f() {
        return this.h;
    }

    @Generated
    public BlockESPCommand g() {
        return this.i;
    }

    @Generated
    public ClientCommandSource h() {
        return this.j;
    }

    @Generated
    public String i() {
        Objects.requireNonNull(this);
        return ".";
    }

    @Override
    public void unSetup() {
    }

    public void a(BaseCommand... commands) {
        for (BaseCommand command : commands) {
            this.d.add(command);
            command.a(this.c);
        }
    }

    public void a(String message, CallbackInfo ci) {
        if (message == null || message.isEmpty() || !message.startsWith(i())) {
            return;
        }
        ci.cancel();

        String command = message.substring(i().length()).trim();
        if (command.isEmpty()) {
            ChatUtil.a("&cВведите команду. Введите &f" + i() + "&c и нажмите Tab для просмотра всех команд");
            return;
        }

        try {
            ParseResults<CommandSource> results = this.c.parse(command, this.j);

            String rootName = command.split("\\s+")[0];
            CommandNode<CommandSource> rootChild = this.c.getRoot().getChild(rootName);
            if (rootChild == null) {
                for (CommandNode<CommandSource> child : this.c.getRoot().getChildren()) {
                    if (child.getName().equalsIgnoreCase(rootName)) {
                        rootChild = child;
                        break;
                    }
                }
            }
            if (rootChild == null) {
                ChatUtil.a("&cКоманда &f" + rootName + "&c не найдена! Введите &f" + i() + "&c для списка команд");
                return;
            }

            for (ParsedCommandNode<CommandSource> parsed : results.getContext().getNodes()) {
                CommandNode<CommandSource> node = parsed.getNode();
                if (node instanceof LiteralCommandNode<CommandSource> literal) {
                    int typedLength = parsed.getRange().getLength();
                    if (typedLength != literal.getLiteral().length()) {
                        ChatUtil.a("&cКоманда &f" + rootName + "&c не найдена! Введите &f" + i() + "&c для списка команд");
                        return;
                    }
                }
            }

            if (results.getReader().canRead()) {
                if (!results.getExceptions().isEmpty()) {
                    for (CommandSyntaxException ex : results.getExceptions().values()) {
                        ChatUtil.a("&c" + ex.getMessage());
                    }
                } else {
                    ChatUtil.a("&cНеизвестный аргумент или неверный синтаксис команды");
                }
                return;
            }

            this.c.execute(results);
        } catch (CommandSyntaxException e) {
            ChatUtil.a("&c" + e.getMessage());
        } catch (Exception e) {
            ChatUtil.a("&cОшибка при выполнении команды: " + e.getMessage());
        }
    }

    public static <T> RequiredArgumentBuilder<CommandSource, T> a(String name, ArgumentType<T> type) {
        return RequiredArgumentBuilder.argument(name, type);
    }
}
