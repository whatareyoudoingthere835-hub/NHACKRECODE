package aethereal.network;

import aethereal.core.NativeMethodLookup;
import aethereal.lib.json.JSONArray;
import aethereal.lib.json.JSONObject;
import aethereal.config.ConfigProcessor;
import aethereal.network.AccountConstructor;

import aethereal.api.Compile;
import java.util.ArrayList;
import java.util.List;

public class AccountProcessor extends ConfigProcessor<AccountConstructor> {
    private AccountConstructor selected;

    @Override
    @Compile
    protected List<AccountConstructor> a(String json) throws Exception {
        JSONArray jSONArray = new JSONArray(json);
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.a(); i++) {
            JSONObject jSONObjectJ = jSONArray.j(i);
            AccountConstructor accountConstructor = new AccountConstructor(jSONObjectJ.l("name"));
            accountConstructor.a(jSONObjectJ.q("selected"));
            accountConstructor.b(jSONObjectJ.q("favorited"));
            arrayList.add(accountConstructor);
        }
        return arrayList;
    }

    @Override
    @Compile
    protected String a(List<AccountConstructor> data) throws Exception {
        JSONArray jSONArray = new JSONArray();
        for (AccountConstructor accountConstructor : data) {
            JSONObject jSONObject = new JSONObject();
            if (!(accountConstructor instanceof AccountConstructor)) {
                throw new ClassCastException();
            }
            AccountConstructor accountConstructor2 = accountConstructor;
            jSONObject.c("name", accountConstructor2.b());
            jSONObject.b("selected", accountConstructor2.c());
            jSONObject.b("favorited", accountConstructor2.d());
            jSONArray.a(jSONObject);
        }
        return jSONArray.E(2);
    }

    static {
        NativeMethodLookup.lookup(AccountProcessor.class, 19);
    }

    @Override
    public void setup() {
        super.setup();
        this.selected = this.d.stream().filter(AccountConstructor::c).findFirst()
                .orElse(this.d.isEmpty() ? null : this.d.get(0));
        if (this.selected != null) {
            this.a(this.selected);
        }
    }

    @Override
    public void unSetup() {
        if (this.selected != null && this.d.contains(this.selected)) {
            this.a(this.selected);
        }
        super.unSetup();
    }

    public List<AccountConstructor> e() {
        return this.d;
    }

    public AccountConstructor a() {
        return this.selected;
    }

    public void a(AccountConstructor account) {
        this.d.forEach(other -> other.a(other == account));
        this.selected = account;
    }

    @Override
    protected String b() {
        return "accounts.json";
    }
}
