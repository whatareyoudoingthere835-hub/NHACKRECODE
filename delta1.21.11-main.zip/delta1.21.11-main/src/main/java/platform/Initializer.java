package platform;

import aethereal.core.Delta;
import aethereal.core.NativeMethodLookup;
import aethereal.api.Compile;
import aethereal.render.Font;
import net.fabricmc.api.ClientModInitializer;

public class Initializer implements ClientModInitializer {
    @Compile
    public void onInitializeClient() {
        new Delta();
        try {
            aethereal.render.ImmediateRenderer.init();
            Font.getRenderer();
            System.out.println("[Delta] Client mod initialized successfully, pipelines and fonts loaded!");
        } catch (Throwable t) {
            System.err.println("[Delta] Warning during font preload: " + t.getMessage());
            t.printStackTrace();
        }
    }

    static {
        NativeMethodLookup.lookup(Initializer.class, 1);
    }
}

